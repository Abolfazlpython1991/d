import subprocess
import psutil
import time

def is_script_running(script_name):
    for process in psutil.process_iter(['pid', 'name', 'cmdline']):
        if script_name in process.info['cmdline']:
            return True
    return False

def run_script(script_name):
    subprocess.Popen(['python', script_name])

script_name = 'tl.add-to-group.py'

while True:
    if not is_script_running(script_name):
        #print(f"{script_name} is not running. Starting it...")
        run_script(script_name)
    else:
        #print(f"{script_name} is already running.")
        pass
    time.sleep(1.5)
