#!/bin/sh
python3 bot.py &
python3 tl.add-to-group.py &
# python3 runner.py &
# python3 z.get_api.py &
