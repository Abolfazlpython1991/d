#!/usr/bin/env python3
# pylint: disable=C0116,W0613

from os import system
import string
import random
import os
import shutil
import json
import time
import datetime
import jdatetime
import re
import mysql.connector
import asyncio
import telegram
from queue import Queue as queue
from telegram import Chat as chat, Message
from telegram.ext import filters as Filters
from telegram import Update, ChatPermissions, ForceReply
from telegram.ext import Updater, CommandHandler, MessageHandler, CallbackQueryHandler, CallbackContext, Application
from telegram.error import RetryAfter, TimedOut
from telethon.sync import TelegramClient
import utility as utl
import nest_asyncio

nest_asyncio.apply()

directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))
try:
    with open(f"{directory}/pid/{filename}.txt", "r") as file:
        pid = int(file.read())
    os.kill(pid, 0)
except OSError:
    with open(f"{directory}/pid/{filename}.txt", "w") as file:
        file.write(str(os.getpid()))
else:
    os.system(f"kill -9 {pid}")
    time.sleep(2)
    try:
        os.kill(pid, 0)
    except OSError:
        with open(f"{directory}/pid/{filename}.txt", "w") as file:
            file.write(str(os.getpid()))
    else:
        print("Try again!")
        exit()
print(f"run: {filename}")

step_page = 15


def write_on_file(name, content):
    with open(name, 'w') as file:
        file.write(content)


def uniq_id_generate(cs, num, table):
    randon_num = str(''.join(random.choices(string.ascii_uppercase + string.digits, k=num)))
    cs.execute(f"SELECT * FROM {table} WHERE uniq_id='{randon_num}'")
    if cs.fetchone() == None:
        return randon_num
    else:
        uniq_id_generate(num, table)


def select_api(cs, num):
    outout = ""
    cs.execute(f"SELECT api_id,count(*) FROM {utl.mbots} GROUP BY api_id HAVING count(*)>={num}")
    result = cs.fetchall()
    if not result:
        cs.execute(f"SELECT * FROM {utl.apis}")
        return cs.fetchone()

    for row in result:
        outout += f"'{row['api_id']}',"

    cs.execute(f"SELECT * FROM {utl.apis} WHERE api_id NOT IN ({outout[0:-1]})")
    return cs.fetchone()


async def admin_panel(update, cs, just_keyboard=False):
    keyboard = [
        [{'text': 'محدودیت چند ساعته'}],
        [{'text': 'اد هر شماره در هر بار استفاده'}],
        [{'text': 'هر api چند شماره'}],
        [{'text': utl.menu_var}],
    ]
    if just_keyboard:
        return keyboard
    cs.execute(f"SELECT * FROM {utl.admini}")
    row_admin = cs.fetchone()
    await update.message.reply_html(text="پنل ادمین:\n\n" +
                                         f"- هر اکانت در {row_admin['limit_per_h']} ساعت یکبار استفاده می شود\n" +
                                         f"- هر اکانت در هر استفاده {row_admin['add_per_h']} اد می کند\n" +
                                         f"- در هر api {row_admin['api_per_number']} شماره ثبت می شود\n\n" +
                                         f"❗️ در هر استفاده از اکانت الزاما {row_admin['add_per_h']} اد نمی کند بلکه {row_admin['add_per_h']} شماره را بررسی میکند و هر تعداد قابلیت اد داشت اد می کند",
                                    reply_markup={'resize_keyboard': True, 'keyboard': keyboard}
                                    )


async def user_panel(update, just_keyboard=False):
    keyboard = [
        [{'text': '🔮 آنالیز گروه 🔮'}],
        [{'text': '📋 سفارشات'}, {'text': '➕ ایجاد سفارش'}],
        [{'text': '📋 اکانت ها'}, {'text': '➕ افزودن اکانت'}],
        [{'text': '📋 لیست api ها'}, {'text': '➕ افزودن api'}],
        [{'text': '📊 آمار 📊'}],
    ]
    if just_keyboard:
        return keyboard
    await update.message.reply_html(text="ناحیه کاربری:",
                                    reply_markup={'resize_keyboard': True, 'keyboard': keyboard}
                                    )


class Pagination:
    inline_keyboard = []

    def __init__(self, update, type_btn, output, step_page, num_all_pages):
        self.update = update
        self.type_btn = type_btn
        self.text = output
        self.step_page = step_page
        self.num_all_pages = num_all_pages

    def setStepPage(self, step_page):
        self.step_page = step_page

    def setText(self, text):
        self.text = text

    def setNumAllPages(self, num_all_pages):
        self.num_all_pages = num_all_pages

    async def processMessage(self):
        chat_id = self.update.message.chat.id
        if self.num_all_pages > self.step_page:
            await self.update.message.reply_html(disable_web_page_preview=True, text=self.text,
                                                reply_markup={'inline_keyboard': [
                                                    [{'text': f"صفحه 2", 'callback_data': f"pg;{self.type_btn};2"}]]}
                                                )
        else:
            await self.update.message.reply_html(disable_web_page_preview=True, text=self.text)
        return

    async def processCallback(self):
        query = self.update.callback_query
        ex_data = query.data.split(";")
        num_current_page = int(ex_data[2])
        num_prev_page = num_current_page - 1
        num_next_page = num_current_page + 1
        if num_current_page == 1:
            await query.edit_message_text(parse_mode='HTML', disable_web_page_preview=True, text=self.text,
                                          reply_markup={'inline_keyboard': [[{'text': f"<< صفحه {num_next_page}",
                                                                              'callback_data': f"pg;{self.type_btn};{num_next_page}"}]]}
                                          )
        elif self.num_all_pages > (num_current_page * self.step_page):
            await query.edit_message_text(parse_mode='HTML', disable_web_page_preview=True, text=self.text,
                                          reply_markup={'inline_keyboard': [
                                              [{'text': f"صفحه {num_prev_page} >>",
                                                'callback_data': f"pg;{self.type_btn};{num_prev_page}"},
                                               {'text': f"<< صفحه {num_next_page}",
                                                'callback_data': f"pg;{self.type_btn};{num_next_page}"}]
                                          ]}
                                          )
        else:
            await query.edit_message_text(parse_mode='HTML', disable_web_page_preview=True, text=self.text,
                                          reply_markup={'inline_keyboard': [[{'text': f"صفحه {num_prev_page} >>",
                                                                              'callback_data': f"pg;{self.type_btn};{num_prev_page}"}]]}
                                          )
        return


async def callbackquery_process(update: Update, context: CallbackContext) -> None:
    # write_on_file("callbackquery_process.txt",str(update))
    try:
        bot = context.bot
        query = update.callback_query
        from_id = query.from_user.id
        chat_id = query.message.chat.id
        chat_type = query.message.chat.type
        data = query.data
        ex_data = data.split(';')
    except:
        pass
    timestamp = int(time.time())
    try:
        if data == "test":
            return
        mydb = mysql.connector.connect(host=utl.host_db, database=utl.database, user=utl.user_db, passwd=utl.passwd_db,
                                       charset="utf8mb4", auth_plugin='mysql_native_password')
        cs = mydb.cursor(dictionary=True, buffered=True)
        cs.execute(f"SELECT * FROM {utl.admini}")
        row_admin = cs.fetchone()
        if ex_data[0] == 'pg':
            if ex_data[1] == 'accounts':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.mbots} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    if row['status'] == 'restrict':
                        output += f"{i}. شماره: <code>{row['phone']}</code>\n"
                        output += f"⛔ محدودیت: ({utl.convert_time(row['end_restrict'] - timestamp)})\n"
                    else:
                        output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت ها:\n\n" + output + "ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots}")
                ob = Pagination(update, "accounts", output, step_page, cs.rowcount)
                await ob.processCallback()
                return
            if ex_data[1] == 'restrict':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(
                    f"SELECT * FROM {utl.mbots} WHERE status='restrict' ORDER BY end_restrict ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code>\n"
                    output += f"⛔ محدودیت: ({utl.convert_time(row['end_restrict'] - timestamp)})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های محدود شده:\n\n" + output + "ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='restrict'")
                ob = Pagination(update, "restrict", output, step_page, cs.rowcount)
                await ob.processCallback()
                return
            if ex_data[1] == 'first_level':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(
                    f"SELECT * FROM {utl.mbots} WHERE status='first_level' ORDER BY id ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های ثبت نشده:\n\n" + output + "ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='first_level'")
                ob = Pagination(update, "first_level", output, step_page, cs.rowcount)
                await ob.processCallback()
                return
            if ex_data[1] == 'submitted':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(
                    f"SELECT * FROM {utl.mbots} WHERE status='submitted' ORDER BY last_order_at ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های فعال:\n\n" + output + "ـــــــــــــــــــــــــــــــ"
                cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted'")
                ob = Pagination(update, "submitted", output, step_page, cs.rowcount)
                await ob.processCallback()
                return
            if ex_data[1] == 'adability':
                limit_per_h = row_admin['limit_per_h'] * 3600
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(
                    f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. شماره: <code>{row['phone']}</code> ({utl.status_mbots[row['status']]})\n"
                    output += f"🔸️ بررسی: /status_{row['id']}\n\n"
                    i += 1
                output = "پنل ادمین » اکانت های با قلبیت اد:\n\n" + output + "ـــــــــــــــــــــــــــــــ"
                cs.execute(
                    f"SELECT id FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp}")
                ob = Pagination(update, "adability", output, step_page, cs.rowcount)
                await ob.processCallback()
                return
            if ex_data[1] == 'orders':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.gtg} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    await query.answer("❌ لیست خالی است", show_alert=True)
                    return
                output = ""
                for row in result:
                    created_at = datetime.datetime.fromtimestamp(row['created_at'])
                    output += f"{i}. /gtg_{row['id']}\n🔹️ گروه مبدا: {row['origin']}\n🔹️ گروه مقصد: {row['destination']}\n🔹️ تعداد ارسال شده/درخواستی: [{row['count']}/{row['count_moved']}]\n🔹️ وضعیت: {utl.status_gtg[row['status']]}\n📅️ ایجاد: {created_at}\n\n"
                    i += 1
                output = "پنل ادمین » سفارشات:\n\n" + output
                cs.execute(f"SELECT id FROM {utl.gtg}")
                ob = Pagination(update, "orders", output, step_page, cs.rowcount)
                await ob.processCallback()
                cs.execute(f"UPDATE {utl.users} SET step='panel',prev_step='panel' WHERE user_id='{from_id}'")
                return
            if ex_data[1] == 'apis':
                selected_pages = (int(ex_data[2]) - 1) * step_page;
                i = selected_pages + 1;
                cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT {selected_pages},{step_page}")
                result = cs.fetchall()
                if not result:
                    return await query.answer("❌ لیست خالی است", show_alert=True)
                output = ""
                for row in result:
                    output += f"{i}. حذف: /dela_{row['id']}\n🔴️ Api ID: <code>{row['api_id']}</code>\n🔴️ Api Hash: <code>{row['api_hash']}</code>\n\n"
                    i += 1
                cs.output = "پنل ادمین » لیست api ها:\n\n" + output
                cs.execute(f"SELECT id FROM {utl.apis}")
                ob = Pagination(update, "apis", output, step_page, cs.rowcount)
                await ob.processCallback()
                cs.execute(f"UPDATE {utl.users} SET step='panel',prev_step='panel' WHERE user_id='{from_id}'")
                return
            return
        if ex_data[0] == 'update' or ex_data[0] == 'change_status':
            gtg_id = int(ex_data[1])
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
            row_gtg = cs.fetchone()
            if row_gtg == None:
                await query.answer("❌ یافت نشد", show_alert=True)
                return
            if ex_data[0] == 'change_status':
                if row_gtg['status'] == 'end':
                    cs.execute(f"SELECT * FROM {utl.gtg} WHERE id NOT IN ('{row_gtg['id']}') AND status='doing'")
                    if cs.fetchone() != None:
                        await query.answer("❌ نمی توان دو سفارش را همزمان در وضعیت در حال انجام قرار داد",
                                           show_alert=True)
                        return
                    row_gtg['status'] = 'doing'
                    cs.execute(f"UPDATE {utl.gtg} SET status='doing' WHERE id={row_gtg['id']}")
                elif row_gtg['status'] == 'doing':
                    row_gtg['status'] = 'end'
                    cs.execute(f"UPDATE {utl.gtg} SET status='end' WHERE id={row_gtg['id']}")

            created_at = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(row_gtg['created_at']))
            updated_at = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(row_gtg['updated_at']))
            now = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(datetime.datetime.now().timestamp()))

            await query.edit_message_text(parse_mode='HTML', disable_web_page_preview=True, text="🔹️ گروه مبدا:\n" +
                                                                                                 f"<code>{row_gtg['origin_id']}</code>\n" +
                                                                                                 f"{row_gtg['origin']}\n" +
                                                                                                 "🔹 گروه مقصد:\n" +
                                                                                                 f"<code>{row_gtg['destination_id']}</code>\n" +
                                                                                                 f"{row_gtg['destination']}\n\n" +
                                                                                                 f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n" +
                                                                                                 f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n" +
                                                                                                 f"\n" +
                                                                                                 f"📅️ ایجاد: {created_at}\n" +
                                                                                                 f"📅️ بروزرسانی: {updated_at}\n" +
                                                                                                 f"📅️ الان: {now}",
                                          reply_markup={'inline_keyboard': [
                                              [{'text': utl.status_gtg[row_gtg['status']],
                                                'callback_data': f"change_status;{row_gtg['id']}"}],
                                              [{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}]
                                          ]}
                                          )
            return
    except RetryAfter as e:
        await query.answer("−⚠️┈┅━ " + str(int(e.retry_after)) + " ثانیه بعد تلاش کنید!", show_alert=True)


async def private_process(update: Update, context: CallbackContext):
    # write_on_file("private_process.txt",str(update))
    bot = context.bot
    message = update.message
    from_id = message.from_user.id
    first_name = message.from_user.first_name
    username = message.from_user.username
    chat_id = message.chat.id
    message_id = message.message_id
    text = message.text
    if not text:
        text = ""
    ex_text = text.split('_')

    timestamp = int(time.time())
    mydb = mysql.connector.connect(host=utl.host_db, database=utl.database, user=utl.user_db, passwd=utl.passwd_db,
                                   charset="utf8mb4", auth_plugin='mysql_native_password')
    cs = mydb.cursor(dictionary=True, buffered=True)
    cs.execute(f"SELECT * FROM {utl.admini}")
    row_admin = cs.fetchone()

    cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{from_id}'")
    row_user = cs.fetchone()
    if row_user is None:
        cs.execute(
            f"INSERT INTO {utl.users} (user_id,created_at,uniq_id) VALUES ('{from_id}','{timestamp}','{uniq_id_generate(cs, 10, utl.users)}')")
        cs.execute(f"SELECT * FROM {utl.users} WHERE user_id='{from_id}'")
        row_user = cs.fetchone()
    ex_step = row_user['step'].split(';')

    if from_id not in utl.admin_id and row_user['status'] != 'admin':
        return
    if text == 'run':
        system('./job.sh')
        await message.reply_html(text='is running...')
    if text.startswith('terminal_command:'):
        await message.reply_html(text='waiting....')
        system(text.replace('terminal_command:', ''))
        await message.reply_html(text='completed.')
    """if text == '/panel' or text == 'panel' or text == 'پنل' or text == 'بازگشت به پنل ادمین ↪️':
        admin_panel(update, cs)
        cs.execute(f"UPDATE {utl.users} SET step='panel',prev_step='panel' WHERE user_id='{from_id}'")
        return
    if text == "محدودیت چند ساعته":
        await message.reply_html(text="تعداد را وارد کنید:",
                                 reply_markup={'resize_keyboard': True,
                                               'keyboard': [[{'text': 'بازگشت به پنل ادمین ↪️'}]]}
                                 )
        return cs.execute(f"UPDATE {utl.users} SET step='limit_per_h' WHERE user_id='{from_id}'")
    if row_user['step'] == 'limit_per_h':
        try:
            text = int(text)
            if text < 0:
                return await message.reply_html(text="❌ یک عدد بزرگتر از -1 ارسال کنید")
        except:
            return await message.reply_html(text="❌ یک عدد بزرگتر از -1 ارسال کنید")
        cs.execute(f"UPDATE {utl.admini} SET limit_per_h='{text}'")
        await message.reply_html(text="✅ با موفقیت تنظیم شد")
        admin_panel(update, cs)
        return cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
    if text == "اد هر شماره در هر بار استفاده":
        await message.reply_html(
            text="تعداد را وارد کنید:",
            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': 'بازگشت به پنل ادمین ↪️'}]]}
        )
        return cs.execute(f"UPDATE {utl.users} SET step='add_per_h' WHERE user_id='{from_id}'")
    if row_user['step'] == 'add_per_h':
        try:
            text = int(text)
            if text < 5 or text > 100:
                return await message.reply_html(text="❌ یک عدد از 5 تا 100 وارد کنی")
        except:
            return await message.reply_html(text="❌ یک عدد از 5 تا 100 وارد کنی")
        cs.execute(f"UPDATE {utl.admini} SET add_per_h='{text}'")
        await message.reply_html(text="✅ با موفقیت تنظیم شد")
        admin_panel(update, cs)
        return cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
    if text == "هر api چند شماره":
        await message.reply_html(
            text="تعداد را وارد کنید:",
            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': 'بازگشت به پنل ادمین ↪️'}]]}
        )
        return cs.execute(f"UPDATE {utl.users} SET step='api_per_number' WHERE user_id='{from_id}'")
    if row_user['step'] == 'api_per_number':
        try:
            text = int(text)
            if text < 1:
                return await message.reply_html(text="❌ یک عدد بزرگتر از 0 ارسال کنید")
        except:
            return await message.reply_html(text="❌ یک عدد بزرگتر از 0 ارسال کنید")
        cs.execute(f"UPDATE {utl.admini} SET api_per_number='{text}'")
        await message.reply_html(text="✅ با موفقیت تنظیم شد")
        admin_panel(update, cs)
        return cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")"""
    if text == '/start' or text == utl.menu_var:
        await user_panel(update)
        cs.execute(f"UPDATE {utl.users} SET step='start',prev_step='start' WHERE user_id='{from_id}'")
        cs.execute(f"DELETE FROM {utl.gtg} WHERE user_id='{from_id}' AND status='start'")
        return
    if update.message.document and update.message.document.file_name.endswith('.zip'):
        session_file = await update.message.document.get_file()
        await session_file.download_to_drive(f"zip/{update.message.document.file_name}")
        await bot.send_message(chat_id, "در حال استخراج فایل زیپ" + "...")
        import zipfile
        with zipfile.ZipFile(f"zip/{update.message.document.file_name}", 'r') as zip_ref:
            os.mkdir(f"zip/{update.message.document.file_name.replace('.zip', '')}/")
            zip_ref.extractall(f"zip/{update.message.document.file_name.replace('.zip', '')}/")
        await bot.send_message(chat_id, "فایل زیپ استخراج شد.\n\nلطفا صبر کنید...")
        sessions_files = os.listdir(f"zip/{update.message.document.file_name.replace('.zip', '')}/")
        session_files = []
        for session_file in sessions_files:
            if session_file.endswith('.session'):
                session_files.append(session_file)
        for sess_name in session_files:
            flag = False
            info_msg = await message.reply_html(text="در حال بررسی ...")
            cs.execute(f"SELECT * FROM {utl.apis}")
            row_apis = cs.fetchone()
            cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{step_page}")
            result = cs.fetchall()
            if not result:
                await message.reply_html(text="❌ هیچ Api ای یافت نشد")
                flag = True
            else:
                file_path = os.path.join('temp_session/', sess_name)
                shutil.copy(f"zip/{update.message.document.file_name.replace('.zip', '')}/{sess_name}", f"temp_session/{sess_name}")
                try:
                    client = TelegramClient(session=file_path, api_id=row_apis['api_id'], api_hash=row_apis['api_hash'])
                    await client.connect()
                    if not (await client.is_user_authorized()):
                        client.disconnect()
                        os.remove(file_path)
                        await message.reply_html(text="❌ سشن از دست خارج شده است.")
                        flag = True
                    else:
                        me = await client.get_me()
                        if not me.phone:
                            client.disconnect()
                            os.remove(file_path)
                            await message.reply_html(text="❌ مشکلی پیش آمد.")
                            flag = True
                        else:
                            phone = me.phone
                            if text[0:1] == '+':
                                phone = phone[1:]
                            client.disconnect()
                            session_main_file_path = os.path.join("sessions/", f"{phone}.session")
                            if os.path.exists(session_main_file_path) and text != "1":
                                await message.reply_html("❌ فایل از قبل وجود دارد.")
                                flag = True
                            if not flag:
                                if text == "1":
                                    try:
                                        os.remove(session_main_file_path)
                                    except FileNotFoundError:
                                        pass
                                shutil.copyfile(file_path, session_main_file_path)
                                os.remove(file_path)
                except Exception as e:
                    await bot.send_message(chat_id=update.message.chat_id, text=f"مشکلی پیش آمد\nبه نظر می آید سشن خراب است.\n\n{e}")
                else:
                    if not flag:
                        if text[0:1] == '+':
                            phone = phone[1:]
                        phone = phone.replace(" ", "")
                        cs.execute(f"SELECT * FROM {utl.mbots} WHERE phone='{phone}'")
                        row_mbots = cs.fetchone()
                        if row_mbots != None:
                            if row_mbots['creator_user_id'] != str(from_id):
                                await message.reply_html(
                                    text="⛔️ این اکانت قبلا توسط شخص دیگری ثبت شده\n\n" +
                                         "❗️ مراحل ثبت اکانت فقط توسط ثبت کننده اولیه آن می تواند ادامه یابد"
                                )
                                flag = True
                        else:
                            if not flag:
                                if row_apis is None:
                                    return await message.reply_html(text="❌ هیچ Api ای یافت نشد")
                                uniq_id = uniq_id_generate(cs, 10, utl.mbots)
                                cs.execute(
                                    f"INSERT INTO {utl.mbots} (creator_user_id,phone,last_order_at,api_id,api_hash,uniq_id,status) VALUES ('{from_id}','{phone}','0','{row_apis['api_id']}','{row_apis['api_hash']}','{uniq_id}','submitted')")
                                cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{uniq_id}'")
                        if not flag:
                            await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
                            await bot.send_message(chat_id=from_id, text=f"سشن ارسالی با شماره {phone} ثبت شد.")
        shutil.rmtree(f"zip/{update.message.document.file_name.replace('.zip', '')}")
        os.remove(f"zip/{update.message.document.file_name}")
        await bot.send_message(from_id, "عملیات کامل شد.")
    if update.message.document and update.message.document.file_name.endswith('.session'):
        info_msg = await message.reply_html(text="در حال بررسی ...")
        cs.execute(f"SELECT * FROM {utl.apis}")
        row_apis = cs.fetchone()
        cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return await message.reply_html(text="❌ هیچ Api ای یافت نشد")
        file_path = os.path.join('temp_session/', update.message.document.file_name)
        session_file = await update.message.document.get_file()
        await session_file.download_to_drive(file_path)
        try:
            client = TelegramClient(session=file_path, api_id=row_apis['api_id'], api_hash=row_apis['api_hash'])
            await client.connect()
            if not (await client.is_user_authorized()):
                client.disconnect()
                os.remove(file_path)
                return await message.reply_html(text="❌ سشن از دست خارج شده است.")
            me = await client.get_me()
            if not me.phone:
                client.disconnect()
                os.remove(file_path)
                return await message.reply_html(text="❌ مشکلی پیش آمد.")
            phone = me.phone
            if text[0:1] == '+':
                phone = phone[1:]
            client.disconnect()
            session_main_file_path = os.path.join("sessions/", f"{phone}.session")
            if os.path.exists(session_main_file_path) and text != "1":
                return await message.reply_html("❌ فایل از قبل وجود دارد.")
            if text == "1":
                try:
                    os.remove(session_main_file_path)
                except FileNotFoundError:
                    pass
            shutil.copyfile(file_path, session_main_file_path)
            os.remove(file_path)
        except Exception as e:
            return await bot.send_message(chat_id=update.message.chat_id, text=f"مشکلی پیش آمد\nبه نظر می آید سشن خراب است.\n\n{e}")
        if text[0:1] == '+':
            phone = phone[1:]
        phone = phone.replace(" ", "")
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE phone='{phone}'")
        row_mbots = cs.fetchone()
        if row_mbots != None:
            if row_mbots['creator_user_id'] != str(from_id):
                return await message.reply_html(
                    text="⛔️ این اکانت قبلا توسط شخص دیگری ثبت شده\n\n" +
                         "❗️ مراحل ثبت اکانت فقط توسط ثبت کننده اولیه آن می تواند ادامه یابد"
                )
        else:
            if row_apis is None:
                return await message.reply_html(text="❌ هیچ Api ای یافت نشد")
            uniq_id = uniq_id_generate(cs, 10, utl.mbots)
            cs.execute(
                f"INSERT INTO {utl.mbots} (creator_user_id,phone,last_order_at,api_id,api_hash,uniq_id,status) VALUES ('{from_id}','{phone}','0','{row_apis['api_id']}','{row_apis['api_hash']}','{uniq_id}','submitted')")
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{uniq_id}'")

        await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
        return await bot.send_message(chat_id=from_id, text=f"سشن ارسالی با شماره {phone} ثبت شد.")

    if text == '➕ افزودن اکانت':
        cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return await message.reply_html(text="❌ هیچ Api ای یافت نشد")
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE user_id='{from_id}' AND status='first_level'")
        row_mbots = cs.fetchone()
        if row_mbots != None:
            return await message.reply_html(
                text="❌ برخی از شماره های ثبت شده شما در وضعیت اولیه قرار دارند لطفا آن ها را تعیین تکلیف کنید")
        cs.execute(f"UPDATE {utl.users} SET step='add_acc;phone',prev_step='start' WHERE user_id='{from_id}'")
        await message.reply_html(
            text="پنل ادمین » افزودن اکانت » ارسال شماره:",
            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
        )
        return
    if ex_step[0] == 'add_acc':
        if ex_step[1] == 'phone':
            phone = text
            if text[0:1] == '+':
                phone = text[1:]
            phone = phone.replace(" ", "")
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE phone='{phone}'")
            row_mbots = cs.fetchone()
            if row_mbots != None:
                if row_mbots['creator_user_id'] != str(from_id):
                    return await message.reply_html(
                        text="⛔️ این اکانت قبلا توسط شخص دیگری ثبت شده\n\n" +
                             "❗️ مراحل ثبت اکانت فقط توسط ثبت کننده اولیه آن می تواند ادامه یابد"
                    )
            else:
                cs.execute(f"SELECT * FROM {utl.apis}")
                row_apis = cs.fetchone()
                if row_apis is None:
                    return await message.reply_html(text="❌ هیچ Api ای یافت نشد")
                uniq_id = uniq_id_generate(cs, 10, utl.mbots)
                cs.execute(
                    f"INSERT INTO {utl.mbots} (creator_user_id,phone,last_order_at,api_id,api_hash,uniq_id) VALUES ('{from_id}','{phone}','0','{row_apis['api_id']}','{row_apis['api_hash']}','{uniq_id}')")
                cs.execute(f"SELECT * FROM {utl.mbots} WHERE uniq_id='{uniq_id}'")
                row_mbots = cs.fetchone()
            info_msg = await message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.account.py {from_id} first_level {row_mbots['id']}")
            await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
            return
        if ex_step[1] == 'code':
            mbots_id = int(ex_step[2])
            cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
            row_mbots = cs.fetchone()
            try:
                ex_nl_text = text.split("\n")
                if len(ex_nl_text[0]) > 200 or len(ex_nl_text[1]) > 200:
                    return await message.reply_html(text="❌ ورودی نادرست")
                cs.execute(
                    f"UPDATE {utl.mbots} SET code='{ex_nl_text[0]}',password='{ex_nl_text[1]}' WHERE id={row_mbots['id']}")
            except:
                cs.execute(f"UPDATE {utl.mbots} SET code='{text}' WHERE id={row_mbots['id']}")
            info_msg = await message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.account.py {from_id} code {row_mbots['id']}")
            await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
            return await user_panel(update)
    if text == '➕ ایجاد سفارش':
        cs.execute(f"SELECT * FROM {utl.gtg} WHERE status='doing'")
        row_gtg = cs.fetchone()
        if row_gtg != None:
            return await message.reply_html(text="❌ یک سفارش در حال انجام است")
        #limit_per_h = row_admin['limit_per_h'] * 3600
        limit_per_h = 0
        cs.execute(
            f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC")
        if cs.fetchone() == None:
            return await message.reply_html(text="❌ اکانتی برای انجام سفارش یافت نشد")
        cs.execute(f"UPDATE {utl.users} SET step='create_order;info',prev_step='start' WHERE user_id='{from_id}'")
        return await message.reply_html(disable_web_page_preview=True,
                                        text="پنل ادمین » ایجاد سفارش » ارسال اطلاعات:\n\n" +
                                             "اطلاعات را به این شکل و در سه خط ارسال کنید:\n" +
                                             "لینک گروه مبدا\n" +
                                             "لینک گروه مقصد\n" +
                                             "تعداد اعضا برای انتقال\n\n" +
                                             "مثال:\n" +
                                             "https://t.me/source\n" +
                                             "https://t.me/target\n" +
                                             "500\n" +
                                             "\n" +
                                             "❗️ اعضای گروه مبدا به گروه مقصد منتقل می شوند",
                                        reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
                                        )
    if ex_step[0] == 'create_order':
        if ex_step[1] == 'info':
            try:
                ex_nl_text = text.split("\n")
                source = ex_nl_text[0].replace("/+", "/joinchat/")
                target = ex_nl_text[1].replace("/+", "/joinchat/")
                count = int(ex_nl_text[2])
                ex_nl_text = text.split("\n")
                if len(source) > 200 or len(target) > 200 or len(ex_nl_text) != 3:
                    return await message.reply_html(text="❌ مقادیر نامعتبر")
                if source[0:13] != "https://t.me/":
                    return await message.reply_html(text="❌ گروه مبدا غیر معتبر")
                if target[0:13] != "https://t.me/":
                    return await message.reply_html(text="❌ گروه مقصد غیر معتبر")
            except:
                return await message.reply_html(text="❌ طبق نمونه ارسال کنید")
            uniq_id = uniq_id_generate(cs, 10, utl.gtg)

            cs.execute(
                f"INSERT INTO {utl.gtg} (user_id,origin,destination,count,created_at,updated_at,uniq_id) VALUES ('{from_id}','{source}','{target}','{count}','{timestamp}','{timestamp}','{uniq_id}')")
            cs.execute(f"SELECT * FROM {utl.gtg} WHERE uniq_id='{uniq_id}'")
            row_gtg = cs.fetchone()
            cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")

            info_msg = await message.reply_html(text="در حال بررسی ...")
            os.system(f"python3 tl.analyze.py {from_id} check {row_gtg['id']}")
            await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
            return
        if ex_step[1] == 'type_users':
            type_users = ""
            if text == 'کاربران واقعی':
                type_users = 'users'
            elif text == 'کاربران فیک':
                type_users = 'users_fake'
            elif text == 'کاربران آنلاین':
                type_users = 'users_online'
            elif text == "تفکیکی (همه ی کاربران)":
                type_users = "users"

            cs.execute(f"SELECT * FROM {utl.gtg} WHERE user_id='{from_id}' AND status='start'")
            row_gtg = cs.fetchone()

            cs.execute(
                f"SELECT * FROM {utl.gtg} WHERE origin_id='{row_gtg['origin_id']}' AND destination_id='{row_gtg['destination_id']}' AND status='end' ORDER BY id DESC")
            row_gtg_check = cs.fetchone()
            if row_gtg_check != None and row_gtg_check['type_users'] == type_users:
                cs.execute(
                    f"UPDATE {utl.gtg} SET last_member_check='{row_gtg_check['last_member_check']}' WHERE id={row_gtg['id']}");

            with open(f"export/{row_gtg['origin_id']}/{type_users}.json", "r") as file:
                max_users = len(json.loads(file.read()))
            cs.execute(
                f"UPDATE {utl.gtg} SET status='doing',max_users='{max_users}',type_users='{type_users}' WHERE id={row_gtg['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
            await message.reply_html(
                text=f"✅ سفارش با موفقیت ثبت شد و در حال انجام است /gtg_{row_gtg['id']}",
                reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
            )
            return
    if text == '🔮 آنالیز گروه 🔮':
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted'")
        if cs.fetchone() == None:
            return await message.reply_html(text="❌ اکانتی برای انجام سفارش یافت نشد")
        await message.reply_html(
            text="پنل ادمین » آنالیز گروه » ارسال لینک:\n\n" +
                 "❗️ لینک عضویت دائمی گروه را وارد کنید نه لینک موقت تولید شده توسط ربات ها",
            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
        )
        return cs.execute(f"UPDATE {utl.users} SET step='analyze;',prev_step='start' WHERE user_id='{from_id}'")
    if ex_step[0] == 'analyze':
        uniq_id = uniq_id_generate(cs, 10, utl.egroup)
        text = text.replace("/+", "/joinchat/")
        cs.execute(
            f"INSERT INTO {utl.egroup} (user_id,link,created_at,updated_at,uniq_id) VALUES ({from_id},'{text}','{timestamp}','{timestamp}','{uniq_id}')")
        cs.execute(f"SELECT * FROM {utl.egroup} WHERE uniq_id='{uniq_id}'")
        row_egroup = cs.fetchone()
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")

        info_msg = await message.reply_html(text="در حال بررسی ...")
        os.system(f"python3 tl.analyze.py {from_id} analyze {row_egroup['id']}")
        await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
        await bot.delete_message(chat_id=from_id, message_id=message_id)
        return
    if text == '➕ افزودن api':
        cs.execute(f"UPDATE {utl.users} SET step='add_api;',prev_step='start' WHERE user_id='{from_id}'")
        return await message.reply_html(
            text="پنل ادمین » افزودن api » ارسال اطلاعات:\n\n" +
                 "اطلاعات را به این شکل و در دو خط ارسال کنید:\n" +
                 "api id\n" +
                 "api hash",
            reply_markup={'resize_keyboard': True, 'keyboard': [[{'text': utl.menu_var}]]}
        )
    if ex_step[0] == 'add_api':
        try:
            ex_nl_text = text.split("\n")
            if len(ex_nl_text[0]) > 200 or len(ex_nl_text[1]) > 200 or len(ex_nl_text) != 2:
                return await message.reply_html(text="❌ ورودی نادرست")
            api_id = ex_nl_text[0]
            api_hash = ex_nl_text[1]
        except:
            return await message.reply_html(text="❌ طبق نمونه ارسال کنید")
        cs.execute(f"SELECT * FROM {utl.apis} WHERE api_id='{api_id}' OR api_hash='{api_hash}'")
        if cs.fetchone() is not None:
            return await message.reply_html(text="❌ این api قبلا ثبت شده")
        cs.execute(f"INSERT INTO {utl.apis} (api_id,api_hash) VALUES ('{api_id}','{api_hash}')")
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        await message.reply_html(text="✅ با موفقیت افزوده شد")
        return await user_panel(update)

    if text == '📊 آمار 📊':
        now = jdatetime.datetime.now()
        time_today = jdatetime.datetime(day=now.day, month=now.month, year=now.year).timestamp()
        time_yesterday = time_today - 86400

        cs.execute(f"SELECT id FROM {utl.gtg}")
        orders_count_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.gtg} WHERE created_at>={time_today}")
        orders_count_today = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.gtg} WHERE created_at<{time_today} AND created_at>={time_yesterday}")
        orders_count_yesterday = cs.rowcount

        cs.execute(f"SELECT id FROM {utl.moveds}")
        orders_count_moved_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.moveds} WHERE created_at>={time_today}")
        orders_count_moved_today = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.moveds} WHERE created_at<{time_today} AND created_at>={time_yesterday}")
        orders_count_moved_yesterday = cs.rowcount

        cs.execute(f"SELECT id FROM {utl.mbots}")
        accs_all = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted'")
        accs_active = cs.rowcount
        limit_per_h = row_admin['limit_per_h'] * 3600
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp}")
        accs_ability_ad = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='restrict'")
        accs_restrict = cs.rowcount
        cs.execute(f"SELECT id FROM {utl.mbots} WHERE status='first_level'")
        accs_first_level = cs.rowcount

        cs.execute(f"SELECT id FROM {utl.apis}")
        apis_count_all = cs.rowcount
        return await message.reply_html(text="پنل ادمین » آمار:\n\n" +
                                             "🔘 سفارشات:\n" +
                                             f"🟢 امروز: {orders_count_today} ({orders_count_moved_today:,})\n" +
                                             f"🟢 دیروز: {orders_count_yesterday} ({orders_count_moved_yesterday:,})\n" +
                                             f"🟢 کل: {orders_count_all} ({orders_count_moved_all:,})\n\n" +
                                             "🔘 اکانت ها:\n" +
                                             f"🔴️ کل: {accs_all}\n" +
                                             f"🔴 فعال: {accs_active}\n" +
                                             f"🔴️ قابلیت اد: {accs_ability_ad}\n" +
                                             f"🔴 محدود شده: {accs_restrict}\n" +
                                             f"🔴 ثبت نشد: {accs_first_level}\n\n" +
                                             f"🔘 تعداد api ها: {apis_count_all}"
                                        )
    if text == '📋 سفارشات':
        cs.execute(f"SELECT * FROM {utl.gtg} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return await message.reply_html(text="❌ لیست خالی است")
        output = ""
        i = 1
        for row in result:
            created_at = datetime.datetime.fromtimestamp(row['created_at'])
            output += f"{i}. /gtg_{row['id']}\n🔹️ گروه مبدا: {row['origin']}\n🔹️ گروه مقصد: {row['destination']}\n🔹️ تعداد ارسال شده/درخواستی: [{row['count']}/{row['count_moved']}]\n🔹️ وضعیت: {utl.status_gtg[row['status']]}\n📅️ ایجاد: {created_at}\n\n"
            i += 1
        output = "پنل ادمین » سفارشات:\n\n" + output
        cs.execute(f"SELECT id FROM {utl.gtg}")
        ob = Pagination(update, "orders", output, step_page, cs.rowcount)
        await ob.processMessage()
        cs.execute(f"UPDATE {utl.users} SET step='start',prev_step='start' WHERE user_id='{from_id}'")
        return
    if text == '📋 اکانت ها':
        cs.execute(f"SELECT * FROM {utl.mbots} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return await message.reply_html(text="❌ لیست خالی است")
        return await message.reply_html(
            text="پنل ادمین » اکانت ها:",
            reply_markup={'inline_keyboard': [
                [
                    {'text': "💢 همه 💢", 'callback_data': f"pg;accounts;1"},
                ],
                [
                    {'text': "⛔️ ثبت نشده", 'callback_data': f"pg;first_level;1"},
                    {'text': "❌ محدود شده", 'callback_data': f"pg;restrict;1"}
                ],
                [
                    {'text': "♻️ قابلیت اد", 'callback_data': f"pg;adability;1"},
                    {'text': "✅ فعال", 'callback_data': f"pg;submitted;1"}
                ]
            ]}
        )
    if text == '📋 لیست api ها':
        cs.execute(f"SELECT * FROM {utl.apis} ORDER BY id DESC LIMIT 0,{step_page}")
        result = cs.fetchall()
        if not result:
            return await message.reply_html(text="❌ لیست خالی است")
        output = ""
        i = 1
        for row in result:
            output += f"{i}. حذف: /dela_{row['id']}\n🔴️ Api ID: <code>{row['api_id']}</code>\n🔴️ Api Hash: <code>{row['api_hash']}</code>\n\n"
            i += 1
        output = "پنل ادمین » لیست api ها:\n\n" + output
        cs.execute(f"SELECT id FROM {utl.apis}")
        ob = Pagination(update, "apis", output, step_page, cs.rowcount)
        await ob.processMessage()
        cs.execute(f"UPDATE {utl.users} SET step='start',prev_step='start' WHERE user_id='{from_id}'")
        return
    if ex_text[0] == '/gtg':
        gtg_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={gtg_id}")
        row_gtg = cs.fetchone()
        if row_gtg == None:
            return await message.reply_html(text="❌ یافت نشد")
        created_at = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(row_gtg['created_at']))
        updated_at = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(row_gtg['updated_at']))
        now = time.strftime('%Y/%m/%d ساعت %H:%M:%S', time.localtime(datetime.datetime.now().timestamp()))
        return await message.reply_html(disable_web_page_preview=True,
                                        text="🔹️ گروه مبدا:\n" +
                                             f"<code>{row_gtg['origin_id']}</code>\n" +
                                             f"{row_gtg['origin']}\n" +
                                             "🔹 گروه مقصد:\n" +
                                             f"<code>{row_gtg['destination_id']}</code>\n" +
                                             f"{row_gtg['destination']}\n\n" +
                                             f"👤 اعضای ارسال شده/درخواستی: [{row_gtg['count']}/{row_gtg['count_moved']}]\n" +
                                             f"👤 اعضای در حال بررسی/کل: [{row_gtg['max_users']}/{row_gtg['last_member_check']}]\n" +
                                             f"\n" +
                                             f"📅️ ایجاد: {created_at}\n" +
                                             f"📅️ بروزرسانی: {updated_at}\n" +
                                             f"📅️ الان: {now}",
                                        reply_markup={'inline_keyboard': [
                                            [{'text': utl.status_gtg[row_gtg['status']],
                                              'callback_data': f"change_status;{row_gtg['id']}"}],
                                            [{'text': '🔄 بروزرسانی 🔄', 'callback_data': f"update;{row_gtg['id']}"}]
                                        ]}
                                        )
    if ex_text[0] == '/status':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return await message.reply_html(text="❌ یافت نشد")
        info_msg = await message.reply_html(text="در حال بررسی ...")
        os.system(f"python3 tl.account.py {from_id} check {row_mbots['id']}")
        cs.execute(f"UPDATE {utl.users} SET step='start' WHERE user_id='{from_id}'")
        await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
        return await message.reply_html(text=f"حذف اکانت: /delete_{row_mbots['id']}")
    if ex_text[0] == '/delete':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return await message.reply_html(text="❌ یافت نشد")
        return await message.reply_html(
            reply_to_message_id=message_id,
            text=f"❌ حذف اکانت: {row_mbots['phone']}\n\n" +
                 f"/deleteconfirm_{ex_text[1]}"
        )
    if ex_text[0] == '/deleteconfirm':
        mbots_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbots_id}")
        row_mbots = cs.fetchone()
        if row_mbots is None:
            return await message.reply_html(text="❌ یافت نشد")
        try:
            cs.execute(f"DELETE FROM {utl.mbots} WHERE id={row_mbots['id']}")
            os.remove(f"{directory}/sessions/{row_mbots['phone']}.session")
        except:
            pass
        return await message.reply_html(text=f"✅ با موفقیت حذف شد")
    if ex_text[0] == '/ex':
        egroup_id = int(ex_text[2])
        cs.execute(f"SELECT * FROM {utl.egroup} WHERE id={egroup_id}")
        row_egroup = cs.fetchone()
        if row_egroup == None:
            return await message.reply_html(text="❌ یافت نشد")
        info_msg = await message.reply_html(text="در حال ارسال ...")
        if ex_text[1] == 'u':
            await bot.send_document(chat_id=chat_id,
                                    document=open(f"{directory}/export/{row_egroup['chat_id']}/users.json", "rb"),
                                    caption='کاربران شناسایی شده (واقعی)')
        elif ex_text[1] == 'f':
            await bot.send_document(chat_id=chat_id,
                                    document=open(f"{directory}/export/{row_egroup['chat_id']}/users_fake.json", "rb"),
                                    caption='کاربران شناسایی شده (فیک)')
        elif ex_text[1] == 'n':
            await bot.send_document(chat_id=chat_id,
                                    document=open(f"{directory}/export/{row_egroup['chat_id']}/users_has_phone.json",
                                                  "rb"), caption='کاربران شناسایی شده (دارای شماره)')
        elif ex_text[1] == 'o':
            await bot.send_document(chat_id=chat_id,
                                    document=open(f"{directory}/export/{row_egroup['chat_id']}/users_online.json",
                                                  "rb"), caption='کاربران شناسایی شده (آنلاین)')
        await bot.delete_message(chat_id=from_id, message_id=info_msg.message_id)
        return await bot.delete_message(chat_id=from_id, message_id=message_id)
    if ex_text[0] == '/dela':
        apis_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.apis} WHERE id={apis_id}")
        row_apis = cs.fetchone()
        if row_apis is None:
            return await message.reply_html(text="❌ یافت نشد")
        return await message.reply_html(
            reply_to_message_id=message_id,
            text=f"❌ حذف ای پی ای: {row_apis['api_id']}\n\n" +
                 f"/delaconfirm_{ex_text[1]}"
        )
    if ex_text[0] == '/delaconfirm':
        apis_id = int(ex_text[1])
        cs.execute(f"SELECT * FROM {utl.apis} WHERE id={apis_id}")
        row_apis = cs.fetchone()
        if row_apis is None:
            return await message.reply_html(text="❌ یافت نشد")
        cs.execute(f"DELETE FROM {utl.apis} WHERE id={row_apis['id']}")
        return await message.reply_html(text=f"✅ با موفقیت حذف شد")


async def main() -> None:
    """
    updater_q = queue()
    updater = Updater(utl.token, updater_q)
    dispatcher = updater.dispatcher
    """
    try:
        application = Application.builder().token(utl.token).build()
        dispatcher = application

        dispatcher.add_handler(MessageHandler(None, private_process))
        dispatcher.add_handler(CallbackQueryHandler(callbackquery_process))

        # updater.start_polling(drop_pending_updates=True)
        await application.run_polling()
    except Exception as e:
        if os.path.exists("errors.txt"):
            with open("errors.txt", "at") as f:
                f.write(str(e))
        else:
            with open("errors.txt", "wt") as f:
                f.write(str(e))


if __name__ == '__main__':
    asyncio.run(main())
