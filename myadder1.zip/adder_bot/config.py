admin_id = [274335070, 7404775375]
token = "7108475480:AAGsBr47XD7uky2jxVPN9yULhmqngpL1s4Y"
host_db = 'localhost'
database = 'adder_bot_db'
user_db = 'root'
passwd_db = 'linux7563_def'
