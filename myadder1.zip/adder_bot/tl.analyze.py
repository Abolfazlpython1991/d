#!/usr/bin/env python3

import os
import sys
import time
import json
import math
import mysql.connector
from telethon.sync import TelegramClient
from telethon import types, functions, errors
import utility as utl
import asyncio

for index, arg in enumerate(sys.argv):
    if index == 1:
        from_id = arg
    elif index == 2:
        status = arg
    elif index == 3:
        table_id = arg
if len(sys.argv) != 4:
    print("Invalid parameters!")
    exit()

directory = os.path.dirname(os.path.abspath(__file__))
timestamp = int(time.time())
mydb = mysql.connector.connect(host = utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4",auth_plugin='mysql_native_password')
cs = mydb.cursor(dictionary=True,buffered=True)

cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='submitted' ORDER BY RAND()")
row_mbots = cs.fetchone()

async def main():
    client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}", api_id=row_mbots['api_id'], api_hash=row_mbots['api_hash'])
    await client.connect()
    if not await client.is_user_authorized():
        cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
        await utl.bot.send_message(chat_id=from_id,parse_mode='HTML',text=f"⛔️ اکانت /status_{row_mbots['id']} (<code>{row_mbots['id']}</code>) از دسترس خارج شد.")
    else:
        try:
            if status == 'check':
                cs.execute(f"SELECT * FROM {utl.gtg} WHERE id='{table_id}'")
                row_gtg = cs.fetchone()
                try:
                    result = await client(functions.channels.GetFullChannelRequest(channel=row_gtg['origin']))
                    chat_id = int(f"-100{result.full_chat.id}")
                except Exception as e:
                    try:
                        if "/joinchat/" in row_gtg['origin']:
                            hash_ = row_gtg['origin'].split("/joinchat/")[1]
                            await client(functions.messages.ImportChatInviteRequest(hash_))
                        else:
                            await client(functions.channels.JoinChannelRequest(channel=row_gtg['origin']))
                        result = await client(functions.channels.GetFullChannelRequest(channel=row_gtg['origin']))
                        chat_id = int(f"-100{result.full_chat.id}")
                    except Exception as e:
                        print(e)
                        await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی در شاناسایی گروه مبدا پیش آمده")
                        await client.disconnect()
                        exit()
                cs.execute(f"UPDATE {utl.gtg} SET origin_id='{chat_id}' WHERE id='{row_gtg['id']}'")
                cs.execute(f"SELECT * FROM {utl.egroup} WHERE chat_id='{chat_id}'")
                if cs.fetchone() is None:
                    await utl.bot.send_message(chat_id=from_id,text="❌ شما هنوز گروه مبدا را آنالیز نکرده اید")
                else:
                    try:
                        result = await client(functions.channels.GetFullChannelRequest(channel=row_gtg['destination']))
                        chat_id = int(f"-100{result.full_chat.id}")
                    except Exception as e:
                        try:
                            if "/joinchat/" in row_gtg['destination']:
                                hash_ = row_gtg['destination'].split("/joinchat/")[1]
                                await client(functions.messages.ImportChatInviteRequest(hash_))
                            elif "t.me/+" in row_gtg['destination']:
                                hash_ = row_gtg['destination'].split("t.me/+")[1]
                                await client(functions.messages.ImportChatInviteRequest(hash_))
                            else:
                                await client(functions.channels.JoinChannelRequest(channel=row_gtg['destination']))
                            result = await client(functions.channels.GetFullChannelRequest(channel=row_gtg['destination']))
                            chat_id = int(f"-100{result.full_chat.id}")
                            
                        except Exception as e:
                            print(e)
                            await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی در شاناسایی گروه مقصد پیش آمده")
                    cs.execute(f"UPDATE {utl.gtg} SET destination_id='{chat_id}' WHERE id='{row_gtg['id']}'")
                    cs.execute(f"UPDATE {utl.users} SET step='create_order;type_users' WHERE user_id='{from_id}'")
                    await utl.bot.send_message(chat_id=from_id,text="پنل ادمین » ایجاد سفارش » نوع کاربران:\n\n"+
                        "❕ کاربران واقعی شامل کاربران آنلاین هم می شوند",
                        reply_markup={'resize_keyboard': True,'keyboard': [
                            [{'text': 'کاربران واقعی'}],
                            [{'text': 'کاربران فیک'}],
                            [{'text': 'کاربران آنلاین'}],
                            [{"text": "تفکیکی (همه ی کاربران)"}],
                            [{'text': utl.back_var},{'text': utl.menu_var}]
                        ]}
                    )
            elif status == 'analyze':
                cs.execute(f"SELECT * FROM {utl.egroup} WHERE id='{table_id}'")
                row_egroup = cs.fetchone()
                info_msg = await utl.bot.send_message(chat_id=from_id,text="در حال آنالیز ...")
                try:
                    link = row_egroup['link'].replace("/+","/joinchat/")
                    result = await client(functions.channels.GetFullChannelRequest(channel=link))
                    chat_id = int(f"-100{result.full_chat.id}")
                    participants_count = result.full_chat.participants_count
                    online_count = result.full_chat.online_count
                except Exception as e:
                    print(e)
                    try:
                        if "/joinchat/" in link:
                            hash_ = link.split("/joinchat/")[1]
                            await client(functions.messages.ImportChatInviteRequest(hash_))
                        else:
                            await client(functions.channels.JoinChannelRequest(channel=link))
                        result = await client(functions.channels.GetFullChannelRequest(channel=link))
                        chat_id = int(f"-100{result.full_chat.id}")
                        participants_count = result.full_chat.participants_count
                        online_count = result.full_chat.online_count
                    except Exception as e:
                        print(e)
                        await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی در عضو شدن اکانت در گروه پیش آمد")
                        await utl.bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
                        await client.disconnect()
                        exit()
                
                cs.execute(f"UPDATE {utl.egroup} SET chat_id='{chat_id}' WHERE id='{row_egroup['id']}'")
                queryKey = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
                participants_all = []
                participants_fake = []
                participants_has_phone = []
                participants_online = []
                i = 1
                percent = j = 0
                for key in queryKey:
                    offset = 0
                    limit = 100
                    # print(f"start: {key}")
                    while True:
                        participants = await client(functions.channels.GetParticipantsRequest(chat_id,types.ChannelParticipantsSearch(key),offset,limit,hash=0))
                        if not participants.users:
                            break
                        for user in participants.users:
                            try:
                                if user.username:
                                    username = "@"+user.username
                                    if isinstance(user.status, types.UserStatusRecently) or isinstance(user.status, types.UserStatusOnline) or (isinstance(user.status, types.UserStatusOffline) and (timestamp - user.status.was_online.timestamp()) < 259200):
                                        if not username in participants_all:
                                            participants_all.append(username)
                                    else:
                                        if not username in participants_fake:
                                            participants_fake.append(username)
                                    if isinstance(user.status, types.UserStatusOnline): # or (isinstance(user.status, types.UserStatusOffline) and (timestamp - user.status.was_online.timestamp()) < 1800):
                                        if not username in participants_online:
                                            participants_online.append(username)
                                if user.phone:
                                    if not user.phone in participants_has_phone:
                                        participants_has_phone.append(user.phone)
                            except Exception as e:
                                # print(str(e))
                                pass
                        offset += len(participants.users)
                        count = len(participants_all)
                        # print(f"{key}: {count}")
                        if j % 10 == 0:
                            try:
                                await utl.bot.edit_message_text(chat_id=from_id,message_id=info_msg.message_id,text=f"در حال آنالیز {percent}%\nاعضای شناسایی شده: {count}\n‏")
                            except:
                                pass
                        # print("##############")
                        j += 1
                    percent = math.ceil((i / 26) * 100)
                    i += 1
                operation_time = int(time.time()) - timestamp;
                try:
                    os.mkdir(f"export/{chat_id}")
                except:
                    pass
                with open(f"export/{chat_id}/users.json", 'w') as file:
                    file.write(json.dumps(participants_all))
                with open(f"export/{chat_id}/users_fake.json", 'w') as file:
                    file.write(json.dumps(participants_fake))
                with open(f"export/{chat_id}/users_has_phone.json", 'w') as file:
                    file.write(json.dumps(participants_has_phone))
                with open(f"export/{chat_id}/users_online.json", 'w') as file:
                    file.write(json.dumps(participants_online))
                users = len(participants_all)
                users_fake = len(participants_fake)
                users_has_phone = len(participants_has_phone)
                users_online = len(participants_online)
                
                cs.execute(f"UPDATE {utl.egroup} SET status='end',users='{users}',users_has_phone='{users_has_phone}',users_online='{users_online}' WHERE id='{row_egroup['id']}'")
                await utl.bot.send_message(chat_id=from_id,parse_mode='HTML',disable_web_page_preview=True,text=f"🔻 شناسه: <code>{chat_id}</code>\n"+
                    f"🔻 لینک: {row_egroup['link']}\n"+
                    f"🔻 کل کاربران: {participants_count}\n"+
                    f"🔻 کاربران آنلاین: {online_count}\n"+
                    # f"🔻 ربات ها: {bots_count}\n"+
                    "‏————————————————————\n"+
                    "♻️ کاربران شناسایی شده:\n"+
                    f"🔻 کاربران واقعی: {users} (/ex_u_{row_egroup['id']})\n"+
                    f"🔻 کاربران فیک: {users_fake} (/ex_f_{row_egroup['id']})\n"+
                    f"🔻 کاربران داری شماره: {users_has_phone} (/ex_n_{row_egroup['id']})\n"+
                    f"🔻 کاربران آنلاین: {users_online} (/ex_o_{row_egroup['id']})\n\n"+
                    "‼️ اگر روی دکمه های داخل پرانتز کلیک کنید خروجی اون کاربر هارو بهت میدم.\n"+
                    "‼️ اعضای فیک تفکیک شده اند.\n"+
                    f"⏰ مدت زمان: {operation_time} ثانیه\n‏"
                )
                await utl.bot.delete_message(chat_id=from_id,message_id=info_msg.message_id)
        except Exception as e:
            print(e)
        try:
            await client.disconnect()
        except:
            pass


if __name__ == '__main__':
    asyncio.run(main())


