CREATE TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon` (
  `id` int(11) NOT NULL,
  `api_per_number` int(11) NOT NULL DEFAULT 10,
  `limit_per_h` int(11) NOT NULL DEFAULT 24,
  `add_per_h` int(11) NOT NULL DEFAULT 20
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
--

INSERT INTO `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon` (`id`, `api_per_number`, `limit_per_h`, `add_per_h`) VALUES
(1, 1, 24, 28);

-- --------------------------------------------------------

--
-- Table structure for table `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
--

CREATE TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU` (
  `id` int(11) NOT NULL,
  `api_id` varchar(20) NOT NULL,
  `api_hash` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
--

CREATE TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq` (
  `id` int(11) NOT NULL,
  `user_id` varchar(30) NOT NULL,
  `chat_id` varchar(30) DEFAULT NULL,
  `link` varchar(200) NOT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'start',
  `users` int(11) NOT NULL DEFAULT 0,
  `users_has_phone` int(11) NOT NULL DEFAULT 0,
  `users_online` int(11) NOT NULL DEFAULT 0,
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
--

CREATE TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `origin` varchar(200) NOT NULL,
  `origin_id` varchar(20) NOT NULL DEFAULT '0',
  `destination` varchar(200) DEFAULT NULL,
  `destination_id` varchar(20) NOT NULL DEFAULT '0',
  `count` int(11) NOT NULL DEFAULT 0,
  `count_moved` int(11) NOT NULL DEFAULT 0,
  `last_bot_check` int(11) NOT NULL DEFAULT 0,
  `last_member_check` int(11) NOT NULL DEFAULT 0,
  `max_users` int(11) NOT NULL DEFAULT 0,
  `type_users` varchar(50) DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'start',
  `created_at` int(11) NOT NULL DEFAULT 0,
  `updated_at` int(11) NOT NULL DEFAULT 0,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
--

CREATE TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4` (
  `id` int(11) NOT NULL,
  `creator_user_id` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `user_id` varchar(20) DEFAULT NULL,
  `end_restrict` int(11) NOT NULL DEFAULT 0,
  `status` varchar(50) NOT NULL DEFAULT 'first_level',
  `last_order_at` int(11) NOT NULL DEFAULT 0,
  `api_id` varchar(20) NOT NULL,
  `api_hash` varchar(200) NOT NULL,
  `phone_code_hash` varchar(100) DEFAULT NULL,
  `code` int(11) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
--

CREATE TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO` (
  `id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `origin_id` varchar(30) NOT NULL,
  `destination_id` varchar(30) NOT NULL,
  `created_at` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec`
--

CREATE TABLE `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec` (
  `id` int(11) NOT NULL,
  `gtg_id` int(11) NOT NULL,
  `bot_id` int(11) NOT NULL,
  `created_at` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
--

CREATE TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379` (
  `id` int(11) NOT NULL,
  `user_id` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'user',
  `step` varchar(50) NOT NULL DEFAULT 'start',
  `prev_step` varchar(50) NOT NULL DEFAULT 'start',
  `ids_step` varchar(100) DEFAULT 'start',
  `created_at` int(11) NOT NULL,
  `uniq_id` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
--
ALTER TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
--
ALTER TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `api_id` (`api_id`),
  ADD UNIQUE KEY `api_hash` (`api_hash`);

--
-- Indexes for table `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
--
ALTER TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`);

--
-- Indexes for table `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
--
ALTER TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`);

--
-- Indexes for table `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
--
ALTER TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`),
  ADD UNIQUE KEY `phone` (`phone`);

--
-- Indexes for table `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
--
ALTER TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec`
--
ALTER TABLE `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
--
ALTER TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_id` (`uniq_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
--
ALTER TABLE `admin_WCxM3ZShOAtkpFRLUTrsHIDcX84Gon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
--
ALTER TABLE `apis_zyeHAY1fsqBd7NpOjvk0hlaKu2goQU`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
--
ALTER TABLE `export_group_baMc48Pk2381Zndh38Pajd739Cn57Plq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
--
ALTER TABLE `group_to_group_Nchw0128Zn389Xpw429Qpdj38427Tspa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
--
ALTER TABLE `madeline_bots_a28Cnsz83JCn38Pqn849Shg48Wol4`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
--
ALTER TABLE `moveds_21TKjUD7b0xkwAtigXefHzBqNY4lVO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec`
--
ALTER TABLE `report_jYCdi8PB9ZmJG7V4srARyvI2hE0Uec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
--
ALTER TABLE `users_hc137ZnsdyHY38Qpsk47Sj39Palw379`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;
