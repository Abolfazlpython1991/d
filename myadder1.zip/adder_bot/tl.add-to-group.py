#!/usr/bin/env python3

import os
import time
import datetime
import json
import re
import mysql.connector
from telethon.sync import TelegramClient
from telethon import functions, errors
import utility as utl
import asyncio
from telegram import Bot as Bot_tel

directory = os.path.dirname(os.path.abspath(__file__))
filename = str(os.path.basename(__file__))
try:
    with open(f"{directory}/pid/{filename}.txt", "r") as file:
        pid = int(file.read())
    os.kill(pid, 0)
except OSError:
    with open(f"{directory}/pid/{filename}.txt", "w") as file:
        file.write(str(os.getpid()))
else:
    os.system(f"kill -9 {pid}")
    time.sleep(2)
    try:
        os.kill(pid, 0)
    except OSError:
        with open(f"{directory}/pid/{filename}.txt", "w") as file:
            file.write(str(os.getpid()))
    else:
        print("Try again!")
        exit()
print(f"run: {filename}")


def prRed(skk): print("\033[31m {}\033[00m" .format(skk))


async def add_to_group(cs, row_mbots, data, last_member_check, join_number):
    try:
        print(f"row_mbots: {row_mbots}")
        timestamp = int(time.time())
        # cs.execute(f"SELECT `day_add` FROM {utl.status_mbots} WHERE `id` = '{row_mbots['id']}'")
        n = datetime.datetime.now()
        d = n.day
        print(d, n.hour + 7)
        if n.hour + 7 > 24:
            d += 1
        current_day = f"{n.year}_{n.month}_{d}"
        mbots_day_add = row_mbots['day_add']
        if not mbots_day_add:
            mbots_day_add = '0.2024_8_5'
        try:
            mbots_day = mbots_day_add.split(".")[1]
            mbots_add = int(mbots_day_add.split(".")[0])
            if mbots_day == current_day and mbots_add >= utl.limit_add_per_day:
                utl.temp_is_end = True
                return await utl.bot.send_message(utl.admin_id[0], f'محدودیت {utl.limit_add_per_day} اد اکانت پر شده است.')
            if mbots_add != 0:
                join_number = utl.limit_add_per_day - mbots_add
        except:
            mbots_day_add = '0.2024_8_5'
            mbots_day = mbots_day_add.split(".")[1]
            mbots_add = int(mbots_day_add.split(".")[0])
            if mbots_day == current_day and mbots_add >= utl.limit_add_per_day:
                utl.temp_is_end = True
                return await utl.bot.send_message(utl.admin_id[0], f'محدودیت {utl.limit_add_per_day} اد اکانت پر شده است.')
            if mbots_add != 0:
                join_number = utl.limit_add_per_day - mbots_add
            # try:
        try:
            cs.execute(f"UPDATE {utl.mbots} SET last_order_at='{timestamp}' WHERE id={row_mbots['id']}")
            count_join = count_check = 0
            client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}", api_id=row_mbots['api_id'],
                                    api_hash=row_mbots['api_hash'])
            await client.connect()
            if not await client.is_user_authorized():
                cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
            else:
                # try:
                if 1:
                    if "/joinchat/" in row_gtg['destination']:
                        hash_ = row_gtg['destination'].split("/joinchat/")[1]
                        await client(functions.messages.ImportChatInviteRequest(hash_))
                    else:
                        await client(functions.channels.JoinChannelRequest(channel=row_gtg['destination']))
                    # i = 1
                    print(data[last_member_check:(last_member_check + join_number)])
                    for user in data[last_member_check:(last_member_check + join_number)]:
                        print(f"count join: {count_join}")
                        print(f"count check: {count_check}")
                        try:
                            cs.execute(
                                f"UPDATE {utl.gtg} SET last_member_check=last_member_check+1 WHERE id={row_gtg['id']}")
                            cs.execute(f"SELECT `last_member_check` FROM {utl.gtg} WHERE id={row_gtg['id']}")
                            now_lmc = cs.fetchone()
                            await client(
                                functions.channels.GetParticipantRequest(channel=row_gtg['destination'], participant=user))
                            print(str(user) + ": " + ": Already joined!")
                        except errors.UserNotParticipantError as e:
                            try:
                                count_check += 1
                                await client(
                                    functions.channels.InviteToChannelRequest(channel=row_gtg['destination'], users=[user]))
                                print(str(user) + ": " + ": Ok!")
                                count_join += 1
                                if (row_gtg['count_moved'] + count_join) >= row_gtg['count']:
                                    cs.execute(
                                        f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']} AND count_moved>0 AND count_moved>=count")
                                    if cs.fetchone() is not None:
                                        break
                                cs.execute(f"UPDATE {utl.gtg} SET count_moved=count_moved+1 WHERE id={row_gtg['id']}")
                                cs.execute(
                                    f"INSERT INTO {utl.moveds} (bot_id,username,origin_id,destination_id,created_at) VALUES ('{row_mbots['id']}','{user}','{row_gtg['origin_id']}','{row_gtg['destination_id']}','{timestamp}')")

                            except errors.FloodWaitError as e:
                                print(f"FloodWaitError: {e}")
                                # print(f"Have to sleep: {e.seconds}")
                                end_restrict = int(e.seconds) + int(time.time())
                                cs.execute(
                                    f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                                break
                            except Exception as e:
                                error = str(e)
                                print(f'exection1: {error}')
                                # print(str(row_mbots['id']) + ": " + str(i) + ": " + error)
                                if error == 'Too many requests (caused by InviteToChannelRequest)':
                                    await send_log(utl.bot, 'اکانت محدود شد', utl.admin_id[0])
                                    cs.execute(
                                        f"UPDATE {utl.gtg} SET last_member_check=last_member_check-1 WHERE id={row_gtg['id']}")
                                else:
                                    await utl.bot.send_message(utl.admin_id[1], str(e))
                        except errors.FloodWaitError as e:
                            print(f"FloodWaitError: {e}")
                            # print(f"Have to sleep: {e.seconds}")
                            end_restrict = int(e.seconds) + int(time.time())
                            cs.execute(
                                f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{end_restrict}' WHERE id={row_mbots['id']}")
                            break
                        except Exception as e:
                            error = str(e)
                            print(f"exception2: " + error)
                            
                            # print(str(row_mbots['id']) + ": " + str(i) + ": " + error)
                            if error == 'Too many requests (caused by InviteToChannelRequest)':
                                await send_log(utl.bot, 'اکانت محدود شد', utl.admin_id[0])
                                cs.execute(
                                    f"UPDATE {utl.gtg} SET last_member_check=last_member_check-1 WHERE id={row_gtg['id']}")
                            else:
                                await utl.bot.send_message(utl.admin_id[1], str(e))
                        # i += 1
                    #except:
                    #    pass
                    try:
                        for r in (await client(functions.messages.StartBotRequest(bot="@spambot", peer="@spambot",
                                                                                start_param="start"))).updates:
                            for r1 in (await client(functions.messages.GetMessagesRequest(id=[r.id + 1]))).messages:
                                if "I’m afraid some Telegram users found your messages annoying and forwarded them to our team of moderators for inspection." in r1.message:
                                    regex = re.findall(r'automatically released on [\d\w ,:]*UTC', r1.message)[0]
                                    regex = regex.replace("automatically released on ", "")
                                    regex = regex.replace(" UTC", "")
                                    restrict = datetime.datetime.strptime(regex, "%d %b %Y, %H:%M").timestamp()
                                    cs.execute(
                                        f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{restrict}' WHERE id={row_mbots['id']}")
                                    cs.execute(
                                        f"INSERT INTO {utl.report} (gtg_id,bot_id,created_at) VALUES ('{row_gtg['id']}','{row_mbots['id']}','{timestamp}')")
                            break
                    except:
                        pass
                    try:
                        for r in (await client(functions.messages.StartBotRequest(bot="@spambot", peer="@spambot",
                                                                                start_param="start"))).updates:
                            for r1 in (await client(functions.messages.GetMessagesRequest(id=[r.id + 1]))).messages:
                                if "I’m afraid some Telegram users found your messages annoying and forwarded them to our team of moderators for inspection." in r1.message:
                                    regex = re.findall(r'automatically released on [\d\w ,:]*UTC', r1.message)[0]
                                    regex = regex.replace("automatically released on ", "")
                                    regex = regex.replace(" UTC", "")
                                    restrict = datetime.datetime.strptime(regex, "%d %b %Y, %H:%M").timestamp()
                                    cs.execute(
                                        f"UPDATE {utl.mbots} SET status='restrict',end_restrict='{restrict}' WHERE id={row_mbots['id']}")
                                    cs.execute(
                                        f"INSERT INTO {utl.report} (gtg_id,bot_id,created_at) VALUES ('{row_gtg['id']}','{row_mbots['id']}','{timestamp}')")
                    except Exception as e:
                        pass
                    """pass"""
        except Exception as e:
            print(e)
        try:
            await client.disconnect()
        except:
            pass
        n = datetime.datetime.now()
        d = n.day
        print(d, n.hour + 7)
        if n.hour + 7 > 24:
            d += 1
        today_was_do = f"{count_join}.{n.year}_{n.month}_{d}"
        cs.execute(f"UPDATE {utl.mbots} SET day_add = '{today_was_do}'")
        mydb.commit()
        # print(f"########################: {count_join}")
    except Exception as e:
        try:
            await utl.bot.send_message(utl.admin_id[1], str(e))
        except:
            prRed("telegram.error.TimedOut: Pool timeout")


async def send_log(bot__: Bot_tel, text, chat_id):
    try:
        return await bot__.send_message(chat_id=chat_id, text=text)
    except:
        pass

while True:
    try:
        n = datetime.datetime.now()
        d = n.day
        print(d, n.hour + 7)
        if n.hour + 7 > 24:
            d += 1
        today_was_do = f"0.{n.year}_{n.month}_{d}"
        mydb = mysql.connector.connect(host=utl.host_db, database=utl.database, user=utl.user_db, passwd=utl.passwd_db,
                                       charset="utf8mb4", auth_plugin='mysql_native_password')
        cs = mydb.cursor(dictionary=True, buffered=True)
        cs.execute(f"SELECT * FROM {utl.admini}")
        row_admin = cs.fetchone()
        join_number = row_admin['add_per_h']
        timestamp = int(time.time())
        cs.execute(f"SELECT * FROM {utl.mbots} WHERE status='restrict' AND end_restrict<{timestamp}")
        for row in cs.fetchall():
            cs.execute(f"UPDATE {utl.mbots} SET status='submitted' WHERE id='{row['id']}'")
        cs.execute(f"SELECT * FROM {utl.gtg} WHERE status='doing'")
        row_gtg = cs.fetchone()
        if row_gtg is not None:
            last_member_check = row_gtg['last_member_check']

            # limit_per_h = row_admin['limit_per_h'] * 3600 * 24
            limit_per_h = 0
            cs.execute(
                f"SELECT * FROM {utl.mbots} WHERE status='submitted' AND (last_order_at+{limit_per_h})<{timestamp} ORDER BY last_order_at ASC")
            result_mbots = cs.fetchall()
            if result_mbots:
                with open(f"{directory}/export/{row_gtg['origin_id']}/{row_gtg['type_users']}.json", "r") as file:
                    data = json.loads(file.read())
                for row_mbots in result_mbots:
                    asyncio.run(add_to_group(cs, row_mbots, data, last_member_check, join_number))
                    if utl.temp_is_end:
                        result_mbots.remove(row_mbots)
                        utl.temp_is_end = False
                    else:
                        timestamp = int(time.time())
                        cs.execute(
                            f"UPDATE {utl.gtg} SET last_bot_check='{row_mbots['id']}',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                        cs.execute(f"SELECT * FROM {utl.gtg} WHERE id={row_gtg['id']}")
                        row_gtg = cs.fetchone()
                        if row_gtg is None or row_gtg['status'] == 'end':
                            break
                        elif (row_gtg['count_moved'] > 0 and row_gtg['count_moved'] >= row_gtg['count']) or row_gtg[
                            'last_member_check'] >= row_gtg['max_users']:
                            cs.execute(
                                f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
                            break
                        last_member_check = row_gtg['last_member_check']
                        # time.sleep(1)
            else:
                asyncio.run(send_log(utl.bot, 'اکانت ها تموم شدن', utl.admin_id[0]))
                print('accounts ended')
                cs.execute(f"UPDATE {utl.gtg} SET status='end',updated_at='{timestamp}' WHERE id={row_gtg['id']}")
    except Exception as e:
        try:
            asyncio.run(send_log(utl.bot, f"Error: {e}", utl.admin_id[1]))
        except:
            prRed("telegram.error.TimedOut: Pool timeout")
    time.sleep(20)

