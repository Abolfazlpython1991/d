#!/usr/bin/env python3

import os
import sys
import time
import mysql.connector
from telethon.sync import TelegramClient
from telethon import errors
import utility as utl
import asyncio

for index, arg in enumerate(sys.argv):
    if index == 1:
        from_id = arg
    elif index == 2:
        status = arg
    elif index == 3:
        mbot_id = int(arg)
if len(sys.argv) != 4:
    print("Invalid parameters!")
    exit()

directory = os.path.dirname(os.path.abspath(__file__))
timestamp = int(time.time())
mydb = mysql.connector.connect(host = utl.host_db,database=utl.database,user=utl.user_db,passwd=utl.passwd_db,charset="utf8mb4", auth_plugin='mysql_native_password')
cs = mydb.cursor(dictionary=True,buffered=True)

cs.execute(f"SELECT * FROM {utl.mbots} WHERE id={mbot_id}")
row_mbots = cs.fetchone()
if row_mbots == None:
    exit()

async def main():
    client = TelegramClient(session=f"{directory}/sessions/{row_mbots['phone']}",api_id=row_mbots['api_id'],api_hash=row_mbots['api_hash'])
    await client.connect()
    if status == 'check':
        try:
            if not await client.is_user_authorized():
                cs.execute(f"UPDATE {utl.mbots} SET status='expired' WHERE id={row_mbots['id']}")
                await utl.bot.send_message(chat_id=from_id,text="❌ اکانت از دسترس خارج شد\n\n"+
                    "❗️ در صورت لزوم می توانید اکانت را حذف و دوباره لاگین کنید")
            else:
                await utl.bot.send_message(chat_id=from_id,text=f"وضعیت: فعال ✅")
        except Exception as e:
            print("Error check status: "+str(e))
        await client.disconnect()
        exit()
    try:
        if await client.is_user_authorized():
            me = await client.get_me()
            cs.execute(f"UPDATE {utl.mbots} SET user_id='{me.id}',status='submitted' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
            await utl.bot.send_message(chat_id=from_id,text="✅ اکانت قبلا ثبت شده")
            await client.disconnect()
            exit()
    except Exception as e:
        print(e)
        await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی پیش آمده، دوباره تلاش کنید!")
        cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
        await client.disconnect()
        exit()
    if status == 'first_level':
        try:
            me = await client.send_code_request(phone=row_mbots['phone'])
            cs.execute(f"UPDATE {utl.mbots} SET phone_code_hash='{me.phone_code_hash}' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='add_acc;code;{row_mbots['id']}' WHERE user_id='{from_id}'")
            await utl.bot.send_message(chat_id=from_id,text=
                "پنل ادمین » افزودن اکانت » ارسال کد و پسورد:\n\n"+
                "❕ اگر پسورد نداشت فقط کد را ارسال کنید مثال:\n"+
                "12345\n\n"+
                "❕ اگر اکانت پسورد دارد هر کدام در یک خط مثال:\n"+
                "code\n"+
                "password"
            )
        except Exception as e:
            print(e)
            await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی پیش آمده، دوباره تلاش کنید!")
            cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
    elif status == 'code':
        is_login = False
        try:
            me = await client.sign_in(phone=row_mbots['phone'],phone_code_hash=row_mbots['phone_code_hash'],code=row_mbots['code'])
            is_login = True
        except errors.SessionPasswordNeededError as e:
            if row_mbots['password'] == None:
                cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
                await utl.bot.send_message(chat_id=from_id,
                    text="❌ اکانت دارای پسورد می باشد!\n\n" +
                        "❕ همانند زیر هر کدام را در یک خط ارسال کنید:\n"+
                        "code\n"+
                        "password"
                )
                await client.disconnect()
                exit()
            else:
                me = await client.sign_in(password=row_mbots['password'])
                is_login = True
        except Exception as e:
            print(e)
        
        if is_login == True:
            cs.execute(f"UPDATE {utl.mbots} SET user_id='{me.id}',status='submitted' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
            await utl.bot.send_message(chat_id=from_id,text="✅ با موفقیت ثبت شد")
        else:
            cs.execute(f"UPDATE {utl.mbots} SET status='first_level' WHERE id={row_mbots['id']}")
            cs.execute(f"UPDATE {utl.users} SET step='panel' WHERE user_id='{from_id}'")
            await utl.bot.send_message(chat_id=from_id,text="❌ مشکلی پیش آمده، دوباره تلاش کنید!")
    await client.disconnect()
    exit()
#except Exception as e:
#    print("Error2: "+str(e))


if __name__ == "__main__":
    asyncio.run(main())

