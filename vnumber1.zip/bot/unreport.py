from telethon.sync import TelegramClient as tc
from telethon import functions
import sys
import os
from time import sleep

args = sys.argv
args.pop(0)
# Texts
unreport_me_text = """Dear Telegram Support
My Telegram account has been spammed Suddenly and I cannot send message to any contacts whom I don’t have their number,if I am the chat starter Kindly help to fix the issue and remove the spam report
Best Regards"""
# ==================================
api_id = 29011362
api_hash = "c6a70248df5723c5150563de3b1f122c"
text2 = "Submit a complaint"
text3 = "No, I’ll never do any of this!"
finally_success_response = "Thank you! Your complaint has been successfully submitted. Our team’s supervisors will check it as soon as possible. If this was a mistake, all limitations will be lifted from your account soon."
# ==================================
sessions_default_dir = "sessions/confirmed_sessions"
if not args or len(args) != 1:
    print("پارامتر های نا معتبر")
    exit()
numbers_file_name = args[0]
if not os.path.exists(numbers_file_name):
    print('فایل وجود ندارد')
    exit()
if not os.path.isfile(numbers_file_name):
    print("پارامتر ارسالی فایل نیست")
    exit()
numbers_file = open(numbers_file_name, 'rt')
numbers = numbers_file.readlines()
numbers__ = []
for n in numbers:
    numbers__.append(n.replace("\n", ""))
numbers = numbers__
try:
    numbers.remove("")
except:
    pass
try:
    numbers.remove(" ")
except:
    pass
try:
    numbers.remove("\n")
except:
    pass

if not numbers:
    print("شماره ای پیدا نشد.")
    exit()

numbers_status = {
    "no_limit": 0,
    "unlimited": 0,
    'error': 0
}


def send_message_to_spam_bot(account: tc, text, bot_username="@spambot") -> [str, list]:
    if text == '/start':
        msg_id = (account(functions.messages.StartBotRequest(bot=bot_username, peer=bot_username, start_param="start"))).updates
    else:
        msg_id = (account(functions.messages.SendMessageRequest(peer=bot_username, message=text))).updates
    sleep(0.5)
    result = account(functions.messages.GetMessagesRequest([msg_id[0].id + 1])).messages[0]
    return [result.message, [msg_id[0].id, msg_id[0].id + 1]]


print("starting process...")
for number in numbers:
    account = tc(session=f"{sessions_default_dir}/{number}", api_hash=api_hash, api_id=api_id)
    account.connect()
    account.start(phone=number)
    messages_list = []
    msg, msgs1 = send_message_to_spam_bot(account, '/start')
    messages_list.extend(msgs1)
    if msg == 'Good news, no limits are currently applied to your account. You’re free as a bird!':
        numbers_status['no_limit'] += 1
        print(f"account [{number}] don't have any limit")
        msg, msgs2 = send_message_to_spam_bot(account, "Cool, thanks")
        messages_list.extend(msgs2)
    else:
        msg2, msgs2 = send_message_to_spam_bot(account, text2)
        msg3, msgs3 = send_message_to_spam_bot(account, text3)
        msg4, msgs4 = send_message_to_spam_bot(account, unreport_me_text)
        print(f"bad response: {msg4}")
        messages_list.extend(msgs2)
        messages_list.extend(msgs3)
        messages_list.extend(msgs4)
        if msg4 == finally_success_response:
            numbers_status['unlimited'] += 1
            print(f"account [{number}] unlimited")
        else:
            numbers_status['error'] += 1
            print(f"error in account [{number}]")
    account.delete_messages("@spambot", messages_list)
    account.disconnect()

result_text = f"""
اکانت هایی که ریپ نبودند: {numbers_status['no_limit']} تا
اکانت هایی که درخواست آن ریپورت آنها انجام شد: {numbers_status['unlimited']} تا
خطا ها: {numbers_status['error']} تا
"""
print(result_text)
print('end of process.')
