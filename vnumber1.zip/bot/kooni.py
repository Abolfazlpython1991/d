import sqlite3,random

conn = sqlite3.connect('data.db')
cursor = conn.cursor()

def query(query):
    result = cursor.execute(query)
    conn.commit()
    return result

def get_proxy():
    with open("proxy.txt", "r") as file:
        proxies = file.readlines()
        try:
            random_proxy = random.choice(proxies).strip()
        except:
            random_proxy = ""
        return random_proxy


cursor.execute("SELECT * FROM sessions WHERE level = 3")
rows = cursor.fetchall()


for row in rows:

    proxy = get_proxy()
    query(f"UPDATE `sessions` SET `proxy` = '{proxy}' WHERE `phonenumber` = '{row[0]}'")
    print(f"{row[0]} :  {proxy}")

conn.close()