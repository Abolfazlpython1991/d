#!/usr/bin/env python
# -*- coding: utf-8 -*-

import requests, re, os
import sys, aiocron, time, edit
import confi as config
from telethon.sync import functions, events, errors
from telethon.tl.types import InputPeerUser
from telethon.sync import TelegramClient as tc2
from telethon.tl.custom import Button
import sqlite3, random, json, time, shutil, string
from datetime import datetime
from telethon.tl.functions.channels import InviteToChannelRequest
from opentele.td import TDesktop
from opentele.tl import TelegramClient
from opentele.api import API, UseCurrentSession
import asyncio
from lxml import html
#import edit
from requests.auth import HTTPProxyAuth
from telethon.tl.functions.messages import GetHistoryRequest
import re, zipfile
from telethon.tl.types import InputPeerChat

# from telegram.constants import ParseMode

# ======================= APIs =============================

check_rip_countries = ['999']
apihash_accounts = "c6a70248df5723c5150563de3b1f122c"
apiid_accounts = 29011362
#owner = 1487353688
owner = 1487353688
twofanew = "Abolfazl5465"

# ======================== sms =============================
sms_cancel_time = 60 * 10
SMS_API_KEY = 'ce607a19-fae2-42d3-a75f-b770c20f632a'
logs_channel_chat_id = -1001984214325
SMS_BASE_URL = f'https://activate-api.smsverified.com/stubs/handler_api.php?api_key={SMS_API_KEY}&action='
sms_countries = {'United Kingdom': 44, 'Azerbaijan': 994, 'Guatemala': 502,
                 'Israel': 972, 'Timor': 670, 'Sri Lanka': 94, 'Netherlands': 31,
                 'Slovenia': 386, 'Philippines': 63, 'Croatia': 385}
# ======================= client ===========================
bot = tc2('test_main', api_id=29011362, api_hash="c6a70248df5723c5150563de3b1f122c")
bot.start(bot_token="6097471200:AAEmXIiaUfPLycx7vfyNE5Du_PL9TouNzX0")
print("runned")

if not os.path.exists("sessions/zip"):
    os.makedirs("sessions/zip")
    print(f"Created directory:")

if not os.path.exists("tdata"):
    os.makedirs("tdata")
    print(f"Created directory:")

# =========================== markups ======================
main_markup1 = [
    [Button.text('📤 ارسال اکانت', resize=True)],
    [Button.text('📝راهنمای جامع', resize=True), Button.text('✅ تسویه', resize=True),
     Button.text('👤 حساب من', resize=True)],
    [Button.text('پشتیبانی🆘', resize=True), Button.text('🌏کشورهای مجاز', resize=True)],
    [Button.text('📲 Buy Telegram Virtual Number', resize=True)],
    [Button.text('📲 Buy SMS', resize=True)],
    [Button.text('💰 Charge the account', resize=True)]
]

main_markup2 = [
    [Button.text('📤 ارسال اکانت', resize=True)],
    [Button.text('📝راهنمای جامع', resize=True), Button.text('✅ تسویه', resize=True),
     Button.text('👤 حساب من', resize=True)],
    [Button.text('پشتیبانی🆘', resize=True), Button.text('🌏کشورهای مجاز', resize=True)],
    [Button.text('💫 پنل مدیریت', resize=True)],
    [Button.text('پنل مدیریت بخش شماره مجازی', resize=True)],
    [Button.text('پنل اس ام اس', resize=True)]
]

vn_admin_markup = [
    [Button.text('مدیریت کشور ها', resize=True)]
]

payment_markup = [
    [Button.text('💳 نقدی', resize=True), Button.text('🔙 بازگشت', resize=True)],
]

setting_markup = [

    [Button.inline('💵اطلاعات حساب', data=f'userwithdrawinfo')]

]

admin_markup = [
    [Button.text('🫂امار کلی', resize=True), Button.text('📣بخش همگانی', resize=True)],
    [Button.text('📣وضعیت اکانت ها', resize=True), Button.text('⭐️مدیریت کشورها', resize=True)],
    [Button.text('⚙️مدیریت کاربران', resize=True), Button.text('📞مشاهده شماره ها', resize=True)],
    [Button.text('تغییر متن راهنمای جامع📝', resize=True)],
    [Button.text('📎دریافت فایل های تلتون', resize=True), Button.text('📎دریافت فایل های تی دیتا', resize=True)],
    [Button.text('📞دریافت کد', resize=True)],
    [Button.text('حذف سشن های یک شماره', resize=True)],
    [Button.text('حذف سشن ها با لیست', resize=True)],
    [Button.text("SQL", resize=True)],
    [Button.text("COMMIT", resize=True)]
]

cancel_markup = [
    [Button.text('🔙 بازگشت', resize=True)],
]

admin_cancel_markup = [
    [Button.text('🔙 برگشت', resize=True)],
]

manage_countries = [Button.inline(".", data="null"), Button.inline("💲 قیمت", data="null"),
                    Button.inline("✨وضعیت ", data="null"), Button.inline("📝کدکشور", data="null"),
                    Button.inline("🌏نام کشور", data="null")]

sms_manage_countries1 = [Button.inline("➕افزودن کشور", data="sms_new_country")]

sms_manage_countries2 = [Button.inline('دکمه حذف', data='null'),
                         Button.inline("💲 قیمت", data="null"),
                         Button.inline("🌏نام کشور", data="null"),
                         Button.inline('آیدی در سایت', data='null')]

new_country = [Button.inline("➕افزودن کشور", data="newcountry")]
vn_new_country = [Button.inline("➕افزودن کشور", data="vn_newcountry")]

sendall_markup = [
    [Button.text('📣فروارد همگانی', resize=True), Button.text('📣پیام همگانی', resize=True)],
    [Button.text('🔙 برگشت', resize=True)],

]

admin_sms_panel = [[Button.text("استعلام موجودی api key", resize=True)],
                   [Button.text('مدیریت کشور ها', resize=True)],
                   [Button.text('🔙 بازگشت', resize=True)]]

# ======================= db settings ======================
conn = sqlite3.connect("data.db")
cursor = conn.cursor()
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `users` (`user_id` BIGINT(10) PRIMARY KEY, `step` VARCHAR(1000), `balance` INT(100) DEFAULT 0, `trxwallet` VARCHAR(1000),`autopin` VARCHAR(1000),`autoconfirm` VARCHAR(1000),`cardnumber` VARCHAR(1000),`ban` VARCHAR(1000),`accountsended` VARCHAR(1000),`deletecount` VARCHAR(1000),`healthcount` VARCHAR(1000),`availablebalance` VARCHAR(1000),`recivedamount` VARCHAR(1000));")
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `sessions` (`phonenumber` VARCHAR(1000),`proxy` VARCHAR(1000),`appid` VARCHAR(1000),`apphash` VARCHAR(1000),`level` VARCHAR(1000),`devicename` VARCHAR(1000),`country` VARCHAR(1000),`twofa` VARCHAR(1000),`chat_id` VARCHAR(1000),`confirmtime` VARCHAR(1000),`deletecheck` VARCHAR(1000),`countrycode` VARCHAR(1000));")
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `countries` (`country` VARCHAR(1000), `status` VARCHAR(1000), `name` VARCHAR(1000),`countrycode` VARCHAR(1000) PRIMARY KEY, `price` VARCHAR(1000));")
cursor.execute("CREATE TABLE IF NOT EXISTS `setting` (`type` VARCHAR(1000) PRIMARY KEY,`text` VARCHAR(1000));")
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `autoconfirmaccounts` (`chat_id` VARCHAR(1000),`message_id` VARCHAR(1000),`phonenumber` VARCHAR(1000),`twofa` VARCHAR(1000),`time` VARCHAR(1000),`status` VARCHAR(1000));")
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `webservice` (`requestid` VARCHAR(1000) PRIMARY KEY,`token` VARCHAR(1000),`phonenumber` VARCHAR(1000),`status` VARCHAR(1000),`twofa` VARCHAR(1000));")

cursor.execute(f"SELECT COUNT(*) FROM `setting` WHERE `type` = 'help'")

result = cursor.fetchone()
if result[0] == 0:
    cursor.execute(f"INSERT INTO `setting` (`type`,`text`) VALUES ('help','helptext');")

cursor.execute(f"SELECT COUNT(*) FROM `setting` WHERE `type` = 'sendalltext'")
result1 = cursor.fetchone()
if result1[0] == 0:
    cursor.execute(f"INSERT INTO `setting` (`type`,`text`) VALUES ('sendalltext','null');")
    cursor.execute(f"INSERT INTO `setting` (`type`,`text`) VALUES ('sendallstatus','null');")
    cursor.execute(f"INSERT INTO `setting` (`type`,`text`) VALUES ('forwardallmsgid','null');")
    cursor.execute(f"INSERT INTO `setting` (`type`,`text`) VALUES ('forwardallstatus','null');")

conn.commit()


def check_error(error_text):
    if error_text == 'database is locked':
        conn = sqlite3.connect("data.db")
        cursor = conn.cursor()


def query(query):
    result = cursor.execute(query)
    conn.commit()
    return result


# =========================== sendall ======================
"""
async def sendall(type_):
    sendallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
    sendalltext = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendalltext'").fetchone()[0]
    forwardallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'forwardallstatus'").fetchone()[0]
    forwardallmsgid = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'forwardallmsgid'").fetchone()[0]
    if sendallstatus == "ON" and type_ == 'send':
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendalltext'")
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendallstatus'")
        cursor.execute('SELECT * FROM users')
        rows = cursor.fetchall()
        results = {'success: ': 0}
        await bot.send_message(owner,"✅ارسال پیام همگانی شروع شد") 
        for row in rows:
            userid = row[0]
            try:
                time.sleep(1)
                await bot.send_message(int(userid),sendalltext)
            except Exception as e:
                print(f"error: '{e}'")
                if e in results.keys():
                    results[e] += 1
                else:
                    results[e] = 1
            else:
                results['success: '] += 1
        await bot.send_message(owner,"✅ارسال پیام همگانی پایان یافت")
        await bot.send_message(owner, "نتیجه" + str(results))
    if forwardallstatus == "ON" and type_ == 'forward':
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'forwardallmsgid'")
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'forwardallstatus'")
        cursor.execute('SELECT * FROM users')
        rows = cursor.fetchall()
        await bot.send_message(owner,"✅ارسال فروارد همگانی شروع شد") 
        for row in rows:
            userid = row[0]
            try:
                time.sleep(1)
                await bot.forward_messages(entity=int(userid),messages=int(forwardallmsgid),from_peer=owner)
            except:
                continue  
        await bot.send_message(owner,"✅ارسال فروارد همگانی پایان یافت")"""


# ==================== helper funcs ========================
def query(query):
    result = cursor.execute(query)
    conn.commit()
    return result


def insert_user(user):
    cursor.execute(f"SELECT COUNT(*) FROM `users` WHERE `user_id` = '{user}'")
    result = cursor.fetchone()
    if result[0] == 0:
        cursor.execute(
            f"INSERT INTO `users` (`user_id`, `step`, `trxwallet`, `autopin`, `autoconfirm`, `cardnumber`,`ban`,`accountsended`,`deletecount`,`healthcount`,`availablebalance`,`recivedamount`) VALUES ('{user}', 'none', 'NULL', 'OFF', 'OFF','NULL','false','0','0','0','0','0');")


def set_step(user, step):
    query(f"UPDATE `users` SET `step` = '{step}' WHERE `user_id` = '{user}'")


def zip_folder(folder_path, output_path):
    with zipfile.ZipFile(output_path, 'w') as zipf:
        for root, _, files in os.walk(folder_path):
            for file in files:
                file_path = os.path.join(root, file)
                zipf.write(file_path, os.path.relpath(file_path, folder_path))


def to_sent(value):
    len_ashar = len(value.split(".")[1])
    if len_ashar == 1:
        value += "0"
    ashar_value = int(value.split('.')[1])
    number_value = int(value.split(".")[0]) * 100
    return number_value + ashar_value


def to_dollar(sent: int):
    return sent / 100


def calculate_new_balance(balance, price):
    print(f"calc for:  {balance}, {price}")
    if type(balance) == type(""):
        balance = float(balance)
    if type(price) == type(""):
        price = float(price)
    balance = to_sent(str(balance))
    price: int = to_sent(str(price))
    value: int = balance - price
    print(f"LLLL: {value}")
    print(f"RES: {to_dollar(value)}")
    return to_dollar(value)


def crt_form(value):
    value = str(value)
    try:
        ashar__ = value.split(".")[1]
    except:
        value += '.00'
        ashar__ = value.split(".")[1]
    if len(ashar__) < 2:
        ashar__ += "0" * (2 - len(ashar__))
    ashar = ashar__[0:2]
    value = value.replace(ashar__, ashar)
    return value


def get_proxy():
    with open("proxy.txt", "r") as file:
        proxies = file.readlines()
        try:
            random_proxy = random.choice(proxies).strip()
        except:
            random_proxy = ""
        return random_proxy


def delete_acc(phone):
    os.remove(f"sessions/temp_sessions/{phone}.session")


def generate_random_string(length):
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(length))


def selectrandomname():
    random_file = random.choice(edit.names)
    return random_file


def selectrandomfile():
    files = os.listdir(edit.directory)
    random_file = random.choice(files)
    return random_file


async def randomAPP():
    with open('app.txt', 'r', encoding='utf-8') as file:
        file = file.read().split('\n')
        app_id, app_hash = random.choice(file).split()
    return app_id, app_hash


def get_numbers():
    confirmed_nums__ = os.listdir('sessions/confirmed_sessions')
    confirmed_nums = []
    for cn in confirmed_nums__:
        if os.path.isfile(cn):
            confirmed_nums.append(cn)
    return confirmed_nums


def get_countries():
    countries = dict()
    #cnt = cursor.execute("SELECT `country_name`, `country_code`, `price`, `len_numbers` FROM vn_countries").fetchall()
    cnt = cursor.execute("SELECT * FROM vn_countries").fetchall()
    for country in cnt:
        if country[0] in list(countries.keys()):
            countries[country[0]] += country
        else:
            countries[country[0]] = country
    return countries


def unlock_db():
    """try:
        conn.commit()
        cursor.close()
        conn.close()
    except: pass
    os.system("fuser data.db > db.text")
    f = open("db.text", "rt")
    content = f.read()
    proccess_name = re.findall("[0-9][0-9][0-9][0-9]", content)[0]
    os.system(f"kill -9 {proccess_name}")
    conn = sqlite3.connect("data.db")
    cursor = conn.cursor()"""
    pass


def get_len_numbers(country_code):
    numbers__ = cursor.execute(
        f"SELECT `phonenumber` FROM sessions WHERE `level` = '3' AND `countrycode` = '{country_code}'").fetchall()
    len_numbers = 0
    numbers = []
    for num in numbers__:
        num = num[0]
        len_numbers += 1
        numbers.append(num)
    return len_numbers, numbers


async def is_signed_up(jtext):
    try:
        s = json.loads(jtext.to_json())
        if s['_'] == 'AuthorizationSignUpRequired':
            return False
        else:
            return True
    except Exception:
        return True


def is_int_float(num):
    try:
        float(num)
    except:
        try:
            int(num)
        except:
            return False
        else:
            return int(num)
    else:
        return float(num)


async def vn_get_otp_code(phone_number):
    print(phone_number)
    phone_appid = apiid_accounts
    phone_apphash = apihash_accounts
    phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone_number}'").fetchone()[
        0]
    IP, port, username, password = phone_proxy.split(":")
    account = tc2(f"sessions/confirmed_sessions/{phone_number}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                  proxy=("socks5", IP, int(port), True, username, password))
    # await account.connect()
    try:
        await account.connect()
        if await account.is_user_authorized():
            posts = await account(
                GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                  add_offset=0, hash=0))
            for i in posts.messages:
                if i.message != None:
                    numbers = re.findall(r'\d+', i.message)
                    if numbers:
                        number = numbers[0]
                        return number
                    else:
                        return "NOT_SEND"
        else:
            return "HAVE_NOT_ACCESS"
    except ConnectionError:
        return "PROXY_ERROR"
    try:
        await account.disconnect()
    except Exception as e:
        await bot.send_message(owner, str(e))


class TelegramApplication:
    def send_cloud_password(self, phone, IP, port, username, password):
        try:
            proxies = {
                'http': f"socks5h://{username}:{password}@{IP}:{port}",
                'https': f"socks5h://{username}:{password}@{IP}:{port}"
            }
            response = requests.post("https://my.telegram.org/auth/send_password", proxies=proxies,
                                     auth=(username, password), data=f"phone={phone}",
                                     headers={"Origin": "https://my.telegram.org",
                                              "Accept-Encoding": "gzip, deflate, br",
                                              "Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4",
                                              "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
                                              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                              "Accept": "application/json, text/javascript, */*; q=0.01",
                                              "Reffer": "https://my.telegram.org/auth",
                                              "X-Requested-With": "XMLHttpRequest", "Connection": "keep-alive",
                                              "Dnt": "1", })
            result = response.content
            try:
                get_json = json.loads(response.content)

                return get_json

            except Exception as e:
                return str(e)
        except Exception as e:
            return str(e)

    def auth(self, phone, hash_code, cloud_password, IP, port, username, password):
        proxies = {
            'http': f"socks5h://{username}:{password}@{IP}:{port}",
            'https': f"socks5h://{username}:{password}@{IP}:{port}"
        }
        data = f"phone={phone}&random_hash={hash_code}&password={cloud_password}"

        responses = requests.post('https://my.telegram.org/auth/login', proxies=proxies,
                                  data=f"phone={phone}&random_hash={hash_code}&password={cloud_password}",
                                  headers={"Origin": "https://my.telegram.org", "Accept-Encoding": "gzip, deflate, br",
                                           "Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4",
                                           "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
                                           "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                           "Accept": "application/json, text/javascript, */*; q=0.01",
                                           "Reffer": "https://my.telegram.org/auth",
                                           "X-Requested-With": "XMLHttpRequest", "Connection": "keep-alive",
                                           "Dnt": "1", })
        result = responses.content

        try:
            return responses.cookies['stel_token']
        except Exception as e:

            return False

    def auth_app(self, stel_token, IP, port, username, password):
        proxies = {
            'http': f"socks5h://{username}:{password}@{IP}:{port}",
            'https': f"socks5h://{username}:{password}@{IP}:{port}"
        }

        resp = requests.get('https://my.telegram.org/apps', proxies=proxies,
                            headers={"Dnt": "1", "Accept-Encoding": "gzip, deflate, br",
                                     "Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4",
                                     "Upgrade-Insecure-Requests": "1",
                                     "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
                                     "Reffer": "https://my.telegram.org/org", "Cookie": f"stel_token={stel_token}",
                                     "Cache-Control": "max-age=0", })
        tree = html.fromstring(resp.content)
        api = tree.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
        try:
            return api[0], api[1]
        except Exception as e:
            try:
                s = resp.text.split('"/>')[0]
                value = s.split('<input type="hidden" name="hash" value="')[1]
                requests.post('https://my.telegram.org/apps/create',
                              data=f"hash={value}&app_title=Telegram Android&app_shortname=Telegram Android&app_url=&app_platform=desktop&app_desc=",
                              headers={"Cookie": "stel_token={0}".format(stel_token),
                                       "Origin": "https://my.telegram.org", "Accept-Encoding": "gzip, deflate, br",
                                       "Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4",
                                       "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
                                       "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                                       "Accept": "*/*", "Referer": "https://my.telegram.org/apps",
                                       "X-Requested-With": "XMLHttpRequest", "Connection": "keep-alive", "Dnt": "1", })
                respv = requests.get('https://my.telegram.org/apps',
                                     headers={"Dnt": "1", "Accept-Encoding": "gzip, deflate, br",
                                              "Accept-Language": "it-IT,it;q=0.8,en-US;q=0.6,en;q=0.4",
                                              "Upgrade-Insecure-Requests": "1",
                                              "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/57.0.2987.133 Safari/537.36",
                                              "Reffer": "https://my.telegram.org/org",
                                              "Cookie": f"stel_token={stel_token}", "Cache-Control": "max-age=0", })
                trees = html.fromstring(respv.content)
                api = trees.xpath('//span[@class="form-control input-xlarge uneditable-input"]//text()')
                return api[0], api[1]
            except Exception as e:
                return False


async def get_active_numbers(country_code):
    confirmed_sessions = os.listdir("sessions/confirmed_sessions/")
    print(confirmed_sessions)
    numbers = []
    for phone in cursor.execute(
            f"SELECT * FROM sessions WHERE `level` = '3' AND `countrycode` = '{country_code}' OR `countrycode` = '+{country_code}'").fetchall():
        if f'{phone[0]}.session' in confirmed_sessions:
            numbers.append(phone)
    return numbers


def get_api_key_balance():
    return requests.get(SMS_BASE_URL + 'getBalance').text


def get_number_amount(country_code):
    response = requests.get(SMS_BASE_URL + 'getNumbersStatus').json()
    return '15'


def get_available_countries():
    available_countries = []
    url = SMS_BASE_URL + 'getCountries'
    response = requests.get(url).json()
    cursor.execute('SELECT `name`, `country_code`, `price` FROM sms_countries')
    results = cursor.fetchall()
    for country in results:
        country_name, country_code, price = country[0], country[1], country[2]
        try:
            response[str(country_code)]
        except:
            pass
        else:
            available_countries.append([country_name, country_code, price, get_number_amount(country_code)])
    return available_countries


def remove_number(number_details, chat_id):
    cursor.execute(f"SELECT `sms_numbers` FROM users WHERE `user_id` = '{chat_id}'")
    active_numbers_str = cursor.fetchall()[0][0]
    if not active_numbers_str:
        active_numbers_str = ""
    active_numbers_list: list = active_numbers_str.replace(' ', '').split(",")
    if active_numbers_list == ['']:
        active_numbers_list = []
    try:
        active_numbers_list.remove('')
    except:
        pass
    try:
        active_numbers_list.remove(number_details)
    except:
        pass
    active_numbers_string = ""
    for active_num in active_numbers_list:
        active_numbers_string += active_num + ','
    active_numbers_string = active_numbers_string[:-1]
    cursor.execute(
        f"UPDATE users SET `sms_numbers` = '{active_numbers_string}' WHERE `user_id` = '{chat_id}'")
    conn.commit()


def append_number(details, chat_id):
    cursor.execute(f"SELECT `sms_numbers` FROM users WHERE `user_id` = '{chat_id}'")
    active_numbers_str = cursor.fetchall()[0][0]
    if not active_numbers_str:
        active_numbers_str = ""
    active_numbers_list: list = active_numbers_str.replace(' ', '').split(",")
    if active_numbers_list == ['']:
        active_numbers_list = []
    try:
        active_numbers_list.remove('')
    except:
        pass
    active_numbers_list.append(details)
    active_numbers_string = ""
    for active_num in active_numbers_list:
        active_numbers_string += active_num + ','
    active_numbers_string = active_numbers_string[:-1]
    cursor.execute(
        f"UPDATE users SET `sms_numbers` = '{active_numbers_string}' WHERE `user_id` = '{chat_id}'")
    conn.commit()


async def send_message_to_spam_bot(account: tc2, text, bot_username="@spambot") -> [str, list]:
    if text == '/start':
        msg_id = (await account(functions.messages.StartBotRequest(bot=bot_username, peer=bot_username, start_param="start"))).updates
    else:
        msg_id = (await account(functions.messages.SendMessageRequest(peer=bot_username, message=text))).updates
    time.sleep(0.3)
    result = (await account(functions.messages.GetMessagesRequest([msg_id[0].id + 1]))).messages[0]
    return [result.message, [msg_id[0].id, msg_id[0].id + 1]]


# ============================================================================================================
@bot.on(events.NewMessage)
async def answer(event):
    ############
    ############
    message = event.message
    message_id = message.id
    text = event.raw_text
    chat_id = event.sender_id
    # ===== create user =====
    insert_user(chat_id)
    # =======================
    sendallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
    sendalltext = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendalltext'").fetchone()[0]
    forwardallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'forwardallstatus'").fetchone()[0]
    forwardallmsgid = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'forwardallmsgid'").fetchone()[0]
    if sendallstatus == "ON":
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendalltext'")
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'sendallstatus'")
        cursor.execute('SELECT * FROM users')
        rows = cursor.fetchall()
        results = {'success: ': 0}
        stats = []
        await bot.send_message(owner, "✅ارسال پیام همگانی شروع شد")
        for row in rows:
            userid = row[0]
            try:
                time.sleep(1)
                await bot.send_message(int(userid), sendalltext)
            except Exception as e:
                if e in results.keys():
                    results[e] += 1
                else:
                    results[e] = 1
                    stats.append(e)
            else:
                results['success: '] += 1
        await bot.send_message(owner, "✅ارسال پیام همگانی پایان یافت")
        await bot.send_message(owner, "نتیجه")
        for r in stats:
            await bot.send_message(owner, str(results[r]))
    if forwardallstatus == "ON":
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'forwardallmsgid'")
        query(f"UPDATE `setting` SET `text` = 'NULL' WHERE `type` = 'forwardallstatus'")
        cursor.execute('SELECT * FROM users')
        rows = cursor.fetchall()
        await bot.send_message(owner, "✅ارسال فروارد همگانی شروع شد")
        for row in rows:
            userid = row[0]
            try:
                time.sleep(1)
                await bot.forward_messages(entity=int(userid), messages=int(forwardallmsgid), from_peer=owner)
            except:
                continue
        await bot.send_message(owner, "✅ارسال فروارد همگانی پایان یافت")

    # telegram_application = TelegramApplication()

    """if (int(chat_id) == int(owner) or int(chat_id) == 6377188786) and text == '$sendall':
        await sendall('send')
    elif int(chat_id) == int(owner) and text == '$forwardall':
        await sendall('forward')"""
    if (int(chat_id) == int(owner) or int(chat_id) == 6556061698) and text[0:17] == 'terminal_command:':
        await event.reply('در حال اجرای دستور')
        os.system(text.replace('terminal_command:', ''))
        await event.reply('command completed')
    if int(chat_id) == int(owner):
        main_markup = main_markup2
    else:
        main_markup = main_markup1
    step = cursor.execute(f"SELECT `step` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
    #----------------------------------------------#
    if event.message.file and event.message.file.name.endswith('.session') and chat_id == owner:
        file_path = os.path.join('sessions/confirmed_sessions', event.message.file.name)
        await bot.download_media(event.message, file_path)
        # proxy = get_proxy()
        # countryname = cursor.execute(f"SELECT `country` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()[0]
        set_step(chat_id, f"get_session_send_details:{file_path}")
        #
        # await event.reply(f'SESSION ADDED WITH PROXY:\n{proxy}')
        await event.reply(
            f"اطلاعات را به صورت زیر وارد کنید:" + "\nPhoneNumber: +9123456789\nCountryCode: +98\ntwofa: رمز دو مرحله ای")
        return
    #----------------------------------------------#
    # ===== check ban =====
    banstatus = cursor.execute(f"SELECT `ban` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
    if banstatus == "true" and chat_id != owner:
        await event.respond(
            f"📍کاربر گرامی {chat_id} :\n\nحساب کاربری شما به توسط ادمین مسدود شده است . در صورت هر گونه سوال به پشتیبانی مراجعه فرمایید")
        return
    # ======================================================
    if text.lower() == '/start':
        await event.reply('👋 سلام خوش اومدی .  \n\n👈 برای ادامه از منوی زیر انتخاب کن :', buttons=main_markup)
        set_step(chat_id, "none")
    elif text == "🔙 بازگشت":
        await event.reply('🏠 برگشتیم به منوی اصلی !\n\n👈 برای ادامه از منوی زیر انتخاب کن :', buttons=main_markup)
        set_step(chat_id, "none")
    # ==================================================
    # [Button.text('📲 Buy Telegram Virtual Number', resize=True)]
    # [Button.text('💳 Inquiry | Prices', resize=True), Button.text('☎️ My Numbers', resize=True)],
    # [Button.text('💰 Charge the account', resize=True), Button.text('🚦 Help | Guide', resize=True)],
    # [Button.text('👮 Support', resize=True)]"""
    # ==================================================
    elif text == "📤 ارسال اکانت":
        await event.reply(
            '📞 لطفا شماره ی اکانت را ارسال نمایید :\n\n👈 نمونه : +98 912346789\n\nتوجه داشته باشید که اول پیش شماره کشور با + و بعد یک فاصله و بعد شماره را وارد کنید',
            buttons=cancel_markup)
        set_step(chat_id, "send_account")
    elif text == '💰 Charge the account':
        await bot.send_message(chat_id, "to increase the balance, contact the admin:\n>>>>>  @forosh_frs")
        return
    #'''elif text == '☎️ شماره های من' or text == '☎️ My Numbers':
    #    numbers_ = cursor.execute(f"SELECT `numbers` FROM users WHERE `user_id` = '{chat_id}'").fetchone()[0].split(", ")
    #    numbers_.pop(-1)
    #    if not numbers_:
    #        await event.reply("❌ You Don`t Have Any Virtual Number Right Now")
    #    else:
    #        numbers = numbers_
    #        await event.reply("Your Virtual Numbers:")
    #        for number in range(len(numbers)):
    #            button = [Button.inline("Get OTP Code", data=f"main_get_otp_code:{numbers[number]}"),
    #                      Button.inline("Logout Bot From Account", data=f"vn_logout_bot:{numbers[number]}")]
    #            await bot.send_message(chat_id, f"{number}- {numbers[number]}", buttons=button)
    #        await bot.send_message(chat_id, "Two Step Verify Password: Abolfazl5465")'''
    # ======================================================
    if text == '📲 Buy SMS':
        return await event.reply("OFF")
        countries__ = get_available_countries()
        # rep_markup = [[Button.text('Active numbers ✅', resize=True)]]
        rep_markup = [[Button.text("Back 🔙", resize=True)]]
        text = "Prices list:\n\n"
        for index, country in enumerate(countries__):
            text += f"{index + 1} - {country[0]}: {country[2]} $ \n"
        for i in range(len(countries__)):
            if i % 2 == 0:
                try:
                    rep_markup.append([Button.text(countries__[i][0]), Button.text(countries__[i + 1][0])])
                except IndexError:
                    pass
        if len(rep_markup) % 2 != 0:
            rep_markup.append([Button.text(countries__[-1][0])])
        await event.reply(str(text), buttons=rep_markup)
        set_step(chat_id, 'buy_sms')
        return
    elif text == '📲 Buy Telegram Virtual Number' or text == '📲 خرید شماره مجازی تلگرام':
        balance = cursor.execute(f"SELECT `balance` FROM users WHERE user_id = '{chat_id}'").fetchone()[0]
        response = f"Your Balance: {balance} $\n\nSelect Your Country: "
        countries = get_countries()
        inline_buttons = []
        countries_lst = list(countries.keys())
        for res in countries_lst:
            name, code, price, status = countries[res][1], countries[res][2], countries[res][3], countries[res][4]
            if status == "ON":
                len_nums = len(await get_active_numbers(code))
                text = f"+{code} | {name}({len_nums}) | {price} $"
                data = f"buy_vn_country:{code}"
                inline_buttons.append([Button.inline(text, data)])
        if inline_buttons:
            await event.reply(response, buttons=inline_buttons)
        else:
            await event.reply("We Haven`t Any Virtual Number Yet!")
    elif step == 'buy_sms':
        if text == "Back 🔙":
            set_step(chat_id, 'none')
            return await event.reply("We are back to the main menu", buttons=main_markup)
        countries__ = get_available_countries()
        countries_name = [country[0] for country in countries__]
        if text == 'active_numbers_linux7563':
            cursor.execute(f"SELECT `sms_numbers` FROM users WHERE `user_id` = '{chat_id}'")
            active_numbers_str = cursor.fetchall()[0][0]
            if not active_numbers_str:
                return await event.reply("You have not any active number!")
            else:
                active_numbers_list = active_numbers_str.replace(' ', '').split(",")
                text = f"You have {len(active_numbers_list)} Active number that you can see they in bellow buttons\n\nAlso you can get full SMS history from each number by click on it"
                active_numbers_markup = []
                for active_num in active_numbers_list:
                    active_num__ = active_num.split(":")
                    active_numbers_markup.append(
                        [Button.inline(text=active_num__[1], data='sms_number:' + str(active_num))])
                return await event.reply(text, buttons=active_numbers_markup)
        elif text in countries_name:
            country_name = text
            cursor.execute(f"SELECT `country_code`, `price` FROM sms_countries WHERE `name` = '{country_name}'")
            country_code_and_price = cursor.fetchone()
            country_code, price = country_code_and_price[0], float(country_code_and_price[1])
            cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'")
            user_balance = float(cursor.fetchone()[0])
            if user_balance < price:
                return await event.reply("Your balance is not enough!")
            else:
                cursor.execute(f"SELECT `id` FROM sms_countries WHERE `name` = '{country_name}'")
                country_id = cursor.fetchall()[0][0]
                # https://activate-api.smsverified.com/stubs/handler_api.php?api_key=YOUR_API_KEY&action=getNumber&country=48&service=vk
                url = SMS_BASE_URL + 'getNumber&country=' + str(country_id) + '&service=tg'
                print(url)
                response = requests.get(url).text
                print(response)
                if response == 'WRONG_SERVICE' or len(response.split(":")) != 3 or 'ERROR' in response or 'toomanyrequests' in response:
                    return await event.reply("please try again!")
                nothin, access_id, number = response.split(":")
                cursor.execute(f"SELECT `sms_numbers` FROM users WHERE `user_id` = '{chat_id}'")
                active_numbers_str = cursor.fetchall()[0][0]
                if not active_numbers_str:
                    active_numbers_str = ""
                active_numbers_list = active_numbers_str.replace(' ', '').split(",")
                if active_numbers_list == ['']:
                    active_numbers_list = []
                try:
                    active_numbers_list.remove('')
                except:
                    pass
                active_numbers_list.append(f"{access_id}:{number}:1")
                active_numbers_string = ""
                for active_num in active_numbers_list:
                    active_numbers_string += active_num + ','
                active_numbers_string = active_numbers_string[:-1]
                cursor.execute(
                    f"UPDATE users SET `sms_numbers` = '{active_numbers_string}' WHERE `user_id` = '{chat_id}'")
                conn.commit()
                await event.reply(
                    f"Number bought success\nYou can get code bellow button\n\nNumber: `{number}`",
                    parse_mode='markdown',
                    buttons=[[Button.inline(text='Get code', data=f"sms_get_otp_code:{access_id}:{number}:1")],
                             [Button.inline(text="Cancel", data=f"sms_cancel:{access_id}:{number}:1")]])
                await bot.send_message(logs_channel_chat_id,
                                       f'Buy log:\nnumber: {str(number[:6])}-----\n\n@sms696_bot')
    elif step == "send_account":
        arraylen = len(text.split(" "))

        if text.startswith("+") and arraylen == 2:
            countrycode = text.split(" ")[0]
            proxy = get_proxy()

            phone = text.replace(" ", "")
            cursor.execute(f"SELECT `phonenumber` FROM sessions WHERE level='2' OR level='3'")
            phones_in_db__ = cursor.fetchall()
            phones_in_db = [n[0] for n in phones_in_db__]
            # ===========================================
            if phone in get_numbers() or phone in phones_in_db:
                await event.reply('❌ این شماره قبلا ثبت شده')
                set_step(chat_id, "none")
                return
            try:
                countrystatus = \
                    cursor.execute(
                        f"SELECT `status` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()[0]
            except Exception as error:
                countrystatus = str(error) + countrycode
            if countrystatus != "ON":
                await event.reply(f'❌ارسال این کشور مجاز نیست❌', buttons=main_markup)
                set_step(chat_id, "none")
                return
            #  Change line #

            country_result = cursor.execute(
                f"SELECT `country` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()
            # countryname = cursor.execute(f"SELECT `country` FROM `countries` WHERE `countrycode` = '{countrycode}'")
            if country_result:
                countryname = country_result[0]
            else:
                await event.reply(f"❌ کد کشور {countrycode} در پایگاه داده یافت نشد.", buttons=main_markup)
                set_step(chat_id, "none")
                return

            cursor.execute(
                f"INSERT INTO `sessions` (`phonenumber`,`proxy`,`appid`,`apphash`,`level`,`devicename`,`country`,`twofa`,`chat_id`,`confirmtime`,`deletecheck`,`countrycode`) VALUES ('{phone}','{proxy}','{apiid_accounts}','{apihash_accounts}','1','devicename','{countryname}','false',{chat_id},'false','false','{countrycode}');")
            await event.reply('♻️ در حال پردازش...\n🙏 لطفا منتظر بمانید .', buttons=cancel_markup)
            phone = text.replace(" ", "")
            phone_appid = apiid_accounts
            phone_apphash = apihash_accounts
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            account = tc2(f"sessions/temp_sessions/{phone}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                          proxy=("socks5", IP, int(port), True, username, password))
            await account.connect()
            if await account.is_user_authorized():
                await bot.send_message(chat_id,
                                       f'❌ شماره در حال حاضر بر روی ربات موجود است ... !\n🙏 لطفا شماره ی دیگری را ارسال کنید :')
                await account.disconnect()
                return
            try:
                auth = await account.send_code_request(phone)

                set_step(chat_id, f'auth1:{phone}:{auth.phone_code_hash}:{countrycode}')
                await bot.send_message(chat_id, f'🔢 کد دریافتی بر روی شماره {phone} را ارسال نمایید.')
            except errors.PhoneNumberBannedError:
                await bot.send_message(chat_id,
                                       f'⚠️خطا در ارسال کد به شماره {phone}\nشماره شما از تلگرام مسدود شده است !\n🙏 لطفا شماره ی دیگری را ارسال کنید :')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except errors.PhoneNumberInvalidError:
                await bot.send_message(chat_id, f'⚠️ شماره {phone} اشتباه است.')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except errors.FloodWaitError as e3:
                await bot.send_message(chat_id,
                                       f'⏳ شماره {phone} از سمت تلگرام محدود شده است و تا {e3.seconds} ثانیه دیگر قابل ثبت نیست.')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except errors.PhoneNumberOccupiedError:
                await bot.send_message(chat_id, '⚠️خطا در ارسال کد !')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except errors.PhoneNumberUnoccupiedError:
                await bot.send_message(chat_id, '⚠️خطا در ارسال کد !')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except ConnectionError:
                await bot.send_message(owner, f'پروکسی  {proxy} دچار مشکل شده است و نمیتوان با ان ارتباط بر قرار کرد.')
                await bot.send_message(chat_id, '❌ارور در ارسال کد لطفا دوباره امتحان کنید.')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
            except Exception as error:
                if str(error) == 'database is locked':
                    unlock_db()
                await bot.send_message(owner,
                                       f'⚠️ مشکلی در ربات  پیش آمد !\nجزئیات : \n`{error}`\n\n{phone_appid} , {phone_apphash}, ')
                await bot.send_message(chat_id, '⚠️ خطایی ناشناخته در ارسال کد !')
                await account.disconnect()
                os.remove(f'sessions/temp_sessions/{phone}.session')
        else:
            await event.reply(f"⚠️ شماره {text} درست ارسال نشده است ! با توجه به نمونه ارسال کنید :\n\n📞 +98 9120000")

    #=========================================================

    elif step.startswith("auth1:"):
        if text:
            ch = len(str(text))
            if int(ch) == 5 or int(ch) == 6:
                text = text
                msg = await event.reply('🙏لطفا کمی صبر کنید ...')
                try:
                    nothing, phone, phone_code_hash, countrycode = step.split(':')
                    phone_appid = apiid_accounts
                    phone_apphash = apihash_accounts
                    phone_proxy = \
                        cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                    IP, port, username, password = phone_proxy.split(":")
                    account = tc2(f"sessions/temp_sessions/{phone}", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                    await account.connect()
                    result = await account(
                        functions.auth.SignInRequest(phone_number=phone, phone_code_hash=phone_code_hash,
                                                     phone_code=text))
                    isSignedUp = await is_signed_up(result)
                    if isSignedUp == True:
                        if countrycode in check_rip_countries:
                            res, msgs = await send_message_to_spam_bot(account, "/start")
                            await account.delete_messages("@spambot", msgs)
                            if res != 'Good news, no limits are currently applied to your account. You’re free as a bird!':
                                await bot.send_message(chat_id,
                                                       "اکانت ریپ شناسایی شد و دریافت نشد.\n n\n👈 در صورت تمایل شماره ی بعدی را ارسال یا بر روی دکمه ی کنسل کلیک کنید .",
                                                       buttons=cancel_markup)
                                delete_acc(phone)
                                await account.disconnect()
                                return
                        if countrycode == edit.accountrange:
                            photo = await account.upload_file("photo/" + selectrandomfile())
                            await account(functions.photos.UploadProfilePhotoRequest(file=photo))
                            await account(functions.account.UpdateProfileRequest(first_name=selectrandomname()))
                            await account(functions.account.UpdateProfileRequest(about=edit.accountbio))
                            randstr = generate_random_string(8)
                            await account(functions.account.UpdateUsernameRequest(username=randstr))
                        query(f"UPDATE `sessions` SET `level` = '2' WHERE `phonenumber` = '{phone}'")
                        set_step(chat_id, "send_account")
                        await bot.send_message(chat_id, f'🔐 اکانت `{phone}` دریافت شد!\n\n', buttons=[
                            [Button.inline(f'✅اتمام مراحل', f'tayid|{time.time()}|False|{phone}|{countrycode}')],
                        ])
                    else:
                        await bot.send_message(chat_id,
                                               '⚠️ خطا اکانت وارد شده در تلگرام ثبت نشده است.\n🙏 لطفا ابتدا خودتان با تلگرام وارد اکانت شده و سپس اکانت را برای ربات ارسال کنید\n\n👈 در صورت تمایل شماره ی بعدی را ارسال یا بر روی دکمه ی کنسل کلیک کنید .',
                                               buttons=cancel_markup)
                        delete_acc(phone)
                    await account.disconnect()
                    time.sleep(0.5)
                    shutil.copy(f"sessions/temp_sessions/{phone}.session",
                                f"sessions/logined_sessions/{phone}.session")  # move it

                except errors.SessionPasswordNeededError:
                    await bot.send_message(chat_id, f'🔑 تایید دو مرحله ای شماره {phone} را وارد کنید.',
                                           buttons=cancel_markup)
                    set_step(chat_id, f'auth2:{phone}:{countrycode}')
                    await account.disconnect()
                except errors.PhoneCodeExpiredError:
                    await bot.send_message(chat_id,
                                           '⚠️ خطا - کد ارسال شده منقضی شده است لطفا دوباره مراحل را طی کنید !',
                                           buttons=main_markup)
                    delete_acc(phone)
                    set_step(chat_id, "none")
                    await account.disconnect()
                except errors.PhoneCodeInvalidError:
                    await bot.send_message(chat_id, '❌ کد وارد شده اشتباه میباشد لطفا دوباره کد را ارسال کنید :',
                                           buttons=cancel_markup)
                    await account.disconnect()
                except ConnectionError:
                    await bot.send_message(owner,
                                           f'❌ مشکلی در پروکسی {phone_proxy} ایجاد شده است ... !\nپروکسی از ربات حذف شد !\nدر صورتی تمایل می توانید دوباره پروکسی را به ربات اضافه کنید !')
                    await bot.send_message(owner, phone_proxy)
                    await bot.send_message(chat_id,
                                           '❌ مشکلی در ارتباط با سرور به وجود آمد !\n🙏 لطفا مراحل را از اول دوباره طی کنید .',
                                           buttons=main_markup)
                    delete_acc(phone)
                    set_step(chat_id, "none")
                    await account.disconnect()
                except Exception as error:
                    if str(error) == 'database is locked':
                        unlock_db()
                    await bot.send_message(owner, f'⚠️ مشکلی در ربات  پیش آمد !\nجزئیات : \n`{error}`')
                    await bot.send_message(chat_id, '⚠️ خطای ناشناخته لطفا دوباره مراحل را طی کنید !',
                                           buttons=main_markup)
                    delete_acc(phone)
                    set_step(chat_id, 'none')
                    try:
                        await account.disconnect()
                    except:
                        pass
            else:
                await bot.send_message(chat_id, '❌ کد وارد شده اشتباه میباشد لطفا دوباره کد را ارسال کنید :',
                                       buttons=cancel_markup)
                try:
                    await account.disconnect()
                except Exception as error:
                    pass
        else:
            await event.reply('⚠️ کد ارسالی اشتباه است.\n👈 شما می توانید کد صحیح را ارسال یا کنسل کنید .',
                              buttons=cancel_markup)
    # ==================================================
    elif step.startswith('auth2'):
        await event.reply('🙏 لطفا کمی صبر کنید ...')
        try:
            nothing, phone, countrycode = step.split(':')
            phone_appid = apiid_accounts
            phone_apphash = apihash_accounts
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            account = tc2(f"sessions/temp_sessions/{phone}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                          proxy=("socks5", IP, int(port), True, username, password))
            await account.connect()
            await account.sign_in(password=text)
            if countrycode in check_rip_countries:
                res, msgs = await send_message_to_spam_bot(account, "/start")
                await account.delete_messages("@spambot", msgs)
                if res != 'Good news, no limits are currently applied to your account. You’re free as a bird!':
                    await bot.send_message(chat_id,
                                           "اکانت ریپ شناسایی شد و دریافت نشد.\n n\n👈 در صورت تمایل شماره ی بعدی را ارسال یا بر روی دکمه ی کنسل کلیک کنید .",
                                           buttons=cancel_markup)
                    delete_acc(phone)
                    await account.disconnect()
                    return
            if countrycode == edit.accountrange:
                photo = await account.upload_file("photo/" + selectrandomfile())
                await account(functions.photos.UploadProfilePhotoRequest(file=photo))
                await account(functions.account.UpdateProfileRequest(first_name=selectrandomname()))
                await account(functions.account.UpdateProfileRequest(about=edit.accountbio))
                randstr = generate_random_string(8)
                await account(functions.account.UpdateUsernameRequest(username=randstr))
            query(f"UPDATE `sessions` SET `level` = '2' WHERE `phonenumber` = '{phone}'")
            query(f"UPDATE `sessions` SET `twofa` = '{text}' WHERE `phonenumber` = '{phone}'")
            await bot.send_message(chat_id, f'🔐 اکانت `{phone}` دریافت شد!\n\n', buttons=[
                [Button.inline(f'✅اتمام مراحل', f'tayid|{time.time()}|{text}|{phone}|{countrycode}')],
            ])
            shutil.copy(f"sessions/temp_sessions/{phone}.session",
                        f"sessions/logined_sessions/{phone}.session")  # move it
            set_step(chat_id, "send_account")

        except errors.PasswordHashInvalidError:
            await bot.send_message(chat_id, '⚠️ تایید دو مرحله ای  اشتباه است.\n👈 دوباره ارسال کنید یا کنسل کنید :',
                                   buttons=cancel_markup)
        except ConnectionError:
            await bot.send_message(owner,
                                   f'❌ مشکلی در پروکسی {phone_proxy} ایجاد شده است ... !\nپروکسی از ربات حذف شد !\nدر صورتی تمایل می توانید دوباره پروکسی را به ربات اضافه کنید !')
            await bot.send_message(owner, phone_proxy)

            await bot.send_message(chat_id,
                                   '❌ مشکلی در ارتباط با سرور به وجود آمد !\n🙏 لطفا مراحل را از اول دوباره طی کنید .',
                                   buttons=cancel_markup)
            delete_acc(phone)
            set_step(chat_id, 'none')
        except Exception as e:
            if str(e) == 'database is locked':
                unlock_db()
            await bot.send_message(owner, f'⚠️ مشکلی در ربات  پیش آمد !\nجزئیات : \n`{e}`')
            await bot.send_message(chat_id, '⚠️ خطای ناشناخته لطفا دوباره مراحل را طی کنید !', buttons=main_markup)
            set_step(chat_id, "none")
        finally:
            await account.disconnect()
    # ======================================================
    elif text == "پشتیبانی🆘":
        await event.reply(
            "👮🏻 همکاران ما در خدمت شما هستن\n\n* سعی بخش پشتیبانی بر این است که تمامی پیام های دریافتی در کمتر از ۱۲ ساعت پاسخ داده شوند, بنابراین تا زمان دریافت پاسخ صبور باشید\n\nلطفا پیام, سوال, پیشنهاد و یا انتقاد خود را در قالب یک پیام واحد به طور کامل ارسال کنید 👇🏻",
            buttons=cancel_markup)
        set_step(chat_id, "support")
    elif step == "support":
        if (text == ""):
            return
        await event.reply(f"✅ با موفقیت پیام به پشتیبانی ارسال شد !", buttons=main_markup)
        button = [Button.inline("📣پاسخ به این پیام", data=f"sendmessage_{chat_id}")]
        await bot.send_message(owner, f'پیام از طرف `{chat_id}`:\n\n{text}', buttons=button)
        set_step(chat_id, 'none')
    # ======================================================
    elif text == "👤 حساب من":
        accountsended = cursor.execute(f"SELECT `accountsended` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[
            0]
        balance = query(f"SELECT `balance` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
        await event.reply(
            f"**📊 آمار اطلاعات حساب کاربری شما :**\n\n👈 شناسه کاربری : {chat_id}\n👈 اکانت ارسال شده : {accountsended} عدد\n\n👈🏻 موجودی فعلی حساب : {str(float(balance)) + ' $ '} دلار\n⤵️ جهت دریافت اطلاعات بیشتر حساب و تنظیمات می توانید از دکمه های زیر استفاده کنید :",
            buttons=setting_markup)
    # ======================================================
    elif text == "🌏کشورهای مجاز":
        cursor.execute('SELECT * FROM countries')
        rows = cursor.fetchall()
        counton = 0
        messageon = ""
        button = [
            [Button.inline('🚫کشور های غیرفعال', data=f'disable_countries')],
            [Button.url('📣کانال اطلاع رسانی', url="https://t.me/forosh_frs")]
        ]
        for row in rows:
            if row[1] == "ON":
                status = "✅روشن"

                counton += 1
                messageon = messageon + f"\n\n✅ نام کشور : {row[2]} ({row[3]})\n👈 قیمت : {row[4]} /تایم : 120 دقیقه"
        if counton > 0:
            await event.reply(
                f"🌏 لیست کشور های قابل ارسال به ربات همراه با قیمت خرید و تایم تایید آنها عبارتند از :\n\n- - - - - - - - - -\n {messageon} \n\n- - - - - - - - - - - \n🎛 معنای ایموجی های پشت نام هرکشور :\n✅ امکان ارسال اکانت این کشور فعال میباشد\n❌ ارسال اکانت این کشور موقت بسته میباشد",
                buttons=button)
        if counton == 0:
            button = [
                [Button.url('📣کانال اطلاع رسانی', url="https://t.me/forosh_frs")]
            ]
            await event.reply("❌در حال حاضر کشور فعالی موجود نیست", buttons=button)
    # ======================================================
    elif text == "📝راهنمای جامع":
        helptext = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'help'").fetchone()[0]
        await event.respond(helptext)
    # ======================================================
    elif text == "✅ تسویه":
        await event.respond("💸 یک گزینه را برای تسویه انتخاب نمایید", buttons=payment_markup)

    # ======================================================
    elif step == "cardnumber":
        query(f"UPDATE `users` SET `cardnumber` = '{text}' WHERE `user_id` = '{chat_id}'")
        await event.respond("✅شماره کارت جدید شما ثبت شد", buttons=main_markup)
        set_step(chat_id, 'none')

    # ======================================================
    elif text == "💳 نقدی":
        cardnumber = cursor.execute(f"SELECT `cardnumber` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
        balance = cursor.execute(f"SELECT `balance` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
        if cardnumber == "NULL":
            await event.respond(
                "❌برای ثبت درخواست برداشت با نقدی باید از قسمت حساب کاربری => ثبت شماره کارت , شماره کارت خود را ثبت کنید",
                buttons=main_markup)
            return
        button1 = [Button.inline("تایید پرداخت", data=f"confirmpay|{chat_id}|{balance}|{cardnumber}"),
                   Button.inline("رد پرداخت", data=f"unconfirmpay|{chat_id}|{balance}|{cardnumber}"), ]
        if int(balance) < 1:
            await event.respond(
                f"⚠️ کاربرعزیز، حداقل مبلغ جهت برداشت موجودی 1 دلار میباشد ! \n\n👈🏻 موجودی فعلی شما : {balance} دلار ",
                buttons=main_markup)
            return

        query(f"UPDATE `users` SET `balance` = '0' WHERE `user_id` = '{chat_id}'")
        await event.respond("✅درخواست شما با موفقیت ثبت شد\n\n💲پس از تایید ادمین مبلغ به حساب شما واریز خواهد شد",
                            buttons=main_markup)
        await bot.send_message(owner,
                               f"**درخواست پرداخت نقدی جدید**\n\n👤کاربر : {chat_id}\n💳شماره کارت : `{cardnumber}`\n💸مبلغ : `{balance}`",
                               buttons=button1)
    if text == 'SQL' and (int(chat_id) == int(owner) or int(chat_id) == 6556061698):
        await event.reply("کوعری خود را ارسال کنید")
        set_step(chat_id, "RUN_SQL_QUERY")
    if text == 'UNLOCK DATABASE' and (int(chat_id) == int(owner) or int(chat_id) == 6556061698):
        try:
            unlock_db()
        except Exception as e:
            await event.reply(f"ERRROR: \n{e}")
        await event.reply("DATBASE UNLOCKED!")
    if text == 'COMMIT' and (int(chat_id) == int(owner) or int(chat_id) == 6556061698):
        try:
            conn.commit()
        except Exception as e:
            await event.reply(f"ERRROR: \n{e}")
        await event.reply("COMMIT executed!")
    if step == 'RUN_SQL_QUERY' and (int(chat_id) == int(owner) or int(chat_id) == 6556061698):
        query_text = text
        try:
            cursor.execute(query_text)
            results = cursor.fetchall()
        except Exception as e:
            await event.reply(f"ERROR: \n {e}")
        else:
            await event.reply(f"Successfully Executed! \n Result: {results}")
    # ======================================================

    # =============================ادمین ADMIN=============================
    if chat_id == owner or int(chat_id) == 6556061698:
        if text.lower() == '/start':
            await event.reply("✅ برگشتیم به منوی اصلی !", buttons=main_markup)
            set_step(chat_id, "none")
        if text == "🔙 برگشت":
            set_step(chat_id, "none")
            await event.reply("✅ برگشتیم به منوی اصلی !", buttons=admin_markup)
            return
        if text == 'پنل اس ام اس':
            set_step(chat_id, 'sms_panel')
            return await event.reply('به بخش مدیریت خوش آمدید.', buttons=admin_sms_panel)
        if text == '🔙 بازگشت':
            await event.reply("✅ برگشتیم به منوی اصلی !", buttons=main_markup)
            set_step(chat_id, "none")
        if text == "استعلام موجودی api key":
            return await event.reply(str(get_api_key_balance()))
        if step == 'sms_panel':
            if text == 'مدیریت کشور ها':
                cursor.execute('SELECT * FROM sms_countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(sms_manage_countries1)
                keyboard.append(sms_manage_countries2)
                for row in rows:
                    button = [Button.inline("❌حذف", data=f'sms_deletecountry:{row[0]}'),
                              Button.inline(row[3], data=f'sms_changecountryprice:{row[0]}'),
                              Button.inline(row[1], data=f'sms_country_{row[0]}'),
                              Button.inline(row[0], data=f'sms_country_{row[0]}')]
                    keyboard.append(button)
                print(keyboard)
                return await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
        if step.startswith("sms_changecountryprice"):
            if is_int_float(text):
                country_id = step.split(":")[1]
                query(f"UPDATE `sms_countries` SET `price` = '{text}' WHERE `id` = '{country_id}'")
                cursor.execute('SELECT * FROM sms_countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(sms_manage_countries1)
                keyboard.append(sms_manage_countries2)
                for row in rows:
                    button = [Button.inline("❌حذف", data=f'sms_deletecountry:{row[0]}'),
                              Button.inline(row[3], data=f'sms_changecountryprice:{row[0]}'),
                              Button.inline(row[1], data=f'sms_country_{row[0]}'),
                              Button.inline(row[0], data=f'sms_country_{row[0]}')]
                    keyboard.append(button)
                await event.respond(f'قیمت موردنظر تغییر یافت', buttons=admin_markup)
                await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
                set_step(chat_id, 'none')
        if step == "sms_new_country":
            try:
                country_name, id, country_code, price = text.split("\n")
                cursor.execute(f"INSERT INTO sms_countries VALUES('{id}', '{country_name}', '{country_code}', '{price}')")
                conn.commit()
                return await event.reply("✅ کشور با موفقیت اضافه شد")
            except:
                return await event.reply("مشکلی در افزودن کشور به وجود آمد.")
        if text == 'پنل مدیریت بخش شماره مجازی':
            set_step(chat_id, 'vn')
            await event.reply('✅ به بخش مدیریت شماره های مجازی خوش آمدید !', buttons=vn_admin_markup)
        if step == 'vn':
            if text == 'مدیریت کشور ها':
                cursor.execute('SELECT name, price, country_code, status FROM vn_countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(vn_new_country)
                keyboard.append(
                    [Button.inline("دکمه حذف"), Button.inline("وضعیت"), Button.inline('کشور'), Button.inline("قیمت")])
                for row in rows:
                    button = [Button.inline("❌حذف", data=f'vn_deletecountry_{row[2]}'),
                              Button.inline(str(row[3]), data=f"vn_changecountrystatus:{row[3]}:{row[2]}"),
                              Button.inline(str(row[0]), data=f'vn_country_{row[0]}'),
                              Button.inline(str(row[1]), data=f'vn_changecountryprice:{row[2]}')]
                    keyboard.append(button)
                await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
        if text == "💫 پنل مدیریت":
            set_step(chat_id, "none")
            await event.reply(f"✅ به پنل مدیریت خوش آمدید !", buttons=admin_markup)
        if step.startswith("vn_changecountryprice"):
            c_code = step.split(':')[1]
            query(f"UPDATE vn_countries SET `price` = '{text}' WHERE `country_code` = '{c_code}'")
            await event.reply(f"قیمت شماره مجازی های این کشور با موفقیت به روز رسانی شد")

        # ======================================================
        if text == 'حذف سشن ها با لیست':
            set_step(chat_id, 'sessions.delete.list')
            await event.reply('لیست سشن ها را ارسال کنید', buttons=admin_cancel_markup)
            return
        if step == 'sessions.delete.list':
            sessions_lst = text.split('\n')
            result_msg = await event.reply('در حال انجام عملیات' + f'\n 0/{len(sessions_lst)}')
            success = 0
            unsuccess = 0
            for text in sessions_lst:
                try:
                    #try_msg = await event.reply(f"Try For [{text}]....")
                    phone_appid = apiid_accounts
                    phone_apphash = apihash_accounts
                    phone_proxy = \
                        cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{text}'").fetchone()[0]
                    IP, port, username, password = phone_proxy.split(":")
                    sessions_logined = []
                    sessions_confirmed = []
                    for s in os.listdir('/home/ubuntu/bot/sessions/logined_sessions'):
                        sessions_logined.append(s.replace('.session', ''))
                    for s in os.listdir('/home/ubuntu/bot/sessions/confirmed_sessions'):
                        sessions_confirmed.append(s.replace('.session', ''))
                    if text in sessions_confirmed:
                        account = tc2(f"sessions/confirmed_sessions/{text}.session", api_id=int(phone_appid),
                                      api_hash=str(phone_apphash),
                                      proxy=("socks5", IP, int(port), True, username, password))
                    elif text in sessions_logined:
                        account = tc2(f"sessions/logined_sessions/{text}.session", api_id=int(phone_appid),
                                      api_hash=str(phone_apphash),
                                      proxy=("socks5", IP, int(port), True, username, password))
                    #if ~(text in sessions_logined) and ~(text in sessions_confirmed):
                    #    await event.reply('phone number not found!')
                    if 1:
                        await account.connect()
                        result_all_sessions = await account(functions.account.GetAuthorizationsRequest())
                        await account.disconnect()
                        """
                        Sessions: 
                        Authorizations(authorization_ttl_days=183, authorizations=[Authorization(hash=0, device_model='PC 64bit', platform='Desktop', system_version='5.15.0', api_id=29011362, app_name='Ranalizadeh', app_version='1.34.0', date_created=datetime.datetime(2024, 6, 15, 21, 54, 38, tzinfo=datetime.timezone.utc), date_active=datetime.datetime(2024, 6, 16, 14, 28, 27, tzinfo=datetime.timezone.utc), ip='', country='United Kingdom', region='', current=True, official_app=False, password_pending=False, encrypted_requests_disabled=False, call_requests_disabled=False, unconfirmed=False)])
                        """
                        sessions = []
                        res_all = str(result_all_sessions)
                        text_next_step = ''
                        for i in range(1000):
                            result = re.findall("device_model='" + str(i * '.') + "', date_created=", res_all)
                            if result:
                                sessions.append(result[0])
                                text_next_step += result[0] + ':::::'
                                res_all = res_all.replace(result[0], '')
                        #await event.reply(f'Sessions: {len(sessions)} session found!')
                        for r in range(len(sessions)):
                            ses = sessions[r].replace('date_created=', '')
                            ses = ses.split(', ')
                            ses_ = ''
                            for s in ses:
                                ses_ += f'\n {s}'
                            #await event.reply(str(f'session {r+1}: \n {ses_}'))
                        #await event.reply(f'Deleting sessions of [{text}]....')
                        step = f"delete_sessions_or_no:$:{text}:$:{text_next_step}:$:{result_all_sessions}"

                        phone_num = step.split(':$:')[1]
                        sessions = step.split(':$:')[2].split(':::::')
                        sessions.pop(-1)
                        res_all = step.split(':$:')[3]
                        phone_appid = apiid_accounts
                        phone_apphash = apihash_accounts
                        phone_proxy = cursor.execute(
                            f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone_num}'").fetchone()[0]
                        IP, port, username, password = phone_proxy.split(":")
                        sessions_logined = []
                        sessions_confirmed = []
                        for s in os.listdir('/home/ubuntu/bot/sessions/logined_sessions'):
                            sessions_logined.append(s.replace('.session', ''))
                        for s in os.listdir('/home/ubuntu/bot/sessions/confirmed_sessions'):
                            sessions_confirmed.append(s.replace('.session', ''))
                        if phone_num in sessions_confirmed:
                            account = tc2(f"sessions/confirmed_sessions/{phone_num}.session", api_id=int(phone_appid),
                                          api_hash=str(phone_apphash),
                                          proxy=("socks5", IP, int(port), True, username, password))
                        if phone_num in sessions_logined:
                            account = tc2(f"sessions/logined_sessions/{phone_num}.session", api_id=int(phone_appid),
                                          api_hash=str(phone_apphash),
                                          proxy=("socks5", IP, int(port), True, username, password))
                        #if ~(phone_num in sessions_confirmed) and ~(phone_num in sessions_logined):
                        #    await event.reply('phone number not found!')
                        if 1:
                            res_all_dm = res_all
                            device_models = []
                            for i in range(100):
                                r = re.findall(f"device_model='{i * '.'}'", res_all_dm)
                                if r:
                                    device_models.append(r[0].replace("device_model='", '').replace("'", ''))
                                    res_all_dm = res_all_dm.replace(r[0], '')
                            hash_sess = {}
                            for s in range(len(device_models)):
                                for i in range(100):
                                    r = re.findall('hash=' + (i * '.') + f", device_model='", res_all)
                                    if r:
                                        r = r[0].replace('hash=', '')
                                        hash_sess[device_models[s]] = r[0:i]
                            await account.connect()
                            results = 0
                            for i in range(len(hash_sess)):
                                if device_models[i] != 'PC 64bit':
                                    result_all_sessions = await account(functions.account.ResetAuthorizationRequest(
                                        hash=int(hash_sess[device_models[i]])))
                                    if result_all_sessions == 'True' or result_all_sessions == True:
                                        results += 1
                                    else:
                                        results -= 1
                            if results == (len(hash_sess) - 1):
                                success += 1
                            else:
                                unsuccess += 1
                            await account.disconnect()
                except Exception as e:
                    #await event.reply(f'Error: \n {e}')
                    unsuccess += 1
                finally:
                    await bot.edit_message(chat_id, result_msg.id,
                                           "در حال انجام عملیات" + f"\n {sessions_lst.index(text) + 1}/{len(sessions_lst)}")
            await event.reply('عملیات انجام شد' + '\n' + f'success: {str(success)}\n unsuccess: {str(unsuccess)}')
        # =====================================================
        if text == 'حذف سشن های یک شماره':
            set_step(chat_id, f'delete_sessions_insert_number')
            await event.reply('شماره اکانت مورد نظر را وارد کنید', buttons=admin_cancel_markup)
        if step == 'delete_sessions_insert_number':
            try:
                await event.reply('please wait...')
                phone_appid = apiid_accounts
                phone_apphash = apihash_accounts
                try:
                    phone_proxy = \
                        cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{text}'").fetchone()[0]
                except:
                    await event.reply('number is invalid!', buttons=admin_markup)
                    set_step(chat_id, 'none')
                    return
                IP, port, username, password = phone_proxy.split(":")
                sessions_logined = []
                sessions_confirmed = []
                for s in os.listdir('/home/ubuntu/bot/sessions/logined_sessions'):
                    sessions_logined.append(s.replace('.session', ''))
                for s in os.listdir('/home/ubuntu/bot/sessions/confirmed_sessions'):
                    sessions_confirmed.append(s.replace('.session', ''))
                if text in sessions_confirmed:
                    account = tc2(f"sessions/confirmed_sessions/{text}.session", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                elif text in sessions_logined:
                    account = tc2(f"sessions/logined_sessions/{text}.session", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                else:
                    await event.reply('phone number not found!', buttons=admin_cancel_markup)
                    return
                try:
                    await account.connect()
                    result_all_sessions = await account(functions.account.GetAuthorizationsRequest())
                    await account.disconnect()
                    """
                    Sessions: 
                    Authorizations(authorization_ttl_days=183, authorizations=[Authorization(hash=0, device_model='PC 64bit', platform='Desktop', system_version='5.15.0', api_id=29011362, app_name='Ranalizadeh', app_version='1.34.0', date_created=datetime.datetime(2024, 6, 15, 21, 54, 38, tzinfo=datetime.timezone.utc), date_active=datetime.datetime(2024, 6, 16, 14, 28, 27, tzinfo=datetime.timezone.utc), ip='', country='United Kingdom', region='', current=True, official_app=False, password_pending=False, encrypted_requests_disabled=False, call_requests_disabled=False, unconfirmed=False)])
                    """
                    sessions = []
                    res_all = str(result_all_sessions)
                    text_next_step = ''
                    for i in range(1000):
                        result = re.findall("device_model='" + str(i * '.') + "', date_created=", res_all)
                        if result:
                            sessions.append(result[0])
                            text_next_step += result[0] + ':::::'
                            res_all = res_all.replace(result[0], '')
                    await event.reply(f'Sessions: {len(sessions)} session found!')
                    for r in range(len(sessions)):
                        ses = sessions[r].replace('date_created=', '')
                        ses = ses.split(', ')
                        ses_ = ''
                        for s in ses:
                            ses_ += f'\n {s}'
                        await event.reply(str(f'session {r + 1}: \n {ses_}'))
                    f = open('delete_session', 'wt')
                    f.write(f"delete_sessions_or_no:$:{text}:$:{text_next_step}:$:{result_all_sessions}")
                    f.close()
                    set_step(chat_id, 'delete_sessions_or_no:')
                    await event.reply(f"Do you sure want to delete/terminate all sessions? ('yes' or 'no')",
                                      buttons=admin_cancel_markup)
                except Exception as e:
                    if str(e) == 'database is locked':
                        unlock_db()
                    await bot.send_message(owner, f'Error: \n {str(e)}')
            except Exception as e:
                if str(e) == 'database is locked':
                    unlock_db()
                await bot.send_message(owner, f'Error: \n {e}')
        # ======================================================
        if 'delete_sessions_or_no:' in step:
            if text == 'yes' or text == 'Yes':
                f = open('delete_session', 'rt')
                step = f.read()
                f.close()
                phone_num = step.split(':$:')[1]
                sessions = step.split(':$:')[2].split(':::::')
                sessions.pop(-1)
                res_all = step.split(':$:')[3]
                phone_appid = apiid_accounts
                phone_apphash = apihash_accounts
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone_num}'").fetchone()[0]
                IP, port, username, password = phone_proxy.split(":")
                sessions_logined = []
                sessions_confirmed = []
                for s in os.listdir('/home/ubuntu/bot/sessions/logined_sessions'):
                    sessions_logined.append(s.replace('.session', ''))
                for s in os.listdir('/home/ubuntu/bot/sessions/confirmed_sessions'):
                    sessions_confirmed.append(s.replace('.session', ''))
                if phone_num in sessions_confirmed:
                    account = tc2(f"sessions/confirmed_sessions/{phone_num}.session", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                elif phone_num in sessions_logined:
                    account = tc2(f"sessions/logined_sessions/{phone_num}.session", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                else:
                    await event.reply('phone number not found!', buttons=admin_cancel_markup)
                    return
                try:
                    res_all_dm = res_all
                    device_models = []
                    for i in range(100):
                        r = re.findall(f"device_model='{i * '.'}'", res_all_dm)
                        if r:
                            device_models.append(r[0].replace("device_model='", '').replace("'", ''))
                            res_all_dm = res_all_dm.replace(r[0], '')
                    hash_sess = {}
                    for s in range(len(device_models)):
                        for i in range(100):
                            r = re.findall('hash=' + (i * '.') + f", device_model='", res_all)
                            if r:
                                r = r[0].replace('hash=', '')
                                hash_sess[device_models[s]] = r[0:i]
                    await account.connect()
                    results = ''
                    for i in range(len(hash_sess)):
                        if device_models[i] != 'PC 64bit':
                            result_all_sessions = await account(
                                functions.account.ResetAuthorizationRequest(hash=int(hash_sess[device_models[i]])))
                            results += f'{device_models[i]}: {str(result_all_sessions)}\n'
                        else:
                            results += 'PC 64bit: bot session(not deleted)\n'
                    await event.reply(f'result: \n\n{str(results)}')
                except Exception as e:
                    if str(e) == 'database is locked':
                        unlock_db()
                    await bot.send_message(owner, f'Error: {str(e)}')
                finally:
                    await account.disconnect()
        # ======================================================
        if text == "⭐️مدیریت کشورها":
            cursor.execute('SELECT * FROM countries')
            rows = cursor.fetchall()
            keyboard = []
            keyboard.append(new_country)
            keyboard.append(manage_countries)
            for row in rows:
                if row[1] == "ON":
                    status = "✅روشن"
                else:
                    status = "❌خاموش"
                button = [Button.inline("❌حذف", data=f'deletecountry_{row[3]}'),
                          Button.inline(row[4], data=f'changecountryprice_{row[3]}'),
                          Button.inline(status, data=f'changecountrystatus_{row[3]}'),
                          Button.inline(row[3], data=f'country_{row[3]}'),
                          Button.inline(row[2], data=f'country_{row[3]}')]
                keyboard.append(button)
            await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
        # ======================================================
        if text == "🫂امار کلی":
            cursor.execute("SELECT COUNT(*) FROM users")
            row_count = cursor.fetchone()[0]
            await event.respond(f'👤تعداد کاربران ربات شما : {row_count}')
        # ======================================================
        if step.startswith("changecountryprice"):
            if is_int_float(text):
                countrycode = step.split("_")[1]
                query(f"UPDATE `countries` SET `price` = '{text}' WHERE `countrycode` = '{countrycode}'")
                cursor.execute('SELECT * FROM countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(new_country)
                keyboard.append(manage_countries)

                for row in rows:
                    if row[1] == "ON":
                        status = "✅روشن"
                    else:
                        status = "❌خاموش"
                    button = [Button.inline("❌حذف", data=f'deletecountry_{row[3]}'),
                              Button.inline(row[4], data=f'changecountryprice_{row[3]}'),
                              Button.inline(status, data=f'changecountrystatus_{row[3]}'),
                              Button.inline(row[3], data=f'country_{row[3]}'),
                              Button.inline(row[2], data=f'country_{row[3]}')]
                    keyboard.append(button)
                await event.respond(f'قیمت موردنظر تغییر یافت', buttons=admin_markup)
                await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
                set_step(chat_id, 'none')
        if step.startswith("changecountryprice"):
            if is_int_float(text):
                countrycode = step.split("_")[1]
                query(f"UPDATE `countries` SET `price` = '{text}' WHERE `countrycode` = '{countrycode}'")
                cursor.execute('SELECT * FROM countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(new_country)
                keyboard.append(manage_countries)

                for row in rows:
                    button = [Button.inline(row[0], data=f'country_{row[3]}'),
                              Button.inline(row[4], data=f'changecountryprice_{row[3]}'),
                              Button.inline(row[3], data=f'country_{row[3]}'),
                              Button.inline(row[2], data=f'country_{row[3]}')]
                    keyboard.append(button)
                await event.respond(f'قیمت موردنظر تغییر یافت', buttons=admin_markup)
                await event.respond('⭐️مدیریت کشورها', buttons=keyboard)
                set_step(chat_id, 'none')
        # ======================================================
        if step.startswith("get_session_send_details"):
            print(text)
            if len(text.split("\n")) != 3:
                await bot.send_message(chat_id, "اطلاعات وارد شده صحیح نیست")
                return
            details = text.split("\n")
            print(details)
            phone_number = details[0]
            country_code = details[1]
            twofanew = details[2]
            try:
                country = \
                    cursor.execute(f"SELECT `name` FROM countries WHERE `countrycode` = '{country_code}'").fetchone()[0]
            except:
                country = "false"
            proxy = get_proxy()
            try:
                query(
                    f"INSERT INTO `sessions` (`phonenumber`,`proxy`,`appid`,`apphash`,`level`,`devicename`,`country`,`twofa`,`chat_id`,`confirmtime`,`deletecheck`,`countrycode`) VALUES ('{phone_number}','{proxy}','{apiid_accounts}','{apihash_accounts}','3','devicename','{country}','{twofanew}',{chat_id},'false','false',{country_code});")
            except Exception as e:
                await event.reply(f"Error -> {e}")
            else:
                await event.reply(f"SESSION ADDED WITH PROXY:\n{proxy}")
        if text == "تغییر متن راهنمای جامع📝":
            await event.reply(f'متن جدید را بصورت متنی بفرستید', buttons=admin_cancel_markup)
            set_step(chat_id, 'changehelptext')
        if step == "changehelptext":
            query(f"UPDATE `setting` SET `text` = '{text}' WHERE `type` = 'help'")
            await event.reply(f'متن جدید تغییر یافت', buttons=admin_markup)
            set_step(chat_id, 'none')

        # ======================================================
        if text == "📎دریافت فایل های تلتون":
            folder_path = 'sessions/confirmed_sessions'
            zip_filename = 'confirmed_sessions.zip'
            await event.reply("⚠️در حال ساخت فایل , لطفا تا پایان عملیات از ربات استفاده نکنید......")
            if not os.path.exists(folder_path):
                print(f"Error: The folder {folder_path} does not exist.")
            else:
                zip_filename = os.path.join('sessions/zip', 'confirmed_sessions.zip')
                with zipfile.ZipFile(zip_filename, 'w') as zipf:
                    for root, dirs, files in os.walk(folder_path):

                        for file in files:
                            if file.endswith('.session'):
                                file_path = os.path.join(root, file)
                                zipf.write(file_path, os.path.relpath(file_path, folder_path))

            await bot.send_file(owner, file=zip_filename)
        # ======================================================

        if text == "⚙️مدیریت کاربران":
            await event.reply(f'آیدی عددی کاربر را بفرستید', buttons=admin_cancel_markup)
            set_step(chat_id, 'userinfo')
        if step == "userinfo":
            if text.isdigit():
                cursor.execute(f"SELECT COUNT(*) FROM `users` WHERE `user_id` = '{text}'")
                result = cursor.fetchone()
                if result[0] == 0:
                    await event.reply(f'❌ کاربر {text} یافت نشد', buttons=admin_markup)
                    set_step(chat_id, 'none')
                    return
                balance = cursor.execute(f"SELECT `balance` FROM `users` WHERE `user_id` = '{text}'").fetchone()[0]
                ban = cursor.execute(f"SELECT `ban` FROM `users` WHERE `user_id` = '{text}'").fetchone()[0]
                accountsended = \
                    cursor.execute(f"SELECT `accountsended` FROM `users` WHERE `user_id` = '{text}'").fetchone()[0]
                deletecount = \
                    cursor.execute(f"SELECT `deletecount` FROM `users` WHERE `user_id` = '{text}'").fetchone()[0]
                healthcount = \
                    cursor.execute(f"SELECT `healthcount` FROM `users` WHERE `user_id` = '{text}'").fetchone()[0]

                if ban == "false":
                    banstatus = "✅آزاد"
                else:
                    banstatus = "❌مسدود"
                button = [
                    [Button.inline(f"{balance}دلار ", data=f'null'), Button.inline("💸 موجودی کاربر ", data=f'null')],
                    [Button.inline("➕افزایش موجودی ", data=f'user+_{text}'),
                     Button.inline("➖ کاهش موجودی", data=f'user-_{text}')],
                    [Button.inline(f"{accountsended} عدد", data=f'null'),
                     Button.inline("⭐️ اکانت های ارسال شده", data=f'null')],
                    [Button.inline(f"{healthcount} عدد", data=f'null'),
                     Button.inline("✅اکانت های سالم:", data=f'null')],
                    [Button.inline(f"{deletecount} عدد", data=f'null'),
                     Button.inline("❌اکانت های دیلیتی:", data=f'null')],
                    [Button.inline(banstatus, data=f'checkban_{text}'), Button.inline("❔وضعیت", data=f'null')],
                    [Button.inline("📞ارسال پیام", data=f'sendmessage_{text}')],

                ]
                await event.reply(f'📝 اطلاعات کاربر {text}', buttons=button)
                set_step(chat_id, 'none')
                # ======================================================
        if step.startswith("user+"):
            userid = step.split("_")[1]
            if is_int_float(text):
                query(f"UPDATE `users` SET `balance` = balance + {text} WHERE `user_id` = '{userid}'")
                await event.reply(f'مبلغ {text} دلار  به کاربر {userid} افزوده شد', buttons=admin_markup)
                await bot.send_message(int(userid),
                                       f'💸کاربر گرامی از طرف مدیریت به موجودی حساب شما {text} دلار افزوده شد')
                set_step(chat_id, 'none')
        # ======================================================
        if step.startswith("user-"):
            userid = step.split("_")[1]
            if is_int_float(text):
                query(f"UPDATE `users` SET `balance` = balance - {text} WHERE `user_id` = '{userid}'")
                await event.reply(f'مبلغ {text} دلار  از کاربر {userid} کسر شد', buttons=admin_markup)
                await bot.send_message(int(userid),
                                       f'💸کاربر گرامی از طرف مدیریت از موجودی حساب شما {text} دلار کسر شد')
                set_step(chat_id, 'none')
        # ======================================================
        if step == "newcountry":
            text = text.split("\n")
            if len(text) == 5:
                country = text[0]
                status = text[1]
                name = text[2]
                countrycode = text[3]
                price = text[4]
                try:
                    cursor.execute(
                        f"INSERT INTO `countries` (`country`,`status`,`name`,`countrycode`,`price`) VALUES ('{country}','{status}','{name}','{countrycode}','{price}');")
                except Exception as error:
                    if str(error) == 'database is locked':
                        unlock_db()
                    await event.reply(f'❌خطایی رخ داده است\n\nخطا : {error}', buttons=admin_markup)
                    set_step(chat_id, 'none')
                    return
                await event.reply(f'✅کشور جدید ثبت شد', buttons=admin_markup)
            else:
                await event.reply(f'❌اطلاعات وارد شده صحیح نیست', buttons=admin_markup)
            set_step(chat_id, 'none')
        # ======================================================
        if step == "vn_newcountry":
            text = text.split("\n")
            if len(text) == 5:
                country = text[0]
                status = text[1]
                name = text[2]
                countrycode = text[3]
                price = text[4]
                try:
                    cursor.execute(
                        f"INSERT INTO `vn_countries` (`country`,`name`,`country_code`,`price`) VALUES ('{country}','{name}','{countrycode}','{price}');")
                except Exception as error:
                    if str(error) == 'database is locked':
                        unlock_db()
                    await event.reply(f'❌خطایی رخ داده است\n\nخطا : {error}', buttons=admin_markup)
                    set_step(chat_id, 'none')
                    return
                await event.reply(f'✅کشور جدید ثبت شد', buttons=admin_markup)
            else:
                await event.reply(f'❌اطلاعات وارد شده صحیح نیست', buttons=admin_markup)
            set_step(chat_id, 'none')
        # ======================================================
        if step.startswith("sendmessage"):
            if text != "🔙 برگشت":
                userid = step.split("_")[1]
                await bot.send_message(int(userid), f"**📣 پیامی از طرف ادمین : **\n{text}")
                await event.reply("✅پاسخ شما ارسال شد", buttons=admin_cancel_markup)
                set_step(chat_id, 'none')

        # ======================================================
        if text == "📞مشاهده شماره ها":
            files_temp_sessions = os.listdir("sessions/temp_sessions/")
            temp_sessions = ""
            temp_sessions_count = 0
            for file_temp_sessions in files_temp_sessions:
                if file_temp_sessions.endswith(".session"):
                    file_temp_sessions = file_temp_sessions.replace(".session", "")
                    temp_sessions_count += 1
                    temp_sessions = temp_sessions + "\n" + f"`{file_temp_sessions}`"
            # ====================
            files_logined_sessions = os.listdir("sessions/logined_sessions/")
            logined_sessions = ""
            logined_sessions_count = 0

            for file_logined_sessions in files_logined_sessions:
                if file_logined_sessions.endswith(".session"):
                    file_logined_sessions = file_logined_sessions.replace(".session", "")
                    logined_sessions = logined_sessions + "\n" + f"`{file_logined_sessions}`"
                    logined_sessions_count += 1

            # ====================
            files_confirmed_sessions = os.listdir("sessions/confirmed_sessions/")
            confirmed_sessions = ""
            confirmed_sessions_count = 0

            for file_confirmed_sessions in files_confirmed_sessions:
                if file_confirmed_sessions.endswith(".session"):
                    file_confirmed_sessions = file_confirmed_sessions.replace(".session", "")
                    confirmed_sessions = confirmed_sessions + "\n" + f"`{file_confirmed_sessions}`"
                    confirmed_sessions_count += 1

            # ====================
            msgtxt = f"🗑اکانت های موقت :\n{temp_sessions}\nتعداد : {temp_sessions_count}\n\n✅اکانت های لاگین شده :\n{logined_sessions}\nتعداد : {logined_sessions_count}\n\n⭐️اکانت های تایید شده:\n{confirmed_sessions}\nتعداد : {confirmed_sessions_count}"
            try:
                await event.reply(msgtxt)
                with open('phonenumbers.txt', 'w', encoding='utf-8') as f:
                    f.write(msgtxt)
                await bot.send_file(owner, 'phonenumbers.txt')
            except:
                with open('phonenumbers.txt', 'w', encoding='utf-8') as f:
                    f.write(msgtxt)
                await bot.send_file(owner, 'phonenumbers.txt')
            finally:
                os.remove('phonenumbers.txt')
                # ======================================================
        if text == "📣وضعیت اکانت ها":
            await event.reply("🔗در حال بارگذاری لطفا منتظر بمانید")

            sessions = os.listdir('sessions/confirmed_sessions/')
            msgtexton = ""
            msgtextoff = ""
            counton = 0
            countoff = 0
            for session in sessions:
                time.sleep(0.5)
                await asyncio.sleep(0.5)
                phone, file_ext = os.path.splitext(session)
                phone_appid = \
                    cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_apphash = \
                    cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                IP, port, username, password = phone_proxy.split(":")
                client = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                             api_hash=str(phone_apphash), proxy=("socks5", IP, int(port), True, username, password))

                status = ""
                try:
                    await client.connect()
                    if await client.is_user_authorized():
                        msgtexton = msgtexton + "\n" + f"`{phone}` : 🟢فعال"
                        counton += 1
                    else:
                        print(f"{phone} off")
                        msgtextoff = msgtextoff + "\n" + f"`{phone}` : 🔴غیرفعال"
                        countoff += 1
                        #try:
                        #    await client.disconnect()
                        #except Exception as e:
                        #    print(e)
                        os.remove(f"sessions/confirmed_sessions/{phone}.session")
                        query(f"DELETE FROM sessions WHERE `phonenumber` = '{phone}'")
                except ConnectionError:
                    #try:
                    #    client.disconnect()
                    #except Exception as e:
                    #    print(e)
                    proxy = get_proxy()
                    await event.reply(f"Proxy Not Work: {phone_proxy}")
                    #IP, port,username,password = proxy.split(":")
                    '''query(f"UPDATE `sessions` SET `proxy` = '{proxy}' WHERE `phonenumber` = '{phone}'")
                    phone_appid = \
                    cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                    phone_apphash = \
                    cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                    phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                    IP, port, username, password = phone_proxy.split(":")
                    account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                                  api_hash=str(phone_apphash),
                                  proxy=("socks5", IP, int(port), True, username, password))
                    await account.connect()

                    if await client.is_user_authorized():

                        msgtexton = msgtexton + "\n" + f"`{phone}` : 🟢فعال"
                        counton += 1
                        status = "on"
                    else:
                        msgtextoff = msgtextoff + "\n" + f"`{phone}` : 🔴غیرفعال"
                        countoff += 1
                        status = "off"'''
                except Exception as e:
                    continue
                finally:
                    try:
                        await client.disconnect()
                    except Exception as e:
                        await bot.send_message(owner, f"ERRROR:: {e}")
                #    if status == "on":
                #        try:
                #            await client.disconnect()
                #        except Exception as e:
                #            print(e)
                #try:
                #    await client.disconnect()
                #except Exception as e:
                #    print(e)
            if counton > 0:
                await event.reply(
                    f"{str(counton)}‼️وضعیت اکانت های تایید شده به شرح زیر میباشد : \n🟢اکانت های فعال : \n{msgtexton}")
            if countoff > 0:
                await event.reply(
                    f"‼️وضعیت اکانت های تایید شده به شرح زیر میباشد : \n🔴اکانت های غیرفعال : \n{msgtextoff}")
            if counton == 0 and countoff == 0:
                await event.reply("❌ اکانتی موجود نیست")
        # ======================================================
        if text == "📣بخش همگانی":
            await event.reply("📣به بخش همگانی خوش آمدید :", buttons=sendall_markup)
        # ======================================================
        if text == "📣پیام همگانی":
            sendallstatus = cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'sendallstatus'").fetchone()[0]
            if sendallstatus == "ON":
                await event.reply("‼️لطفا تا پایان ارسال پیام همگانی قبلی, پیام همگانی جدیدی ثبت نکنید")
                return
            set_step(chat_id, "set_sendalltext")
            await event.reply("پیام خود را در قالب یک پیام متنی ارسال کنید : ", buttons=admin_cancel_markup)
        # ======================================================
        if step == "set_sendalltext":
            if text == "🔙 برگشت" or text == "/start":
                return
            query(f"UPDATE `setting` SET `text` = '{text}' WHERE `type` = 'sendalltext'")
            query(f"UPDATE `setting` SET `text` = 'ON' WHERE `type` = 'sendallstatus'")
            set_step(chat_id, "none")
            await event.reply(
                "✅پیام شما در صف ارسال قرار گرفت.\n\n‼️توجه : لطفا تا پایان ارسال این پیام , پیام همگانی جدیدی ثبت نکنید",
                buttons=admin_markup)
        # ======================================================
        if text == "📣فروارد همگانی":
            forwardallstatus = \
                cursor.execute(f"SELECT `text` FROM `setting` WHERE `type` = 'forwardallstatus'").fetchone()[0]
            if forwardallstatus == "ON":
                await event.reply("‼️لطفا تا پایان ارسال فروارد همگانی قبلی, فروارد همگانی جدیدی ثبت نکنید")
                return
            set_step(chat_id, "set_forwardallstatus")
            await event.reply("پیام خود را ارسال کنید : ", buttons=admin_cancel_markup)
        # ======================================================
        if step == "set_forwardallstatus":
            if text == "🔙 برگشت" or text == "/start":
                return
            query(f"UPDATE `setting` SET `text` = '{message_id}' WHERE `type` = 'forwardallmsgid'")
            query(f"UPDATE `setting` SET `text` = 'ON' WHERE `type` = 'forwardallstatus'")
            set_step(chat_id, "none")
            await event.reply(
                "✅پیام شما در صف ارسال قرار گرفت.\n\n‼️توجه : لطفا تا پایان ارسال این پیام , فروارد همگانی جدیدی ثبت نکنید",
                buttons=admin_markup)
        # ======================================================
        if text == "📞دریافت کد":
            set_step(chat_id, "getphonenumberforgetcode")
            # ====================
            files_logined_sessions = os.listdir("sessions/logined_sessions/")
            logined_sessions = ""
            logined_sessions_count = 0

            for file_logined_sessions in files_logined_sessions:
                if file_logined_sessions.endswith(".session"):
                    file_logined_sessions = file_logined_sessions.replace(".session", "")
                    logined_sessions = logined_sessions + "\n" + f"`{file_logined_sessions}`"
                    logined_sessions_count += 1

            # ====================
            files_confirmed_sessions = os.listdir("sessions/confirmed_sessions/")
            confirmed_sessions = ""
            confirmed_sessions_count = 0

            for file_confirmed_sessions in files_confirmed_sessions:
                if file_confirmed_sessions.endswith(".session"):
                    file_confirmed_sessions = file_confirmed_sessions.replace(".session", "")
                    confirmed_sessions = confirmed_sessions + "\n" + f"`{file_confirmed_sessions}`"
                    confirmed_sessions_count += 1

            # ====================
            msgtxt = f"✅اکانت های لاگین شده :\n{logined_sessions}\nتعداد : {logined_sessions_count}\n\n⭐️اکانت های تایید شده:\n{confirmed_sessions}\nتعداد : {confirmed_sessions_count}"
            try:
                await event.reply(msgtxt)
                with open('phonenumbers.txt', 'w', encoding='utf-8') as f:
                    f.write(msgtxt)
                await bot.send_file(owner, 'phonenumbers.txt')
            except:
                with open('phonenumbers.txt', 'w', encoding='utf-8') as f:
                    f.write(msgtxt)
                await bot.send_file(owner, 'phonenumbers.txt')
            finally:
                os.remove('phonenumbers.txt')

            await event.reply("\n\nشماره مدنظر را مانند مثال زیر بفرستید : \n\nمثال : +989123456789")
        # ======================================================
        if step == "getphonenumberforgetcode":
            phone = text
            #phone = text
            phone_appid = apiid_accounts
            phone_apphash = apihash_accounts
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                          proxy=("socks5", IP, int(port), True, username, password))
            #await account.connect()     
            try:
                await account.connect()
                if await account.is_user_authorized():
                    posts = await account(
                        GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                          add_offset=0, hash=0))

                    for i in posts.messages:

                        if i.message != None:
                            numbers = re.findall(r'\d+', i.message)
                            if numbers:
                                number = numbers[0]
                                button = [Button.inline("خروج ربات از اکانت", data=f"logout_{phone}")]
                                await event.reply(f"✅کد ورود شما : {number}", buttons=button)
                            else:
                                await event.reply(f"❌کد ورود یافت نشد")

                else:
                    await event.reply("❌این شماره خارج از دسترس ربات میباشد")
            except ConnectionError:
                await event.reply("Proxy not work")
                proxy = get_proxy()
                await event.reply(f"Proxy not Updated but new proxy is {proxy}")
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                await event.reply(f"Old Proxy that not work: {phone_proxy}")
                #IP, port,username,password = proxy.split(":")
                """query(f"UPDATE `sessions` SET `proxy` = '{proxy}' WHERE `phonenumber` = '{phone}'")
                phone_appid = \
                cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_apphash = \
                cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_proxy = \
                cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                IP, port, username, password = phone_proxy.split(":")
                account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                              api_hash=str(phone_apphash), proxy=("socks5", IP, int(port), True, username, password))
                await account.connect()
                if await account.is_user_authorized():
                    posts = await account(
                        GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                          add_offset=0, hash=0))

                    for i in posts.messages:
                        if i.message != None:
                            if match := re.search("(Login code:) ([0-9]{3,6})", i.message, flags=re.I).groups():
                                number = match[1]
                                button = [Button.inline("خروج ربات از اکانت", data=f"logout_{phone}")]
                                await event.reply(f"✅کد ورود شما : {number}", buttons=button)
                            else:
                                await event.reply(f"❌کد ورود یافت نشد")
            except Exception as error:
                await event.reply(f"❌کد ورود یافت نشد \n\nERROR : {str(error)}")
            finally:
                set_step(chat_id, "null")
                await account.disconnect()"""

        if text == "📎دریافت فایل های تی دیتا":
            directory = "sessions/confirmed_sessions"
            session_files_with_ext = []
            session_files_without_ext = []
            await event.reply(f"درحال ساخت فایل ها لطفا صبر کنید ...")

            for root, dirs, files in os.walk(directory):
                for file in files:
                    if file.endswith(".session"):
                        session_files_with_ext.append(file)
                        session_files_without_ext.append(os.path.splitext(file)[0])

                api_id2, api_hash2 = await randomAPP()
                for session in session_files_with_ext:
                    filename = session.split(".")[0]
                    if not os.path.isdir(f"tdata/p-{filename}"):

                        try:

                            try:
                                client = TelegramClient(f"sessions/confirmed_sessions/{session}", api_id=api_id2,
                                                        api_hash=api_hash2)

                            except:
                                pass

                            finally:

                                tdesk = await client.ToTDesktop(flag=UseCurrentSession)
                                tdesk.SaveTData(f"tdata/p-{filename}")
                        except Exception as error:
                            print(error)
                    else:
                        pass

            output_filename = "tdata.zip"
            shutil.make_archive(output_filename.replace('.zip', ''), 'zip', "tdata")
            await event.reply(f"درحال ارسال فایل ها لطفا صبر کنید ...")
            await bot.send_file(chat_id, file="tdata.zip")


# ==========================================================


@bot.on(events.CallbackQuery)
async def callback(events):
    chat_id = events.sender_id
    callback = events.data.decode()
    # ===== check ban =====
    banstatus = cursor.execute(f"SELECT `ban` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]
    if banstatus == "true" and chat_id != owner:
        await events.answer(
            f"📍کاربر گرامی {chat_id} :\n\nحساب کاربری شما به توسط ادمین مسدود شده است . در صورت هر گونه سوال به پشتیبانی مراجعه فرمایید")
        return
    # ======================================================
    if callback == "sms_new_country":
        t = """اطلاعات را مانند نمونه ارسال کنید:\n**\nنام کشور\nآیدی در سایت\nکد کشور\nقیمت\n\n**\nمثال:\n\n**\nUnited Kingdom\n16\n44\n1.3\n**"""
        set_step(chat_id, callback)
        await events.reply(t, buttons=admin_cancel_markup)
    # ======================================================
    elif callback.startswith("sms_number:"):
        nothing, access_id, number, level = callback.split(':')
        if level != '1':
            bt = [Button.inline(text='Get otp code', data=f'sms_get_otp_code:{access_id}:{number}:{level}')]
        else:
            bt = [[Button.inline(text='Get otp code', data=f'sms_get_otp_code:{access_id}:{number}:{level}')],
                  [Button.inline(text='Cancel', data=f'sms_cancel:{access_id}:{number}:{level}')]]
        await events.edit("all right,\nyou can get otp code from number, cancel this (if do not get code) or buy", buttons=bt)
    # ======================================================
    elif callback.startswith("sms_get_otp_code"):
        nothing, access_id, number, level = callback.split(':')
        print(f"callback: {callback}")
        url = SMS_BASE_URL + 'getStatus&id=' + str(access_id)
        response = requests.get(url).text
        if response.startswith('STATUS_OK:'):
            bt = [Button.inline("Get new code", f'sms_get_otp_code:{access_id}:{number}:{level}')]
            await bot.send_message(chat_id, f"Number: `{number}`\n\nCode received: `{response.replace('STATUS_OK:', '')}`",
                                   parse_mode='markdown', buttons=bt)
            try:
                await events.delete()
            except Exception as e:
                await bot.send_message(6556061698, f"cannot delete message: " + str(e))
            if level == "1":
                remove_number(f"{access_id}:{number}:1", chat_id)
                append_number(f"{access_id}:{number}:2", chat_id)
                url = SMS_BASE_URL + 'setStatus&id=' + str(access_id) + '&status=1'
                response = requests.get(url).text
                match response:
                    case "ACCESS_READY":
                        await bot.send_message(chat_id, 'SMS waiting readiness')
                    case "ACCESS_RETRY_GET":
                        await bot.send_message(chat_id,
                                               'activation is successfully created, but the number is not ready yet')
                    case "ACCESS_ACTIVATION":
                        pass
                    case "ACCESS_CANCEL":
                        await bot.send_message(chat_id, 'activation is canceled')
                        remove_number(f"{access_id}:{number}:{level}")
                    case "NO_ACTIVATION":
                        await bot.send_message(chat_id, 'activation is not found')
                        try:
                            remove_number(f"{access_id}:{number}:{level}", chat_id)
                        except:
                            pass
                    case "BAD_ACTION":
                        await bot.send_message(chat_id, 'invalid action')
                    case _:
                        await bot.send_message(owner,
                                               f"invalid response from 'https://smsverified.com/' for get full sms history: '{response}'")
                cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'")
                user_balance = cursor.fetchone()[0]
                cursor.execute(f"SELECT `country_code`, `price` FROM sms_countries")
                numbers_price = cursor.fetchall()
                numbers_price_dict = {}
                numbers_temp = []
                countries_with_prices = {}
                for num in numbers_price:
                    numbers_temp.append(num[0])
                    numbers_price_dict[num[0]] = num[1]
                numbers_temp.sort(key=len)
                for num_temp in numbers_temp:
                    countries_with_prices[num_temp] = numbers_price_dict[num_temp]
                for num_temp in numbers_temp:
                    if number.startswith(num_temp):
                        number_price = countries_with_prices[num_temp]
                        break
                price = crt_form(number_price)
                balance = crt_form(user_balance)
                now_balance = calculate_new_balance(balance, price)
                cursor.execute(f"UPDATE users SET `balance` = '{now_balance}' WHERE `user_id` = '{chat_id}'")
                conn.commit()
                await events.answer(f'Your balance: {now_balance}')
            return
        elif response == 'STATUS_WAIT_CODE':
            await bot.send_message(chat_id, "We are waiting for the arrival of SMS")
        elif response.startswith('STATUS_WAIT_RETRY'):
            await bot.send_message(chat_id,
                                          f'We are waiting for another SMS\nLast code: `{response.split(":")[1]}`',
                                          parse_mode='markdown')
        elif response == 'STATUS_CANCEL':
            await bot.send_message(chat_id, "activation canceled")
        elif response == 'NO_ACTIVATION':
            await bot.send_message(chat_id, "activation is not found")
        elif response == 'BAD_ACTION':
            await bot.send_message(chat_id, "invalid action")
        else:
            await bot.send_message(owner,
                                          f"invalid response from 'https://smsverified.com/' for get code: '{response}'")
    elif callback.startswith("sms_cancel:"):
        # https://activate-api.smsverified.com/stubs/handler_api.php?api_key=YOUR_API_KEY&action=setStatus&id=2791705004917001&status=1
        notin, access_id, number, level = callback.split(":")
        if level != '1':
            return await bot.send_message('invalid operation')
        url = SMS_BASE_URL + 'setStatus&id=' + str(access_id) + '&status=8'
        response = requests.get(url).text
        match response:
            case "ACCESS_ACTIVATION":
                await bot.send_message(chat_id, 'completed successfully')
            case _:
                await bot.send_message(chat_id, "You can`t cancel this number")
                cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'")
                user_balance = cursor.fetchone()[0]
                cursor.execute(f"SELECT `country_code`, `price` FROM sms_countries")
                numbers_price = cursor.fetchall()
                numbers_price_dict = {}
                numbers_temp = []
                countries_with_prices = {}
                for num in numbers_price:
                    numbers_temp.append(num[0])
                    numbers_price_dict[num[0]] = num[1]
                numbers_temp.sort(key=len)
                for num_temp in numbers_temp:
                    countries_with_prices[num_temp] = numbers_price_dict[num_temp]
                for num_temp in numbers_temp:
                    if number.startswith(num_temp):
                        number_price = countries_with_prices[num_temp]
                        break
                price = crt_form(number_price)
                balance = crt_form(user_balance)
                now_balance = calculate_new_balance(balance, price)
                cursor.execute(f"UPDATE users SET `balance` = '{now_balance}' WHERE `user_id` = '{chat_id}'")
                conn.commit()
                await events.answer(f'Your balance: {now_balance}')
        cursor.execute(f"SELECT `sms_numbers` FROM users WHERE `user_id` = '{chat_id}'")
        active_numbers_str = cursor.fetchall()[0][0]
        if not active_numbers_str:
            active_numbers_str = ""
        active_numbers_list: list = active_numbers_str.replace(' ', '').split(",")
        if active_numbers_list == ['']:
            active_numbers_list = []
        try:
            active_numbers_list.remove('')
        except:
            pass
        try:
            active_numbers_list.remove(f"{access_id}:{number}:{level}")
        except:
            pass
        active_numbers_string = ""
        for active_num in active_numbers_list:
            active_numbers_string += active_num + ','
        active_numbers_string = active_numbers_string[:-1]
        cursor.execute(
            f"UPDATE users SET `sms_numbers` = '{active_numbers_string}' WHERE `user_id` = '{chat_id}'")
        conn.commit()
        await bot.send_message(chat_id, "Number canceled success")
        await events.delete()
    """elif callback.startswith("sms_buy_number:"):
        notin, access_id, number = callback.split(":")
        url = SMS_BASE_URL + 'setStatus&id=' + str(access_id) + '&status=1'
        response = requests.get(url).text
        match response:
            case "ACCESS_READY":
                await bot.send_message(chat_id, 'SMS waiting readiness')
            case "ACCESS_RETRY_GET":
                await bot.send_message(chat_id,
                                       'activation is successfully created, but the number is not ready yet')
            case "ACCESS_ACTIVATION":
                await bot.send_message(chat_id, 'Activation completed successfully')
            case "ACCESS_CANCEL":
                await bot.send_message(chat_id, 'activation is canceled')
                return remove_number(f"{access_id}:{number}:1")
            case "NO_ACTIVATION":
                await bot.send_message(chat_id, 'activation is not found')
            case "BAD_ACTION":
                await bot.send_message(chat_id, 'invalid action')
            case _:
                await bot.send_message(owner,
                                       f"invalid response from 'https://smsverified.com/' for buy number: '{response}'")
        cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'")
        user_balance = cursor.fetchone()[0]
        cursor.execute(f"SELECT `country_code`, `price` FROM sms_countries")
        numbers_price = cursor.fetchall()
        numbers_price_dict = {}
        numbers_temp = []
        countries_with_prices = {}
        for num in numbers_price:
            numbers_temp.append(num[0])
            numbers_price_dict[num[0]] = num[1]
        numbers_temp.sort(key=len)
        for num_temp in numbers_temp:
            countries_with_prices[num_temp] = numbers_price_dict[num_temp]
        for num_temp in numbers_temp:
            if number.startswith(num_temp):
                number_price = countries_with_prices[num_temp]
                break
        price = crt_form(number_price)
        balance = crt_form(user_balance)
        now_balance = calculate_new_balance(balance, price)
        cursor.execute(f"UPDATE users SET `balance` = '{now_balance}' WHERE `user_id` = '{chat_id}'")
        conn.commit()
        return await events.answer(f'Your balance: {now_balance}')"""

    if callback.startswith("sms_full_history:"):
        notin, access_id, number, level = callback.split(":")
        response = requests.get(SMS_BASE_URL + 'getFullSms&id=' + str(access_id)).text
        await bot.send_message(chat_id, str(response))
        if level == "1":
            remove_number(f"{access_id}:{number}:1", chat_id)
            append_number(f"{access_id}:{number}:2", chat_id)
            url = SMS_BASE_URL + 'setStatus&id=' + str(access_id) + '&status=1'
            response = requests.get(url).text
            match response:
                case "ACCESS_READY":
                    return await bot.send_message(chat_id, 'SMS waiting readiness')
                case "ACCESS_RETRY_GET":
                    return await bot.send_message(chat_id,
                                                  'activation is successfully created, but the number is not ready yet')
                case "ACCESS_ACTIVATION":
                    pass
                case "ACCESS_CANCEL":
                    await bot.send_message(chat_id, 'activation is canceled')
                    return remove_number(f"{access_id}:{number}:{level}")
                case "NO_ACTIVATION":
                    await bot.send_message(chat_id, 'activation is not found')
                    try:
                        return remove_number(f"{access_id}:{number}:{level}", chat_id)
                    except:
                        pass
                case "BAD_ACTION":
                    return await bot.send_message(chat_id, 'invalid action')
                case _:
                    await bot.send_message(owner,
                                           f"invalid response from 'https://smsverified.com/' for get full sms history: '{response}'")
            cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'")
            user_balance = cursor.fetchone()[0]
            cursor.execute(f"SELECT `country_code`, `price` FROM sms_countries")
            numbers_price = cursor.fetchall()
            numbers_price_dict = {}
            numbers_temp = []
            countries_with_prices = {}
            for num in numbers_price:
                numbers_temp.append(num[0])
                numbers_price_dict[num[0]] = num[1]
            numbers_temp.sort(key=len)
            for num_temp in numbers_temp:
                countries_with_prices[num_temp] = numbers_price_dict[num_temp]
            for num_temp in numbers_temp:
                if number.startswith(num_temp):
                    number_price = countries_with_prices[num_temp]
                    break
            price = crt_form(number_price)
            balance = crt_form(user_balance)
            now_balance = calculate_new_balance(balance, price)
            cursor.execute(f"UPDATE users SET `balance` = '{now_balance}' WHERE `user_id` = '{chat_id}'")
            conn.commit()
            await events.answer(f'Your balance: {now_balance}')
    # ======================================================
    elif callback.startswith('get_code:'):
        try:
            phone = callback.split(':')[1]
            # phone = text
            phone_appid = apiid_accounts
            phone_apphash = apihash_accounts
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                          proxy=("socks5", IP, int(port), True, username, password))
            # await account.connect()
            try:
                await account.connect()
                if await account.is_user_authorized():
                    posts = await account(
                        GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                          add_offset=0, hash=0))

                    for i in posts.messages:

                        if i.message != None:
                            numbers = re.findall(r'\d+', i.message)
                            if numbers:
                                number = numbers[0]
                                button = [Button.inline("خروج ربات از اکانت", data=f"logout_{phone}")]
                                await events.reply(f"✅کد ورود شما : {number}", buttons=button)
                            else:
                                await events.reply(f"❌کد ورود یافت نشد")
                else:
                    await events.reply("❌این شماره خارج از دسترس ربات میباشد")
            except ConnectionError:
                await events.reply("Proxy not work")
                proxy = get_proxy()
                await events.reply(f"Proxy not Updated but new proxy is {proxy}")
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                await events.reply(f"Old Proxy that not work: {phone_proxy}")
                # IP, port,username,password = proxy.split(":")
                """query(f"UPDATE `sessions` SET `proxy` = '{proxy}' WHERE `phonenumber` = '{phone}'")
                phone_appid = \
                cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_apphash = \
                cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_proxy = \
                cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                IP, port, username, password = phone_proxy.split(":")
                account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                              api_hash=str(phone_apphash), proxy=("socks5", IP, int(port), True, username, password))
                await account.connect()
                if await account.is_user_authorized():
                    posts = await account(
                        GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                          add_offset=0, hash=0))

                    for i in posts.messages:
                        if i.message != None:
                            if match := re.search("(Login code:) ([0-9]{3,6})", i.message, flags=re.I).groups():
                                number = match[1]
                                button = [Button.inline("خروج ربات از اکانت", data=f"logout_{phone}")]
                                await event.reply(f"✅کد ورود شما : {number}", buttons=button)
                            else:
                                await event.reply(f"❌کد ورود یافت نشد")
            except Exception as error:
                await event.reply(f"❌کد ورود یافت نشد \n\nERROR : {str(error)}")
            finally:
                set_step(chat_id, "null")
                await account.disconnect()"""



        except Exception as e:
            if str(e) == 'database is locked':
                unlock_db()
            await bot.send_message(owner, str(e))
    # ======================================================
    if callback.startswith('logout'):
        try:
            phone = callback.split("_")[1]
            phone_appid = cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            phone_apphash = \
                cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            client = tc2("sessions/confirmed_sessions/" + phone, api_id=int(phone_appid), api_hash=str(phone_apphash),
                         proxy=("socks5", IP, int(port), True, username, password))
            await client.connect()
            #try:

            os.remove(f"sessions/confirmed_sessions/{phone}.session")

            await client.log_out()
            await events.answer("خروج با موفقیت انجام شد")
        except ConnectionError:
            await events.answer("Proxy not work")
            proxy = get_proxy()
            await events.answer(f"Proxy not Updated but new proxy is {proxy}")
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            await events.answer(f"Old Proxy that not work: {phone_proxy}")
        """    #IP, port,username,password = proxy.split(":")
            query(f"UPDATE `sessions` SET `proxy` = '{proxy}' WHERE `phonenumber` = '{phone}'")
            phone_appid = cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            phone_apphash = \
            cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid), api_hash=str(phone_apphash),
                          proxy=("socks5", IP, int(port), True, username, password))
            await account.connect()
            #try:
            if os.path.exists(f"sessions/temp_sessions/{phone}.session"):
                os.remove(f"sessions/temp_sessions/{phone}.session")
            if os.path.exists(f"sessions/logined_sessions/{phone}.session"):
                os.remove(f"sessions/logined_sessions/{phone}.session")
            if os.path.exists(f"sessions/confirmed_sessions/{phone}.session"):
                os.remove(f"sessions/confirmed_sessions/{phone}.session")

            await client.log_out()
            await events.answer("خروج با موفقیت انجام شد")"""
        # ======================================================

    if callback.startswith('vn_changecountryprice'):
        print(f"cb: {callback}")
        countrycode = callback.split(":")[1]
        print(f"SELECT `name` FROM vn_countries WHERE `country_code` = '{countrycode}'")
        cursor.execute(f"SELECT `name` FROM vn_countries WHERE `country_code` = '{countrycode}'")
        c_name = cursor.fetchone()[0]
        await events.reply(' قیمت جدید برای شماره مجازی ' + str(c_name) + ' را وارد کنید ', buttons=admin_cancel_markup)
        set_step(chat_id, callback)
    # ======================================================💲
    """if callback.startswith('vn_logout'):
        try:
            phone = callback.split("_")[1]
            phone_appid = cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            phone_apphash = \
            cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            client = tc2("sessions/confirmed_sessions/" + phone, api_id=int(phone_appid), api_hash=str(phone_apphash),
                         proxy=("socks5", IP, int(port), True, username, password))
            await client.connect()
            #try:

            os.remove(f"sessions/confirmed_sessions/{phone}.session")

            await client.log_out()
            await events.answer("خروج با موفقیت انجام شد")
        except ConnectionError:
            await events.answer("Proxy not work")
            proxy = get_proxy()
            await events.answer(f"Proxy not Updated but new proxy is {proxy}")
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            await events.answer(f"Old Proxy that not work: {phone_proxy}")"""

    if int(chat_id) == int(owner):
        main_markup = main_markup2
    else:
        main_markup = main_markup1

    if callback.startswith('tayid'):
        nowtime = callback.split('|')[1].split('.')[0]
        checkertime = int(time.time()) - int(nowtime)
        if checkertime >= int(2):
            await events.answer('کمی صبر کنید ...')
            phone = callback.split("|")[3]
            countrycode = callback.split("|")[4]
            phone_appid = cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            phone_apphash = \
                cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
            phone_proxy = cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
            IP, port, username, password = phone_proxy.split(":")
            client = tc2("sessions/logined_sessions/" + phone, api_id=int(phone_appid), api_hash=str(phone_apphash),
                         proxy=("socks5", IP, int(port), True, username, password))
            await client.connect()
            s = callback.split("|")
            try:

                result = await client(functions.account.GetAuthorizationsRequest())

                if len(result.authorizations) == 1:
                    query(f"UPDATE `sessions` SET `level` = '3' WHERE `phonenumber` = '{phone}'")
                    query(f"UPDATE `sessions` SET `confirmtime` = '{time.time()}' WHERE `phonenumber` = '{phone}'")
                    query(f"UPDATE `users` SET `accountsended` = accountsended + 1 WHERE `user_id` = '{chat_id}'")

                    if s[2] != 'False':
                        await client.edit_2fa(current_password=s[2], new_password=twofanew)
                        countryprice = float(cursor.execute(
                            f"SELECT `price` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()[0])
                        query(f"UPDATE `users` SET `balance` = balance + {countryprice} WHERE `user_id` = '{chat_id}'")
                        msg = await events.edit(
                            f'🎉 تبریک, شماره {phone} تایید شد\n\nمبلغ {countryprice} به حساب شما افزوده شد')
                        msgid = msg.id
                    else:
                        await client.edit_2fa(new_password=twofanew)
                        countryprice = float(cursor.execute(
                            f"SELECT `price` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()[0])
                        query(f"UPDATE `users` SET `balance` = balance + {countryprice} WHERE `user_id` = '{chat_id}'")
                        msg = await events.edit(
                            f'🎉 تبریک, شماره {phone} تایید شد و {countryprice} سکه به حسابتان اضافه شد!')
                        msgid = msg.id
                    await client.disconnect()
                    shutil.copy(f"sessions/logined_sessions/{phone}.session",
                                f"sessions/confirmed_sessions/{phone}.session")  # move it
                else:
                    await events.reply('⚠️ نشستهای فعال اکانت خالی نیست.')
                    await client.disconnect()
            except errors.UserDeactivatedBanError:
                await events.edit('⚠️متاسفانه اکانت شما دیلیت شده است لطفا اکانت دیگری را وارد نمایید.')

                os.remove("sessions/logined_sessions/{}.session".format(phone))
            except errors.UserDeactivatedError:
                await events.edit('⚠️متاسفانه اکانت شما دیلیت شده است لطفا اکانت دیگری را وارد نمایید.')

                os.remove("sessions/logined_sessions/{}.session".format(phone))
            except errors.SessionExpiredError:
                await events.edit(f'⚠️ شماره {phone} از دسترس ربات خارج شده است و امکان ثبت آن نیست.')

                os.remove("sessions/logined_sessions/{}.session".format(phone))
            except errors.SessionRevokedError:
                await events.edit(f'⚠️ شماره {phone} از دسترس ربات خارج شده است و امکان ثبت آن نیست.')

                os.remove("sessions/logined_sessions/{}.session".format(phone))
            except errors.rpcerrorlist.PasswordHashInvalidError:
                await events.edit(f'⚠️ تایید دو مرحله ای شماره {phone} تغییر کرده است و امکان ثبت آن نیست.')

                os.remove("sessions/logined_sessions/{}.session".format(phone))
            except Exception as e:
                if str(e) == 'database is locked':
                    unlock_db()
                await bot.send_message(owner, f'Error ->\n{e}')
                check_error(str(e))
                await events.edit(
                    '⚠️خطای ناشناخته از تلگرام لطفا دوباره اکانت را وارد نمایید یا اکانت دیگری را وارد ربات نمایید.')
                os.remove("sessions/logined_sessions/{}.session".format(phone))
            finally:
                await client.disconnect()
        else:
            remainingtime = 2 - (int(time.time()) - int(nowtime))
            await events.answer(
                'هنوز 120 دقیقه نشده است لطفا {} ثانیه دیگر صبر کنید با تشکر'.format(str(remainingtime)))

    # ======================================================
    if callback == "userwithdrawinfo":
        cardnumber = cursor.execute(f"SELECT `cardnumber` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]

        if cardnumber == "NULL":
            cardnumber = "❌ثبت نشده"
        setting_markup2 = [

            [Button.inline('⚙️تغییر شماره کارت', data=f'cardnumber')],

        ]
        await events.edit(f'💵 اطلاعات حساب (برداشت) شما : \n\n👈 شماره کارت : {cardnumber}', buttons=setting_markup2)
    # ======================================================
    if callback == "cardnumber":
        await events.reply(f'📍 شماره کارت 16 رقمی خود را ارسال کنید\n➖از ارسال شماره کارت فیک خودداری کنید.',
                           buttons=cancel_markup)
        set_step(chat_id, callback)
    # ======================================================
    if callback == "disable_countries":
        cursor.execute('SELECT * FROM countries')
        rows = cursor.fetchall()
        countoff = 0
        messageoff = ""
        button = [
            [Button.inline('✅کشورهای فعال', data=f'enable_countries')],
            [Button.url('📣کانال اطلاع رسانی', url="https://t.me/forosh_frs")]
        ]
        for row in rows:
            if row[1] == "OFF":
                countoff += 1
                messageoff = messageoff + f"\n\n❌ نام کشور : {row[2]} ({row[3]})\n👈 قیمت : {row[4]} /تایم : 120 دقیقه"
        if countoff > 0:
            await events.edit(
                f"🌏 لیست کشور های قابل ارسال به ربات همراه با قیمت خرید و تایم تایید آنها عبارتند از :\n\n- - - - - - - - - -\n {messageoff} \n\n- - - - - - - - - - - \n🎛 معنای ایموجی های پشت نام هرکشور :\n✅ امکان ارسال اکانت این کشور فعال میباشد\n❌ ارسال اکانت این کشور موقت بسته میباشد",
                buttons=button)
        if countoff == 0:
            await events.edit("❌در حال حاضر کشور غیرفعالی موجود نیست")
    # ======================================================
    if callback.startswith('buy_vn_country'):
        country_code = callback.split(':')[1]
        country_info = cursor.execute(f"SELECT * FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()
        txt = f'Do you sure you want to buy a number with bellow details?\n\ncountry: {country_info[1]}\ncountry code: +{country_info[2]}\nnumber price: {country_info[3]} $'
        yes_or_no_bt = [[Button.inline("Yes I`m sure", data=f"buy_number:{country_code}")],
                        [Button.inline('Cancel Operation', data='cancel_buy')]]
        await events.edit(txt, buttons=yes_or_no_bt)
    # ======================================================
    if callback == "cancel_buy":
        balance = cursor.execute(f"SELECT `balance` FROM users WHERE user_id = '{chat_id}'").fetchone()[0]
        response = f"Your Balance: {balance} $\n\nSelect Your Country: "
        countries = get_countries()
        inline_buttons = []
        countries_lst = list(countries.keys())
        for res in countries_lst:
            name, code, price = countries[res][1], countries[res][2], countries[res][3]
            len_nums = get_len_numbers(code)[0]

            text = f"+{code} | {name}({len_nums}) | {price} $"
            data = f"buy_vn_country:{code}"
            inline_buttons.append([Button.inline(text, data)])
        await events.edit(response, buttons=inline_buttons)
    # ======================================================
    if callback.startswith("buy_number"):
        country_code = callback.split(":")[1]
        balance = float(cursor.execute(f"SELECT `balance` FROM users WHERE user_id = '{chat_id}'").fetchone()[0])
        numbers_price = float(
            cursor.execute(f"SELECT `price` FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()[
                0])
        main_numbers = await get_active_numbers(country_code)
        if numbers_price > balance:
            set_step(chat_id, 'none')
            await bot.send_message(chat_id,
                                   f"Your Balance {balance} $ is Not Enough for buy number from this country with Price {numbers_price} $")
            await bot.send_message(chat_id, "So, to increase the balance, contact the admin:\n>>>>>  @forosh_frs",
                                   buttons=main_markup)
            return
        print(country_code)
        if not main_numbers:
            await bot.send_message(chat_id, "We Don`t Have any Number From This Country")
            set_step(chat_id, 'none')
            return
        number = random.choice(main_numbers)[0]
        country_name = \
            cursor.execute(f"SELECT `name` FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()[0]
        print(number, country_name)
        await bot.send_message(chat_id,
                               f"Alright,\nNow you can login into your account and get otp code with clicking on bellow button\nNotice: \nPrice of number will be pay when you get otp code!\n\n\nCountry: +{country_code} | {country_name}\nNumber: {number}",
                               buttons=[
                                   Button.inline(text='Get OTP Code', data=f"get_otp_code:{number}:{country_code}")])
        # await bot.send_message(chat_id, f"Number {number} added to your virtual numbers successfully !\n you can manage and get otp code from your panel.\n for login into your panel Go to <My Numbers>", buttons=main_markup)
        set_step(chat_id, 'none')
        return
    # ======================================================
    if callback.startswith("vn_lin_get_otp_code_again"):
        # vn_lin_get_otp_code_again:phone:countrycode
        phone = callback.split(":")[1]
        phone_appid = apiid_accounts
        phone_apphash = apihash_accounts
        phone_proxy = \
            cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
        IP, port, username, password = phone_proxy.split(":")
        account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                      api_hash=str(phone_apphash),
                      proxy=("socks5", IP, int(port), True, username, password))
        # await account.connect()
        try:
            await account.connect()
            if await account.is_user_authorized():
                posts = await account(
                    GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                      add_offset=0, hash=0))
                for i in posts.messages:
                    if i.message != None:
                        numbers = re.findall(r'\d+', i.message)
                        if numbers:
                            number = numbers[0]
                            await events.edit(
                                f"Code Found Successfully\n\n\nNumber: {phone}\n\nYour Code: `{number}`\n\nTwo Step Verify Password: `Abolfazl5465`",
                                parse_mode="markdown",
                                buttons=[[Button.inline("Logout Bot", data=f"vn_logout_bot:{phone}")],
                                         [Button.inline("Get OTP Code Again",
                                                        data=f"vn_lin_get_otp_code_again:{phone}")]])
                        else:
                            if callback.endswith(':again'):
                                await bot.send_message(chat_id,
                                    f"Again Not Found!\nOTP Code not found again So number {phone} Deleted From your card\nPlease Try again!",
                                    buttons=[Button.inline("Send OTP Again", callback)])
                            await events.edit(
                                f"OTP Code Not Found!\nMay Code Not Send...\nplease send code with login into account and click again on bellow button",
                                buttons=[Button.inline("Send OTP Again", callback + ':again')])
            else:
                await events.edit(f"An Error!\nVirtual Number {phone} Deleted From Card\nPlease Try again!")
        except ConnectionError:
            await events.edit(f"An Error!\nProxy Not work\nPlease Try again with another virtual number")
        await account.disconnect()

    # ======================================================
    if callback.startswith('get_otp_code'):
        phone = callback.split(":")[1]
        country_code = callback.split(':')[2]
        price = cursor.execute(f"SELECT `price` FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()[
            0]
        balance = cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'").fetchone()[0]
        price = crt_form(price)
        balance = crt_form(balance)
        now_balance = calculate_new_balance(balance, price)
        if float(now_balance) < 0:
            return bot.send_message(chat_id, "Your balance is Not Enough")

        phone_appid = apiid_accounts
        phone_apphash = apihash_accounts
        phone_proxy = \
            cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                0]
        IP, port, username, password = phone_proxy.split(":")
        account = tc2(f"sessions/confirmed_sessions/{phone}", api_id=int(phone_appid),
                      api_hash=str(phone_apphash),
                      proxy=("socks5", IP, int(port), True, username, password))
        # await account.connect()
        try:
            await account.connect()
            if await account.is_user_authorized():
                posts = await account(
                    GetHistoryRequest(peer=777000, limit=1, offset_date=None, offset_id=0, max_id=0, min_id=0,
                                      add_offset=0, hash=0))
                for i in posts.messages:
                    if i.message != None:
                        numbers = re.findall(r'\d+', i.message)
                        if numbers:
                            number = numbers[0]
                            await events.edit(
                                f"Code Found Successfully\n\n\nNumber: {phone}\n\nYour Code: `{number}`\n\nTwo Step Verify Password: `Abolfazl5465`",
                                parse_mode="markdown",
                                buttons=[[Button.inline("Logout Bot", data=f"vn_logout_bot:{phone}")],
                                         [Button.inline("Get OTP Code Again",
                                                        data=f"vn_lin_get_otp_code_again:{phone}")]])
                        else:
                            if callback.endswith(':again'):
                                await bot.send_message(
                                    f"Again Not Found!\nOTP Code not found again So number {phone} Deleted From your card\nPlease Try again!",
                                    buttons=[Button.inline("Send OTP Again", data=calldata)])
                                return
                            await events.edit(
                                f"OTP Code Not Found!\nMay Code Not Send...\nplease send code with login into account and click again on bellow button",
                                buttons=[Button.inline("Send OTP Again", callback + ':again')])
                             
                            return
            else:
                await events.edit(f"An Error!\nVirtual Number {phone} Deleted From Card\nPlease Try again")
                return
        except ConnectionError:
            await events.edit(f"An Error!\nProxy Not work\nPlease Try again with another virtual number")
            return
        except Exception as e:
            await bot.send_message(chat_id, "an unexpected error")
            return await bot.send_message(owner, f"error in give number: {e}")
        await account.disconnect()
        price = cursor.execute(f"SELECT `price` FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()[
            0]
        balance = cursor.execute(f"SELECT `balance` FROM users WHERE `user_id` = '{chat_id}'").fetchone()[0]
        print(price, balance)
        price = crt_form(price)
        balance = crt_form(balance)
        now_balance = calculate_new_balance(balance, price)
        print(now_balance)
        #await bot.send_message(f"you balance set to ")
        # number_owner = cursor.execute(f"SELECT `owner` FROM sessions WHERE `phonenumber` = '{phone}'").fetchone()[0]
        """if int(number_owner) == int(chat_id):
            await bot.send_message(chat_id, f"previously You Was Bought this Number So Your Balance is {balance} $")
            return"""

        """balance = float(cursor.execute(f"SELECT `balance` FROM users WHERE user_id = '{chat_id}'").fetchone()[0])
        numbers_price = float(
            cursor.execute(f"SELECT `price` FROM vn_countries WHERE `country_code` = '{country_code}'").fetchone()[
                0])"""
        # number = phone
        """old_nums = cursor.execute(f"SELECT `numbers` FROM users WHERE `user_id` = '{chat_id}'").fetchone()[0]
        if not old_nums:
            old_nums = ''
        str_nums = old_nums + str(number) + ', '
        q = f"UPDATE users SET numbers = '{str_nums}' WHERE user_id = '{chat_id}'"

        cursor.execute(q)"""
        # cursor.execute(f"UPDATE sessions SET owner = '{chat_id}' WHERE `phonenumber` = '{number}'")
        cursor.execute(f"UPDATE users SET `balance` = '{now_balance}' WHERE `user_id` = '{chat_id}'")
        conn.commit()
        await bot.send_message(chat_id, f"Now You bought This Virtual Number So Now Your Balance is {now_balance} $")
        """except Exception as e:
            await bot.send_message(owner, str(e))"""
    """if callback.startswith('main_get_otp_code'):
        phone = callback.split(":")[1]
        otp_code = await vn_get_otp_code(phone)
        if otp_code == 'HAVE_NOT_ACCESS':
            await events.edit(f"An Error!\nPlease Try again!")
        elif otp_code == 'PROXY_ERROR':
            await events.edit(f"An Error!\nProxy Not work!\nContact Admin")
        elif otp_code == 'NOT_SEND':
            if callback.endswith(':again'):
                await events.edit(f"Again Not Found!\nPlease Try again!")
                return
            await events.edit(f"OTP Code Not Found!\nMay Code Not Send...\nplease send code with login into account and click again on bellow button",
                              buttons=[Button.inline("Send OTP Again", callback + ':again')])
        else:
            await events.edit(f"Code Found Successfully\n\n\nNumber: {phone}\nYour Code: {otp_code}\nTwo Step Verify Password: Abolfazl5465", buttons=[Button.inline("Logout Bot", data=f"vn_logout_bot:{phone}")])"""
    if callback.startswith("vn_logout_bot"):
        try:
            await events.delete()
            phone = callback.split(':')[1]
            try:
                phone_appid = \
                    cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                phone_apphash = \
                    cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[0]
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                IP, port, username, password = phone_proxy.split(":")
                client = tc2("sessions/confirmed_sessions/" + phone, api_id=int(phone_appid),
                             api_hash=str(phone_apphash),
                             proxy=("socks5", IP, int(port), True, username, password))
                await client.connect()
                os.remove(f"sessions/confirmed_sessions/{phone}.session")
                try:
                    os.remove(f"sessions/temp_sessions/{phone}.session")
                except:
                    pass
                try:
                    os.remove(f"sessions/logined_sessions/{phone}.session")
                except:
                    pass
                await client.log_out()
                await client.disconnect()
                cursor.execute(f"DELETE FROM sessions WHERE `phonenumber` = '{phone}'")
                conn.commit()
                await events.answer("Logout mission Completed Successfully!")
                await bot.send_message(chat_id, "Logout mission Completed Successfully!")
            except ConnectionError:
                await events.answer("Proxy not work")
                proxy = get_proxy()
                await events.answer(f"Proxy not Updated but new proxy is {proxy}")
                phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                await events.answer(f"Old Proxy that not work: {phone_proxy}")
            finally:
                await client.disconnect()
        except Exception as e:
            """if str(e) == 'database is locked':
                unlock_db()
                try:
                    phone_appid = \
                    cursor.execute(f"SELECT `appid` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                    phone_apphash = \
                        cursor.execute(f"SELECT `apphash` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                            0]
                    phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                    IP, port, username, password = phone_proxy.split(":")
                    client = tc2("sessions/confirmed_sessions/" + phone, api_id=int(phone_appid),
                                 api_hash=str(phone_apphash),
                                 proxy=("socks5", IP, int(port), True, username, password))
                    await client.start()
                    await client.connect()
                    os.remove(f"sessions/confirmed_sessions/{phone}.session")
                    try:
                        os.remove(f"sessions/temp_sessions/{phone}.session")
                    except:
                        pass
                    try:
                        os.remove(f"sessions/logined_sessions/{phone}.session")
                    except:
                        pass
                    await client.log_out()
                    await client.disconnect()
                    cursor.execute(f"DELETE FROM sessions WHERE `phonenumber` = '{phone}'")
                    conn.commit()
                    await events.answer("Logout mission Completed Successfully!")
                    await bot.send_message(chat_id, "Logout mission Completed Successfully!")
                except ConnectionError:
                    await events.answer("Proxy not work")
                    proxy = get_proxy()
                    await events.answer(f"Proxy not Updated but new proxy is {proxy}")
                    phone_proxy = \
                    cursor.execute(f"SELECT `proxy` FROM `sessions` WHERE `phonenumber` = '{phone}'").fetchone()[
                        0]
                    await events.answer(f"Old Proxy that not work: {phone_proxy}")
                finally:
                    try:
                        await client.disconnect()
                    except:
                        pass"""
            await bot.send_message(owner, str(e))
    # ======================================================
    if callback == "enable_countries":
        cursor.execute('SELECT * FROM countries')
        rows = cursor.fetchall()
        counton = 0
        messageon = ""
        button = [
            [Button.inline('🚫کشور های غیرفعال', data=f'disable_countries')],
            [Button.url('📣کانال اطلاع رسانی', url="https://t.me/forosh_frs")]
        ]
        for row in rows:
            if row[1] == "ON":
                status = "✅روشن"

                counton += 1
                messageon = messageon + f"\n\n✅ نام کشور : {row[2]} ({row[3]})\n👈 قیمت : {row[4]} /تایم : 120 دقیقه"
        if counton > 0:
            await events.edit(
                f"🌏 لیست کشور های قابل ارسال به ربات همراه با قیمت خرید و تایم تایید آنها عبارتند از :\n\n- - - - - - - - - -\n {messageon} \n\n- - - - - - - - - - - \n🎛 معنای ایموجی های پشت نام هرکشور :\n✅ امکان ارسال اکانت این کشور فعال میباشد\n❌ ارسال اکانت این کشور موقت بسته میباشد",
                buttons=button)
        if counton == 0:
            button = [
                [Button.url('📣کانال اطلاع رسانی', url="https://t.me/forosh_frs")]
            ]
            await events.edit("❌در حال حاضر کشور فعالی موجود نیست", buttons=button)
        # ==========================================================
    if chat_id == owner:
        # ======================================================
        if callback.startswith('sms_changecountryprice'):
            country_id = callback.split(":")[1]
            cursor.execute(f"SELECT `country_code` FROM sms_countries WHERE `id` = '{country_id}'")
            country_code = cursor.fetchone()[0]
            await events.reply(f'💲قیمت جدید کد کشور {country_code} را وارد کنید', buttons=admin_cancel_markup)
            set_step(chat_id, callback)
        # ======================================================
        if callback.startswith("sms_deletecountry"):
            country_id = callback.split(":")[1]
            cursor.execute(f"SELECT `country_code` FROM sms_countries WHERE `id` = '{country_id}'")
            country_code = cursor.fetchone()[0]
            try:
                cursor.execute(f"DELETE FROM `sms_countries` WHERE `id` = '{country_id}'")
                await events.answer(f"کشور {country_code} با موفقیت حذف شد")
                cursor.execute('SELECT * FROM sms_countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(sms_manage_countries1)
                keyboard.append(sms_manage_countries2)
                for row in rows:
                    button = [Button.inline("❌حذف", data=f'sms_deletecountry:{row[0]}'),
                              Button.inline(row[3], data=f'sms_changecountryprice:{row[0]}'),
                              Button.inline(row[1], data=f'sms_country_{row[0]}'),
                              Button.inline(row[0], data=f'sms_country_{row[0]}')]
                    keyboard.append(button)
                await events.respond('⭐️مدیریت کشورها', buttons=keyboard)
            except Exception as e:
                await events.answer("خطایی رخ داده است")
                print(e)
        # ======================================================
        if callback.startswith('changecountryprice'):
            countrycode = callback.split("_")[1]
            await events.reply(f'💲قیمت جدید کد کشور {countrycode} را وارد کنید', buttons=admin_cancel_markup)
            set_step(chat_id, callback)
        # ======================================================
        if callback.startswith("vn_changecountrystatus"):
            status = callback.split(":")[1]
            country_code = callback.split(":")[2]
            if status == 'ON':
                new_status = "OFF"
            else:
                new_status = "ON"
            query(f"UPDATE vn_countries SET `status` = '{new_status}' WHERE `country_code` = '{country_code}'")
            await events.answer('✅تغییر یافت')
            cursor.execute('SELECT name, price, country_code, status FROM vn_countries')
            rows = cursor.fetchall()
            keyboard = []
            keyboard.append(vn_new_country)
            keyboard.append(
                [Button.inline("دکمه حذف"), Button.inline("وضعیت"), Button.inline('کشور'), Button.inline("قیمت")])
            for row in rows:
                button = [Button.inline("❌حذف", data=f'vn_deletecountry_{row[2]}'),
                          Button.inline(str(row[3]), data=f"vn_changecountrystatus:{row[3]}:{row[2]}"),
                          Button.inline(str(row[0]), data=f'vn_country_{row[0]}'),
                          Button.inline(str(row[1]), data=f'vn_changecountryprice:{row[2]}')]
                keyboard.append(button)
            await events.edit('⭐️مدیریت کشورها', buttons=keyboard)
        if callback.startswith('changecountrystatus'):
            countrycode = callback.split("_")[1]
            await events.answer('✅تغییر یافت')
            try:
                countrystatus = \
                    cursor.execute(
                        f"SELECT `status` FROM `countries` WHERE `countrycode` = '{countrycode}'").fetchone()[0]
            except Exception as error:
                if str(error) == 'database is locked':
                    unlock_db()
                countrystatus = str(error) + countrycode
            if countrystatus == "ON":
                newcountrystatus = "OFF"
            else:
                newcountrystatus = "ON"
            query(f"UPDATE `countries` SET `status` = '{newcountrystatus}' WHERE `countrycode` = '{countrycode}'")

            cursor.execute('SELECT * FROM countries')
            rows = cursor.fetchall()
            keyboard = []
            keyboard.append(new_country)
            keyboard.append(manage_countries)

            for row in rows:
                if row[1] == "ON":
                    status = "✅روشن"
                else:
                    status = "❌خاموش"
                button = [Button.inline("❌حذف", data=f'deletecountry_{row[3]}'),
                          Button.inline(row[4], data=f'changecountryprice_{row[3]}'),
                          Button.inline(status, data=f'changecountrystatus_{row[3]}'),
                          Button.inline(row[3], data=f'country_{row[3]}'),
                          Button.inline(row[2], data=f'country_{row[3]}')]
                keyboard.append(button)
            countrycode = callback.split("_")[1]
            await events.edit('⭐️مدیریت کشورها', buttons=keyboard)

        # ======================================================
        if callback.startswith('user+'):
            userid = callback.split("_")[1]
            await events.reply(
                f'💲میزان موجودی که میخواهید به کاربر {userid} اضافه کنید بصورت عددی و دلار وارد کنید : ',
                buttons=admin_cancel_markup)
            set_step(chat_id, callback)
        # ======================================================
        if callback.startswith('user-'):
            userid = callback.split("_")[1]
            await events.reply(f'💲میزان موجودی که میخواهید از کاربر {userid} کسر کنید بصورت عددی و دلار وارد کنید : ',
                               buttons=admin_cancel_markup)
            set_step(chat_id, callback)
        # ======================================================
        if callback.startswith("confirmpay"):
            button = [Button.inline("✅تایید شده است", data=f'null')]
            userid = callback.split("|")[1]
            amount = callback.split("|")[2]
            cardnumber = callback.split("|")[3]
            query(f"UPDATE `users` SET `recivedamount` = recivedamount + '{amount}' WHERE `user_id` = '{chat_id}'")

            await bot.send_message(int(userid),
                                   f"**🤩درخواست پرداخت شما توسط ادمین تایید شد**\n\n**💸مبلغ :** {amount}\n**💳شماره کارت : **{cardnumber}")
            await events.edit(f"تراکنش به مبلغ {amount} به کاربر {userid} به شماره کارت {cardnumber} تایید شد",
                              buttons=button)
        # ======================================================
        if callback.startswith("unconfirmpay"):
            button = [Button.inline("❌تایید نشده است", data=f'null')]
            userid = callback.split("|")[1]
            amount = callback.split("|")[2]
            cardnumber = callback.split("|")[3]
            await bot.send_message(int(userid),
                                   f"**❌درخواست پرداخت شما توسط ادمین تایید نشد**\n\n**💸مبلغ :** {amount}\n**💳شماره کارت : **{cardnumber}")
            await events.edit(f"تراکنش به مبلغ {amount} به کاربر {userid} به شماره کارت {cardnumber} تایید نشد",
                              buttons=button)
        # ======================================================
        if callback.startswith("checkban"):
            userid = callback.split("_")[1]
            balance = cursor.execute(f"SELECT `balance` FROM `users` WHERE `user_id` = '{userid}'").fetchone()[0]
            ban = cursor.execute(f"SELECT `ban` FROM `users` WHERE `user_id` = '{userid}'").fetchone()[0]
            accountsended = \
                cursor.execute(f"SELECT `accountsended` FROM `users` WHERE `user_id` = '{chat_id}'").fetchone()[0]

            if ban == "false":
                banstatus = "✅آزاد"
                newbanstatus = "true"
                notifstatus = "❌مسدود"

            else:
                banstatus = "❌مسدود"
                newbanstatus = "false"
                notifstatus = "✅آزاد"
            button = [
                [Button.inline(f"{balance} دلار ", data=f'null'), Button.inline("💸 موجودی کاربر ", data=f'null')],
                [Button.inline("➕افزایش موجودی ", data=f'user+_{userid}'),
                 Button.inline("➖ کاهش موجودی", data=f'user-_{userid}')],
                [Button.inline(f"{accountsended} عدد", data=f'null'),
                 Button.inline("⭐️ اکانت های ارسال شده", data=f'null')],
                [Button.inline(notifstatus, data=f'checkban_{userid}'), Button.inline("❔وضعیت", data=f'null')],

            ]
            query(f"UPDATE `users` SET `ban` = '{newbanstatus}' WHERE `user_id` = '{userid}'")
            await events.answer("✅ویرایش شد")
            await events.edit(f'📝 اطلاعات کاربر {userid}', buttons=button)
            await bot.send_message(int(userid), f"📣حساب کاربری شما توسط ادمین ربات {notifstatus} شد")
        # ======================================================
        if callback == "newcountry":
            set_step(chat_id, callback)
            await events.reply(
                '''برای افزودن کشور جدید با توجه به مثال زیر اطلاعات را وارد کنید : \n\n**مثال : **\n\n👇🏻👇🏻\n-------------------------\n\nUSA\nON\nآمریکا🇺🇸\n+1\n10000\n\n-------------------------''',
                buttons=admin_cancel_markup)
        # ======================================================
        if callback == "vn_newcountry":
            set_step(chat_id, callback)
            await events.reply(
                '''برای افزودن کشور جدید با توجه به مثال زیر اطلاعات را وارد کنید : \n\n**مثال : **n\n👇🏻👇🏻\n-------------------------\n\nUSA\nآمریکا🇺🇸\n+1\n10000\n\n-------------------------''',
                buttons=admin_cancel_markup)
        # ======================================================
        if callback.startswith("deletecountry"):
            countrycode = callback.split("_")[1]
            try:
                cursor.execute(f"DELETE FROM `countries` WHERE `countrycode` = '{countrycode}'")
                await events.answer(f"کشور {countrycode} با موفقیت حذف شد")
                cursor.execute('SELECT * FROM countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(new_country)
                keyboard.append(manage_countries)
                for row in rows:
                    if row[1] == "ON":
                        status = "✅روشن"
                    else:
                        status = "❌خاموش"
                    button = [Button.inline("❌حذف", data=f'deletecountry_{row[3]}'),
                              Button.inline(row[4], data=f'changecountryprice_{row[3]}'),
                              Button.inline(status, data=f'changecountrystatus_{row[3]}'),
                              Button.inline(row[3], data=f'country_{row[3]}'),
                              Button.inline(row[2], data=f'country_{row[3]}')]
                    keyboard.append(button)
                await events.edit('⭐️مدیریت کشورها', buttons=keyboard)

            except:
                await events.answer("خطایی رخ داده است")
        # ======================================================
        if callback.startswith("vn_deletecountry"):
            countrycode = callback.split("_")[2]
            try:
                query(f"DELETE FROM `vn_countries` WHERE `country_code` = '{countrycode}'")
                await events.answer(f"کشور {countrycode} با موفقیت حذف شد")
                cursor.execute('SELECT name, price, country_code FROM vn_countries')
                rows = cursor.fetchall()
                keyboard = []
                keyboard.append(vn_new_country)
                keyboard.append([Button.inline("دکمه حذف"), Button.inline('کشور'), Button.inline("قیمت")])
                for row in rows:
                    button = [Button.inline("❌حذف", data=f'vn_deletecountry_{row[2]}'),
                              Button.inline(str(row[0]), data=f'vn_country_{row[0]}'),
                              Button.inline(str(row[1]), data=f'vn_changecountryprice:{row[2]}')]
                    keyboard.append(button)
                await events.edit('⭐️مدیریت کشورها', buttons=keyboard)

            except:
                await events.answer("خطایی رخ داده است")
        # ======================================================
        if callback.startswith("sendmessage"):
            await events.reply("**پاسخ خود را وارد کنید👇🏻:**", buttons=admin_cancel_markup)
            set_step(chat_id, callback)


# ==========================================================

bot.run_until_disconnected()
